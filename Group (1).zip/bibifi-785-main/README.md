# BIBIFI Fileserver

## 1) Project Spec

This project implements the **Build-it** phase of BIBIFI: an encrypted secure filesystem middleware in C++17.

Core requirements implemented include:
- Login via `./fileserver keyfile_name`
- Bootstrap of `filesystem/`, `public_keys/`, and admin credentials
- OpenSSL-backed crypto:
  - RSA keypairs for authentication (`*_keyfile` private keys, `public_keys/*.pub` public keys)
  - AES-256-GCM encryption at rest for file contents (no plaintext stored on disk)
  - RSA-OAEP-SHA256 wrapping of per-file keys for owners/admin + shared recipients
- Shell commands:
  - User: `cd`, `pwd`, `ls`, `cat`, `share`, `mkdir`, `mkfile`, `exit`
  - Admin: all user commands + `adduser`
- Admin cross-user semantics: admin can read any user’s filesystem, but writes are limited to the
  admin’s own `/personal` tree. Attempts to write in other users’ `/personal` or any `/shared` path
  return `Forbidden`.
- Per-user virtual roots with `/personal` and `/shared`
- Forbidden writes in `/` and `/shared` (and shared subtree)
- Shared files are read-only and reflect updates from owner
- Error outputs and behavior aligned to spec contract tests
- `mkfile` requires a non-empty contents argument; empty contents are treated as `Invalid Command`.
- Share index limits/behavior:
- Max share capsules per recipient: 1024.
- Share index file: `filesystem/shares_index/<user_id>.idx`, max size 64 KiB.
- Share capsule record max size: 256 KiB.
- Index is a hint: missing/corrupt/overflow triggers a rescan of `filesystem/shares/<user_id>`.
- If a rescan overflows, `/shared` is treated as empty and shared reads fail closed; new shares fail with `Invalid Command` when at capacity.

---

## 2) Instructions to Build and Run

From repo root:

```bash
cmake -S . -B build
cmake --build build -j4
```

Notes:
- OpenSSL (libcrypto) must be available for the build (CMake uses `find_package(OpenSSL REQUIRED)`).
- Keyfiles are created as `<username>_keyfile`:
  - First line: username
  - Optional metadata lines (currently: `root=<root_user_id>` to pin the admin/root public key)
  - Remainder: PEM private key (starts at `-----BEGIN ...`).

Run fileserver:

```bash
./build/fileserver admin_keyfile
```

Example interactive commands:

```text
pwd
ls
cd /personal
mkdir docs
mkfile note hello
cat note
adduser alice
share note alice
exit
```

---

## 3) Instructions to Run Test Cases

### Run all default tests

```bash
ctest --test-dir build --output-on-failure
```

### Optional: run by label

```bash
ctest --test-dir build --output-on-failure -L unit
ctest --test-dir build --output-on-failure -L contract
ctest --test-dir build --output-on-failure -L security
ctest --test-dir build --output-on-failure -L reliability
ctest --test-dir build --output-on-failure -L regression
```

---

## 4) Instructions to Check Test Coverage

This uses LLVM source-based coverage on macOS (`llvm-profdata`, `llvm-cov`).

### Build with coverage instrumentation

```bash
cmake -S . -B /tmp/bibifi-build-coverage -DBIBIFI_ENABLE_PENDING_CONTRACTS=ON \
  -DCMAKE_CXX_FLAGS='-fprofile-instr-generate -fcoverage-mapping'
cmake --build /tmp/bibifi-build-coverage -j4
```

### Run tests and collect profiles

```bash
rm -f /tmp/bibifi-cov-*.profraw /tmp/bibifi-cov.profdata
LLVM_PROFILE_FILE=/tmp/bibifi-cov-%p.profraw \
  ctest --test-dir /tmp/bibifi-build-coverage --output-on-failure
```

### Merge and print coverage report

```bash
xcrun llvm-profdata merge -sparse /tmp/bibifi-cov-*.profraw -o /tmp/bibifi-cov.profdata
xcrun llvm-cov report /tmp/bibifi-build-coverage/unit_tests \
  -instr-profile=/tmp/bibifi-cov.profdata \
  -object=/tmp/bibifi-build-coverage/integration_cli_tests \
  -object=/tmp/bibifi-build-coverage/security_tests \
  -object=/tmp/bibifi-build-coverage/reliability_tests \
  -object=/tmp/bibifi-build-coverage/regression_tests
```

To inspect line-level details:

```bash
xcrun llvm-cov show /tmp/bibifi-build-coverage/unit_tests \
  -instr-profile=/tmp/bibifi-cov.profdata \
  -object=/tmp/bibifi-build-coverage/integration_cli_tests \
  -object=/tmp/bibifi-build-coverage/security_tests \
  -object=/tmp/bibifi-build-coverage/reliability_tests \
  -object=/tmp/bibifi-build-coverage/regression_tests \
  src/vfs/vfs_service.cpp
```
