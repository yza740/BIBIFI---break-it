#include "crypto/encoding_utils.h"

namespace bibifi {

namespace {

int hexValue(char c) {
    if (c >= '0' && c <= '9') {
        return c - '0';
    }
    if (c >= 'a' && c <= 'f') {
        return 10 + (c - 'a');
    }
    if (c >= 'A' && c <= 'F') {
        return 10 + (c - 'A');
    }
    return -1;
}

}  // namespace

std::string hexEncode(const std::vector<std::uint8_t>& bytes) {
    static constexpr char kHex[] = "0123456789abcdef";
    std::string out;
    out.reserve(bytes.size() * 2);
    for (std::uint8_t b : bytes) {
        out.push_back(kHex[(b >> 4) & 0x0F]);
        out.push_back(kHex[b & 0x0F]);
    }
    return out;
}

Result<std::vector<std::uint8_t>> hexDecode(const std::string& hex) {
    if (hex.size() % 2U != 0) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, "odd hex length");
    }

    std::vector<std::uint8_t> out;
    out.reserve(hex.size() / 2U);
    for (std::size_t i = 0; i < hex.size(); i += 2U) {
        const int hi = hexValue(hex[i]);
        const int lo = hexValue(hex[i + 1]);
        if (hi < 0 || lo < 0) {
            return Result<std::vector<std::uint8_t>>::err(FsError::Internal, "invalid hex");
        }
        out.push_back(static_cast<std::uint8_t>((hi << 4) | lo));
    }
    return Result<std::vector<std::uint8_t>>::ok(out);
}

}  // namespace bibifi
