#ifndef BIBIFI_CRYPTO_CRYPTO_PROVIDER_H
#define BIBIFI_CRYPTO_CRYPTO_PROVIDER_H

#include "bibifi/core/result.h"
#include "crypto/openssl_utils.h"

#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace bibifi {

class PublicKey {
public:
    PublicKey() = default;
    PublicKey(PublicKey&&) noexcept = default;
    PublicKey& operator=(PublicKey&&) noexcept = default;
    PublicKey(const PublicKey&) = delete;
    PublicKey& operator=(const PublicKey&) = delete;

private:
    friend class CryptoProvider;
    std::unique_ptr<EVP_PKEY, EvpPkeyDeleter> key_;
};

struct AeadBlob {
    std::vector<std::uint8_t> iv;
    std::vector<std::uint8_t> tag;
    std::vector<std::uint8_t> ciphertext;
};

class CryptoProvider {
public:
    Result<std::vector<std::uint8_t>> randomBytes(std::size_t size) const;
    Result<std::string> sha256Hex(const std::vector<std::uint8_t>& data) const;
    Result<std::string> userIdFromPrivatePem(const std::string& private_key_pem) const;
    Result<std::string> userIdFromPublicKeyPath(const std::string& public_key_path) const;
    Result<PublicKey> loadPublicKeyFromPath(const std::string& public_key_path) const;
    Result<std::string> userIdFromPublicKey(const PublicKey& public_key) const;

    Result<AeadBlob> encryptAesGcm(const std::vector<std::uint8_t>& plaintext,
                                   const std::vector<std::uint8_t>& key,
                                   const std::vector<std::uint8_t>& aad) const;
    Result<std::vector<std::uint8_t>> decryptAesGcm(const AeadBlob& blob,
                                                    const std::vector<std::uint8_t>& key,
                                                    const std::vector<std::uint8_t>& aad) const;

    Result<std::vector<std::uint8_t>> rsaWrapKeyWithPublicKey(const std::vector<std::uint8_t>& key,
                                                              const PublicKey& public_key) const;
    Result<std::vector<std::uint8_t>> rsaWrapKeyWithPublicKeyPath(const std::vector<std::uint8_t>& key,
                                                                  const std::string& public_key_path) const;
    Result<std::vector<std::uint8_t>> rsaUnwrapKeyWithPrivatePem(const std::vector<std::uint8_t>& wrapped_key,
                                                                 const std::string& private_key_pem) const;

    Result<std::vector<std::uint8_t>> signRsaPssSha256WithPrivatePem(const std::vector<std::uint8_t>& message,
                                                                     const std::string& private_key_pem) const;
    Result<bool> verifyRsaPssSha256WithPublicKey(const std::vector<std::uint8_t>& message,
                                                 const std::vector<std::uint8_t>& signature,
                                                 const PublicKey& public_key) const;
    Result<bool> verifyRsaPssSha256WithPublicKeyPath(const std::vector<std::uint8_t>& message,
                                                     const std::vector<std::uint8_t>& signature,
                                                     const std::string& public_key_path) const;
};

}  // namespace bibifi

#endif  // BIBIFI_CRYPTO_CRYPTO_PROVIDER_H
