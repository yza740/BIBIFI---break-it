#include "crypto/crypto_provider.h"
#include "crypto/encoding_utils.h"
#include "crypto/openssl_utils.h"

#include <cerrno>
#include <cstdio>
#include <fcntl.h>
#include <memory>
#include <sys/stat.h>
#include <unistd.h>
#include <utility>

#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/opensslv.h>
#include <openssl/pem.h>
#include <openssl/rand.h>
#include <openssl/rsa.h>
#include <openssl/x509.h>

namespace bibifi {

namespace {
struct EvpCipherCtxDeleter {
    void operator()(EVP_CIPHER_CTX* ctx) const noexcept { EVP_CIPHER_CTX_free(ctx); }
};

struct BioDeleter {
    void operator()(BIO* bio) const noexcept { BIO_free(bio); }
};

using EvpCipherCtxPtr = std::unique_ptr<EVP_CIPHER_CTX, EvpCipherCtxDeleter>;
using EvpPkeyPtr = std::unique_ptr<EVP_PKEY, EvpPkeyDeleter>;
using BioPtr = std::unique_ptr<BIO, BioDeleter>;

constexpr std::uintmax_t kMaxPublicKeyBytes = 64 * 1024;

Result<std::vector<std::uint8_t>> readFileBytesBoundedNoSymlink(const std::string& path,
                                                                 std::uintmax_t max_bytes) {
    int flags = O_RDONLY;
#ifdef O_NOFOLLOW
    flags |= O_NOFOLLOW;
#endif
#ifdef O_CLOEXEC
    flags |= O_CLOEXEC;
#endif
    const int fd = ::open(path.c_str(), flags);
    if (fd < 0) {
        return Result<std::vector<std::uint8_t>>::err(FsError::NotFound, "public key missing");
    }

    struct stat st {};
    if (::fstat(fd, &st) != 0) {
        ::close(fd);
        return Result<std::vector<std::uint8_t>>::err(FsError::NotFound, "public key missing");
    }
    if (!S_ISREG(st.st_mode)) {
        ::close(fd);
        return Result<std::vector<std::uint8_t>>::err(FsError::NotFound, "public key missing");
    }
    if (st.st_size < 0 || static_cast<std::uintmax_t>(st.st_size) > max_bytes) {
        ::close(fd);
        return Result<std::vector<std::uint8_t>>::err(FsError::InvalidKeyfile, "public key malformed");
    }

    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(st.st_size));
    std::size_t total = 0;
    while (total < bytes.size()) {
        const ssize_t n = ::read(fd, bytes.data() + total, bytes.size() - total);
        if (n < 0 && errno == EINTR) {
            continue;
        }
        if (n <= 0) {
            ::close(fd);
            return Result<std::vector<std::uint8_t>>::err(FsError::InvalidKeyfile, "public key malformed");
        }
        total += static_cast<std::size_t>(n);
    }
    ::close(fd);
    return Result<std::vector<std::uint8_t>>::ok(bytes);
}

Result<EvpPkeyPtr> loadPublicKeyFromBytes(const std::vector<std::uint8_t>& bytes) {
    if (bytes.empty()) {
        return Result<EvpPkeyPtr>::err(FsError::InvalidKeyfile, "public key missing");
    }

    auto size = opensslSizeToInt(bytes.size(), "public key pem");
    if (size.isErr()) {
        return Result<EvpPkeyPtr>::err(size.error(), size.message());
    }

    BIO* bio = BIO_new_mem_buf(bytes.data(), size.value());
    if (!bio) {
        return Result<EvpPkeyPtr>::err(FsError::Internal, "bio alloc failed");
    }

    EVP_PKEY* pkey = PEM_read_bio_PUBKEY(bio, nullptr, nullptr, nullptr);
    BIO_free(bio);
    if (!pkey) {
        return Result<EvpPkeyPtr>::err(FsError::InvalidKeyfile, opensslErrorString());
    }

    return Result<EvpPkeyPtr>::ok(EvpPkeyPtr(pkey));
}

Result<EvpPkeyPtr> loadPublicKeyFromPathInternal(const std::string& path) {
    auto bytes = readFileBytesBoundedNoSymlink(path, kMaxPublicKeyBytes);
    if (bytes.isErr()) {
        return Result<EvpPkeyPtr>::err(bytes.error(), bytes.message());
    }
    return loadPublicKeyFromBytes(bytes.value());
}

Result<std::vector<std::uint8_t>> publicKeyDer(EVP_PKEY* key) {
    if (!key) {
        return Result<std::vector<std::uint8_t>>::err(FsError::InvalidKeyfile, "missing key");
    }

    int len = i2d_PUBKEY(key, nullptr);
    if (len <= 0) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }

    std::vector<std::uint8_t> out(static_cast<std::size_t>(len));
    unsigned char* p = out.data();
    if (i2d_PUBKEY(key, &p) <= 0) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }
    return Result<std::vector<std::uint8_t>>::ok(out);
}

Result<std::vector<std::uint8_t>> rsaOaepEncrypt(const std::vector<std::uint8_t>& plaintext,
                                                 EVP_PKEY* public_key) {
    if (!public_key) {
        return Result<std::vector<std::uint8_t>>::err(FsError::InvalidKeyfile, "missing public key");
    }

    EVP_PKEY_CTX* ctx = EVP_PKEY_CTX_new(public_key, nullptr);
    if (!ctx) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, "ctx alloc failed");
    }

    auto cleanup = [&]() { EVP_PKEY_CTX_free(ctx); };

    if (EVP_PKEY_encrypt_init(ctx) <= 0) {
        cleanup();
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }
    if (EVP_PKEY_CTX_set_rsa_padding(ctx, RSA_PKCS1_OAEP_PADDING) <= 0) {
        cleanup();
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }
    if (EVP_PKEY_CTX_set_rsa_oaep_md(ctx, EVP_sha256()) <= 0) {
        cleanup();
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }
    if (EVP_PKEY_CTX_set_rsa_mgf1_md(ctx, EVP_sha256()) <= 0) {
        cleanup();
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }

    std::size_t out_len = 0;
    if (EVP_PKEY_encrypt(ctx, nullptr, &out_len, plaintext.data(), plaintext.size()) <= 0) {
        cleanup();
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }

    std::vector<std::uint8_t> out(out_len);
    if (EVP_PKEY_encrypt(ctx, out.data(), &out_len, plaintext.data(), plaintext.size()) <= 0) {
        cleanup();
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }
    out.resize(out_len);

    cleanup();
    return Result<std::vector<std::uint8_t>>::ok(out);
}

Result<std::vector<std::uint8_t>> rsaOaepDecrypt(const std::vector<std::uint8_t>& ciphertext,
                                                 EVP_PKEY* private_key) {
    if (!private_key) {
        return Result<std::vector<std::uint8_t>>::err(FsError::InvalidKeyfile, "missing private key");
    }

    EVP_PKEY_CTX* ctx = EVP_PKEY_CTX_new(private_key, nullptr);
    if (!ctx) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, "ctx alloc failed");
    }
    auto cleanup = [&]() { EVP_PKEY_CTX_free(ctx); };

    if (EVP_PKEY_decrypt_init(ctx) <= 0) {
        cleanup();
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }
    if (EVP_PKEY_CTX_set_rsa_padding(ctx, RSA_PKCS1_OAEP_PADDING) <= 0) {
        cleanup();
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }
    if (EVP_PKEY_CTX_set_rsa_oaep_md(ctx, EVP_sha256()) <= 0) {
        cleanup();
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }
    if (EVP_PKEY_CTX_set_rsa_mgf1_md(ctx, EVP_sha256()) <= 0) {
        cleanup();
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }

    std::size_t out_len = 0;
    if (EVP_PKEY_decrypt(ctx, nullptr, &out_len, ciphertext.data(), ciphertext.size()) <= 0) {
        cleanup();
        return Result<std::vector<std::uint8_t>>::err(FsError::InvalidKeyfile, "unwrap failed");
    }

    std::vector<std::uint8_t> out(out_len);
    if (EVP_PKEY_decrypt(ctx, out.data(), &out_len, ciphertext.data(), ciphertext.size()) <= 0) {
        cleanup();
        return Result<std::vector<std::uint8_t>>::err(FsError::InvalidKeyfile, "unwrap failed");
    }
    out.resize(out_len);

    cleanup();
    return Result<std::vector<std::uint8_t>>::ok(out);
}

}  // namespace

Result<std::vector<std::uint8_t>> CryptoProvider::randomBytes(std::size_t size) const {
    return opensslRandomBytes(size);
}

Result<std::string> CryptoProvider::sha256Hex(const std::vector<std::uint8_t>& data) const {
    unsigned int md_len = 0;
    std::vector<std::uint8_t> md(EVP_MAX_MD_SIZE);

    EVP_MD_CTX* ctx = EVP_MD_CTX_new();
    if (!ctx) {
        return Result<std::string>::err(FsError::Internal, "md ctx alloc failed");
    }

    auto cleanup = [&]() { EVP_MD_CTX_free(ctx); };

    if (EVP_DigestInit_ex(ctx, EVP_sha256(), nullptr) != 1) {
        cleanup();
        return Result<std::string>::err(FsError::Internal, opensslErrorString());
    }

    if (!data.empty()) {
        if (EVP_DigestUpdate(ctx, data.data(), data.size()) != 1) {
            cleanup();
            return Result<std::string>::err(FsError::Internal, opensslErrorString());
        }
    }

    if (EVP_DigestFinal_ex(ctx, md.data(), &md_len) != 1) {
        cleanup();
        return Result<std::string>::err(FsError::Internal, opensslErrorString());
    }

    cleanup();
    md.resize(md_len);
    return Result<std::string>::ok(hexEncode(md));
}

Result<std::string> CryptoProvider::userIdFromPrivatePem(const std::string& private_key_pem) const {
    auto priv_result = loadPrivateKeyFromPem(private_key_pem);
    if (priv_result.isErr()) {
        return Result<std::string>::err(priv_result.error(), priv_result.message());
    }

    auto der = publicKeyDer(priv_result.value().get());
    if (der.isErr()) {
        return Result<std::string>::err(der.error(), der.message());
    }
    return sha256Hex(der.value());
}

Result<std::string> CryptoProvider::userIdFromPublicKeyPath(const std::string& public_key_path) const {
    auto pub_result = loadPublicKeyFromPath(public_key_path);
    if (pub_result.isErr()) {
        return Result<std::string>::err(pub_result.error(), pub_result.message());
    }
    return userIdFromPublicKey(pub_result.value());
}

Result<PublicKey> CryptoProvider::loadPublicKeyFromPath(const std::string& public_key_path) const {
    auto pub_result = loadPublicKeyFromPathInternal(public_key_path);
    if (pub_result.isErr()) {
        return Result<PublicKey>::err(pub_result.error(), pub_result.message());
    }
    PublicKey out;
    out.key_ = std::move(pub_result.value());
    return Result<PublicKey>::ok(std::move(out));
}

Result<std::string> CryptoProvider::userIdFromPublicKey(const PublicKey& public_key) const {
    auto der = publicKeyDer(public_key.key_.get());
    if (der.isErr()) {
        return Result<std::string>::err(der.error(), der.message());
    }
    return sha256Hex(der.value());
}

Result<AeadBlob> CryptoProvider::encryptAesGcm(const std::vector<std::uint8_t>& plaintext,
                                               const std::vector<std::uint8_t>& key,
                                               const std::vector<std::uint8_t>& aad) const {
    if (key.size() != 32U) {
        return Result<AeadBlob>::err(FsError::InvalidCommand, "invalid key length");
    }

    auto iv_result = randomBytes(12);
    if (iv_result.isErr()) {
        return Result<AeadBlob>::err(iv_result.error(), iv_result.message());
    }

    AeadBlob out;
    out.iv = std::move(iv_result.value());
    out.tag.resize(16);
    out.ciphertext.resize(plaintext.size());

    EvpCipherCtxPtr ctx(EVP_CIPHER_CTX_new());
    if (!ctx) {
        return Result<AeadBlob>::err(FsError::Internal, "cipher ctx alloc failed");
    }

    if (EVP_EncryptInit_ex(ctx.get(), EVP_aes_256_gcm(), nullptr, nullptr, nullptr) != 1) {
        return Result<AeadBlob>::err(FsError::Internal, opensslErrorString());
    }
    auto iv_len = opensslSizeToInt(out.iv.size(), "iv");
    if (iv_len.isErr()) {
        return Result<AeadBlob>::err(iv_len.error(), iv_len.message());
    }
    if (EVP_CIPHER_CTX_ctrl(ctx.get(), EVP_CTRL_GCM_SET_IVLEN, iv_len.value(), nullptr) != 1) {
        return Result<AeadBlob>::err(FsError::Internal, opensslErrorString());
    }
    if (EVP_EncryptInit_ex(ctx.get(), nullptr, nullptr, key.data(), out.iv.data()) != 1) {
        return Result<AeadBlob>::err(FsError::Internal, opensslErrorString());
    }

    int len = 0;
    if (!aad.empty()) {
        auto aad_len = opensslSizeToInt(aad.size(), "aad");
        if (aad_len.isErr()) {
            return Result<AeadBlob>::err(aad_len.error(), aad_len.message());
        }
        if (EVP_EncryptUpdate(ctx.get(), nullptr, &len, aad.data(), aad_len.value()) != 1) {
            return Result<AeadBlob>::err(FsError::Internal, opensslErrorString());
        }
    }

    if (!plaintext.empty()) {
        auto pt_len = opensslSizeToInt(plaintext.size(), "plaintext");
        if (pt_len.isErr()) {
            return Result<AeadBlob>::err(pt_len.error(), pt_len.message());
        }
        if (EVP_EncryptUpdate(ctx.get(),
                              out.ciphertext.data(),
                              &len,
                              plaintext.data(),
                              pt_len.value()) != 1) {
            return Result<AeadBlob>::err(FsError::Internal, opensslErrorString());
        }
    }
    int total = len;

    if (EVP_EncryptFinal_ex(ctx.get(), out.ciphertext.data() + total, &len) != 1) {
        return Result<AeadBlob>::err(FsError::Internal, opensslErrorString());
    }
    total += len;
    out.ciphertext.resize(static_cast<std::size_t>(total));

    auto tag_len = opensslSizeToInt(out.tag.size(), "tag");
    if (tag_len.isErr()) {
        return Result<AeadBlob>::err(tag_len.error(), tag_len.message());
    }
    if (EVP_CIPHER_CTX_ctrl(ctx.get(), EVP_CTRL_GCM_GET_TAG, tag_len.value(), out.tag.data()) != 1) {
        return Result<AeadBlob>::err(FsError::Internal, opensslErrorString());
    }

    return Result<AeadBlob>::ok(out);
}

Result<std::vector<std::uint8_t>> CryptoProvider::decryptAesGcm(const AeadBlob& blob,
                                                                const std::vector<std::uint8_t>& key,
                                                                const std::vector<std::uint8_t>& aad) const {
    if (key.size() != 32U) {
        return Result<std::vector<std::uint8_t>>::err(FsError::InvalidCommand, "invalid key length");
    }
    if (blob.iv.empty() || blob.tag.empty()) {
        return Result<std::vector<std::uint8_t>>::err(FsError::InvalidCommand, "invalid blob");
    }

    std::vector<std::uint8_t> plaintext(blob.ciphertext.size());

    EvpCipherCtxPtr ctx(EVP_CIPHER_CTX_new());
    if (!ctx) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, "cipher ctx alloc failed");
    }

    if (EVP_DecryptInit_ex(ctx.get(), EVP_aes_256_gcm(), nullptr, nullptr, nullptr) != 1) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }
    auto iv_len = opensslSizeToInt(blob.iv.size(), "iv");
    if (iv_len.isErr()) {
        return Result<std::vector<std::uint8_t>>::err(iv_len.error(), iv_len.message());
    }
    if (EVP_CIPHER_CTX_ctrl(ctx.get(), EVP_CTRL_GCM_SET_IVLEN, iv_len.value(), nullptr) != 1) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }
    if (EVP_DecryptInit_ex(ctx.get(), nullptr, nullptr, key.data(), blob.iv.data()) != 1) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }

    int len = 0;
    if (!aad.empty()) {
        auto aad_len = opensslSizeToInt(aad.size(), "aad");
        if (aad_len.isErr()) {
            return Result<std::vector<std::uint8_t>>::err(aad_len.error(), aad_len.message());
        }
        if (EVP_DecryptUpdate(ctx.get(), nullptr, &len, aad.data(), aad_len.value()) != 1) {
            return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
        }
    }

    if (!blob.ciphertext.empty()) {
        auto ct_len = opensslSizeToInt(blob.ciphertext.size(), "ciphertext");
        if (ct_len.isErr()) {
            return Result<std::vector<std::uint8_t>>::err(ct_len.error(), ct_len.message());
        }
        if (EVP_DecryptUpdate(ctx.get(),
                              plaintext.data(),
                              &len,
                              blob.ciphertext.data(),
                              ct_len.value()) != 1) {
            return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
        }
    }
    int total = len;

    auto tag_len = opensslSizeToInt(blob.tag.size(), "tag");
    if (tag_len.isErr()) {
        return Result<std::vector<std::uint8_t>>::err(tag_len.error(), tag_len.message());
    }
    if (EVP_CIPHER_CTX_ctrl(ctx.get(),
                            EVP_CTRL_GCM_SET_TAG,
                            tag_len.value(),
                            const_cast<std::uint8_t*>(blob.tag.data())) != 1) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }

    const int final_ok = EVP_DecryptFinal_ex(ctx.get(), plaintext.data() + total, &len);
    if (final_ok != 1) {
        return Result<std::vector<std::uint8_t>>::err(FsError::InvalidKeyfile, "decrypt failed");
    }
    total += len;
    plaintext.resize(static_cast<std::size_t>(total));
    return Result<std::vector<std::uint8_t>>::ok(plaintext);
}

Result<std::vector<std::uint8_t>> CryptoProvider::rsaWrapKeyWithPublicKey(
    const std::vector<std::uint8_t>& key,
    const PublicKey& public_key) const {
    if (!public_key.key_) {
        return Result<std::vector<std::uint8_t>>::err(FsError::InvalidKeyfile, "missing public key");
    }
    return rsaOaepEncrypt(key, public_key.key_.get());
}

Result<std::vector<std::uint8_t>> CryptoProvider::rsaWrapKeyWithPublicKeyPath(
    const std::vector<std::uint8_t>& key,
    const std::string& public_key_path) const {
    auto pub_result = loadPublicKeyFromPath(public_key_path);
    if (pub_result.isErr()) {
        return Result<std::vector<std::uint8_t>>::err(pub_result.error(), pub_result.message());
    }

    return rsaWrapKeyWithPublicKey(key, pub_result.value());
}

Result<std::vector<std::uint8_t>> CryptoProvider::rsaUnwrapKeyWithPrivatePem(
    const std::vector<std::uint8_t>& wrapped_key,
    const std::string& private_key_pem) const {
    auto priv_result = loadPrivateKeyFromPem(private_key_pem);
    if (priv_result.isErr()) {
        return Result<std::vector<std::uint8_t>>::err(priv_result.error(), priv_result.message());
    }

    return rsaOaepDecrypt(wrapped_key, priv_result.value().get());
}

Result<std::vector<std::uint8_t>> CryptoProvider::signRsaPssSha256WithPrivatePem(
    const std::vector<std::uint8_t>& message,
    const std::string& private_key_pem) const {
    auto priv_result = loadPrivateKeyFromPem(private_key_pem);
    if (priv_result.isErr()) {
        return Result<std::vector<std::uint8_t>>::err(priv_result.error(), priv_result.message());
    }

    EVP_MD_CTX* ctx = EVP_MD_CTX_new();
    if (!ctx) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, "sign ctx alloc failed");
    }

    auto cleanup = [&]() { EVP_MD_CTX_free(ctx); };

    EVP_PKEY_CTX* pkey_ctx = nullptr;
    if (EVP_DigestSignInit(ctx, &pkey_ctx, EVP_sha256(), nullptr, priv_result.value().get()) != 1) {
        cleanup();
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }

    if (EVP_PKEY_CTX_set_rsa_padding(pkey_ctx, RSA_PKCS1_PSS_PADDING) <= 0) {
        cleanup();
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }
    if (EVP_PKEY_CTX_set_rsa_pss_saltlen(pkey_ctx, -1) <= 0) {  // saltlen = hashlen
        cleanup();
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }

    if (!message.empty()) {
        if (EVP_DigestSignUpdate(ctx, message.data(), message.size()) != 1) {
            cleanup();
            return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
        }
    }

    std::size_t sig_len = 0;
    if (EVP_DigestSignFinal(ctx, nullptr, &sig_len) != 1) {
        cleanup();
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }

    std::vector<std::uint8_t> sig(sig_len);
    if (EVP_DigestSignFinal(ctx, sig.data(), &sig_len) != 1) {
        cleanup();
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }
    sig.resize(sig_len);

    cleanup();
    return Result<std::vector<std::uint8_t>>::ok(sig);
}

Result<bool> CryptoProvider::verifyRsaPssSha256WithPublicKeyPath(const std::vector<std::uint8_t>& message,
                                                                 const std::vector<std::uint8_t>& signature,
                                                                 const std::string& public_key_path) const {
    auto pub_result = loadPublicKeyFromPath(public_key_path);
    if (pub_result.isErr()) {
        return Result<bool>::err(pub_result.error(), pub_result.message());
    }

    return verifyRsaPssSha256WithPublicKey(message, signature, pub_result.value());
}

Result<bool> CryptoProvider::verifyRsaPssSha256WithPublicKey(const std::vector<std::uint8_t>& message,
                                                             const std::vector<std::uint8_t>& signature,
                                                             const PublicKey& public_key) const {
    if (!public_key.key_) {
        return Result<bool>::err(FsError::InvalidKeyfile, "missing public key");
    }

    EVP_MD_CTX* ctx = EVP_MD_CTX_new();
    if (!ctx) {
        return Result<bool>::err(FsError::Internal, "verify ctx alloc failed");
    }
    auto cleanup = [&]() { EVP_MD_CTX_free(ctx); };

    EVP_PKEY_CTX* pkey_ctx = nullptr;
    if (EVP_DigestVerifyInit(ctx, &pkey_ctx, EVP_sha256(), nullptr, public_key.key_.get()) != 1) {
        cleanup();
        return Result<bool>::err(FsError::Internal, opensslErrorString());
    }

    if (EVP_PKEY_CTX_set_rsa_padding(pkey_ctx, RSA_PKCS1_PSS_PADDING) <= 0) {
        cleanup();
        return Result<bool>::err(FsError::Internal, opensslErrorString());
    }
    if (EVP_PKEY_CTX_set_rsa_pss_saltlen(pkey_ctx, -1) <= 0) {
        cleanup();
        return Result<bool>::err(FsError::Internal, opensslErrorString());
    }

    if (!message.empty()) {
        if (EVP_DigestVerifyUpdate(ctx, message.data(), message.size()) != 1) {
            cleanup();
            return Result<bool>::err(FsError::Internal, opensslErrorString());
        }
    }

    const int ok = EVP_DigestVerifyFinal(ctx, signature.data(), signature.size());
    cleanup();
    if (ok == 1) {
        return Result<bool>::ok(true);
    }
    if (ok == 0) {
        return Result<bool>::ok(false);
    }
    return Result<bool>::err(FsError::Internal, opensslErrorString());
}

}  // namespace bibifi
