#ifndef BIBIFI_CRYPTO_ENCODING_UTILS_H
#define BIBIFI_CRYPTO_ENCODING_UTILS_H

#include "bibifi/core/result.h"

#include <cstdint>
#include <string>
#include <vector>

namespace bibifi {

std::string hexEncode(const std::vector<std::uint8_t>& bytes);
Result<std::vector<std::uint8_t>> hexDecode(const std::string& hex);

}  // namespace bibifi

#endif  // BIBIFI_CRYPTO_ENCODING_UTILS_H
