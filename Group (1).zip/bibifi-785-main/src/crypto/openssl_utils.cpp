#include "crypto/openssl_utils.h"

#include <cstdio>
#include <limits>

#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rand.h>

namespace bibifi {

void EvpPkeyDeleter::operator()(EVP_PKEY* pkey) const noexcept { EVP_PKEY_free(pkey); }

std::string opensslErrorString() {
    unsigned long err = ERR_get_error();
    if (err == 0) {
        return "openssl error";
    }

    char buf[256];
    ERR_error_string_n(err, buf, sizeof(buf));
    return std::string(buf);
}

Result<int> opensslSizeToInt(std::size_t size, const char* label) {
    if (size > static_cast<std::size_t>(std::numeric_limits<int>::max())) {
        std::string msg = label ? std::string(label) + " too large" : "size too large";
        return Result<int>::err(FsError::Internal, msg);
    }
    return Result<int>::ok(static_cast<int>(size));
}

Result<std::vector<std::uint8_t>> opensslRandomBytes(std::size_t size) {
    std::vector<std::uint8_t> bytes(size);
    if (size == 0) {
        return Result<std::vector<std::uint8_t>>::ok(bytes);
    }

    auto len = opensslSizeToInt(size, "random bytes");
    if (len.isErr()) {
        return Result<std::vector<std::uint8_t>>::err(len.error(), len.message());
    }

    if (RAND_bytes(bytes.data(), len.value()) != 1) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }

    return Result<std::vector<std::uint8_t>>::ok(bytes);
}

Result<EvpPkeyPtr> loadPublicKeyFromPath(const std::string& path) {
    FILE* f = std::fopen(path.c_str(), "rb");
    if (!f) {
        return Result<EvpPkeyPtr>::err(FsError::NotFound, "public key missing");
    }

    EVP_PKEY* pkey = PEM_read_PUBKEY(f, nullptr, nullptr, nullptr);
    std::fclose(f);
    if (!pkey) {
        return Result<EvpPkeyPtr>::err(FsError::InvalidKeyfile, opensslErrorString());
    }

    return Result<EvpPkeyPtr>::ok(EvpPkeyPtr(pkey));
}

Result<EvpPkeyPtr> loadPrivateKeyFromPem(const std::string& pem) {
    if (pem.empty()) {
        return Result<EvpPkeyPtr>::err(FsError::InvalidKeyfile, "private key missing");
    }

    auto pem_len = opensslSizeToInt(pem.size(), "private key pem");
    if (pem_len.isErr()) {
        return Result<EvpPkeyPtr>::err(pem_len.error(), pem_len.message());
    }

    BIO* bio = BIO_new_mem_buf(pem.data(), pem_len.value());
    if (!bio) {
        return Result<EvpPkeyPtr>::err(FsError::Internal, "bio alloc failed");
    }

    EVP_PKEY* pkey = PEM_read_bio_PrivateKey(bio, nullptr, nullptr, nullptr);
    BIO_free(bio);
    if (!pkey) {
        return Result<EvpPkeyPtr>::err(FsError::InvalidKeyfile, opensslErrorString());
    }

    return Result<EvpPkeyPtr>::ok(EvpPkeyPtr(pkey));
}

}  // namespace bibifi
