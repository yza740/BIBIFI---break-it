#ifndef BIBIFI_CRYPTO_OPENSSL_UTILS_H
#define BIBIFI_CRYPTO_OPENSSL_UTILS_H

#include "bibifi/core/result.h"

#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

struct evp_pkey_st;
typedef struct evp_pkey_st EVP_PKEY;

namespace bibifi {

std::string opensslErrorString();
Result<int> opensslSizeToInt(std::size_t size, const char* label);
Result<std::vector<std::uint8_t>> opensslRandomBytes(std::size_t size);
struct EvpPkeyDeleter {
    void operator()(EVP_PKEY* pkey) const noexcept;
};

using EvpPkeyPtr = std::unique_ptr<EVP_PKEY, EvpPkeyDeleter>;

Result<EvpPkeyPtr> loadPublicKeyFromPath(const std::string& path);
Result<EvpPkeyPtr> loadPrivateKeyFromPem(const std::string& pem);

}  // namespace bibifi

#endif  // BIBIFI_CRYPTO_OPENSSL_UTILS_H
