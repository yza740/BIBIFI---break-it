#include "app/fileserver_app.h"

int main(int argc, char** argv) {
    bibifi::FileserverApp app;
    return app.run(argc, argv);
}
