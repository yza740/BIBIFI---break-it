#include "auth/auth_manager.h"
#include "auth/keyfile_reader.h"
#include "bibifi/core/validation.h"
#include "crypto/openssl_utils.h"

#include <cstdio>
#include <filesystem>
#include <memory>

#include <openssl/evp.h>
#include <openssl/opensslv.h>

namespace bibifi {

namespace {

bool keysMatch(EVP_PKEY* priv, EVP_PKEY* pub) {
    if (!priv || !pub) {
        return false;
    }

#if OPENSSL_VERSION_NUMBER < 0x30000000L
    return EVP_PKEY_cmp(priv, pub) == 1;
#else
    return EVP_PKEY_eq(priv, pub) == 1;
#endif
}

}  // namespace

Result<SessionContext> AuthManager::login(const std::string& keyfile_path) const {
    constexpr std::uintmax_t kMaxKeyfileBytes = 64 * 1024;

    auto keyfile = readKeyfileParsed(keyfile_path, kMaxKeyfileBytes);
    if (keyfile.isErr()) {
        return Result<SessionContext>::err(keyfile.error(), keyfile.message());
    }

    const std::string& username = keyfile.value().username;
    const std::string& private_pem = keyfile.value().private_key_pem;
    const std::string& pinned_root_user_id = keyfile.value().pinned_root_user_id;
    std::string effective_root_user_id = pinned_root_user_id;
    if (effective_root_user_id.empty()) {
        auto root_id = crypto_.userIdFromPublicKeyPath("public_keys/root.pub");
        if (root_id.isErr()) {
            return Result<SessionContext>::err(FsError::InvalidKeyfile, "invalid keyfile");
        }
        effective_root_user_id = root_id.value();
    }

    if (!bibifi::isValidUsername(username)) {
        return Result<SessionContext>::err(FsError::InvalidKeyfile, "malformed keyfile");
    }

    auto priv_key = loadPrivateKeyFromPem(private_pem);
    if (priv_key.isErr()) {
        return Result<SessionContext>::err(FsError::InvalidKeyfile, "invalid private key");
    }

    auto user_id = crypto_.userIdFromPrivatePem(private_pem);
    if (user_id.isErr()) {
        return Result<SessionContext>::err(FsError::InvalidKeyfile, "invalid keyfile");
    }

    const std::filesystem::path public_key_path = std::filesystem::path("public_keys") / (user_id.value() + ".pub");
    if (!std::filesystem::exists(public_key_path) || !std::filesystem::is_regular_file(public_key_path)) {
        return Result<SessionContext>::err(FsError::InvalidKeyfile, "unknown user");
    }

    auto pub_key = loadPublicKeyFromPath(public_key_path.string());
    if (pub_key.isErr()) {
        return Result<SessionContext>::err(FsError::InvalidKeyfile, "invalid public key");
    }

    if (!keysMatch(priv_key.value().get(), pub_key.value().get())) {
        return Result<SessionContext>::err(FsError::InvalidKeyfile, "key mismatch");
    }

    {
        if (!bibifi::isValidUserId(effective_root_user_id)) {
            return Result<SessionContext>::err(FsError::InvalidKeyfile, "invalid keyfile");
        }

        if (!pinned_root_user_id.empty()) {
            auto root_id = crypto_.userIdFromPublicKeyPath("public_keys/root.pub");
            if (root_id.isErr() || root_id.value() != pinned_root_user_id) {
                return Result<SessionContext>::err(FsError::InvalidKeyfile, "invalid keyfile");
            }
        }
    }

    SessionContext session;
    session.username = username;
    session.is_admin = (username == "admin");
    session.cwd_virtual = "/";
    session.user_id = user_id.value();
    session.pinned_root_user_id = effective_root_user_id;
    session.private_key_pem = private_pem;

    auto registry = registry_.loadForSession(session);
    if (registry.isErr()) {
        return Result<SessionContext>::err(FsError::InvalidKeyfile, "invalid keyfile");
    }

    const auto* entry = registry.value().findByUsername(username);
    if (!entry || entry->user_id != session.user_id) {
        return Result<SessionContext>::err(FsError::InvalidKeyfile, "unknown user");
    }

    return Result<SessionContext>::ok(session);
}

}  // namespace bibifi
