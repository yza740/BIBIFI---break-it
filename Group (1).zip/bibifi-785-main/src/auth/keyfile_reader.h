#ifndef BIBIFI_AUTH_KEYFILE_READER_H
#define BIBIFI_AUTH_KEYFILE_READER_H

#include "bibifi/core/result.h"

#include <cstdint>
#include <string>

namespace bibifi {

struct KeyfileContents {
    std::string username;
    std::string private_key_pem;
    std::string pinned_root_user_id;
};

Result<KeyfileContents> readKeyfileParsed(const std::string& keyfile_path,
                                          std::uintmax_t max_bytes,
                                          const std::string& expected_username = "");

}  // namespace bibifi

#endif  // BIBIFI_AUTH_KEYFILE_READER_H
