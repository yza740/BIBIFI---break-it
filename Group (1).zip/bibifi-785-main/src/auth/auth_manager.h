#ifndef BIBIFI_AUTH_AUTH_MANAGER_H
#define BIBIFI_AUTH_AUTH_MANAGER_H

#include "bibifi/core/result.h"
#include "bibifi/core/types.h"
#include "crypto/crypto_provider.h"
#include "users/registry_store.h"

#include <string>

namespace bibifi {

class AuthManager {
public:
    Result<SessionContext> login(const std::string& keyfile_path) const;

private:
    RegistryStore registry_;
    CryptoProvider crypto_;
};

}  // namespace bibifi

#endif  // BIBIFI_AUTH_AUTH_MANAGER_H
