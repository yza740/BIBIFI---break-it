#include "auth/keyfile_reader.h"

#include "bibifi/core/errors.h"

#include <cerrno>
#include <cstddef>
#include <fcntl.h>
#include <sstream>
#include <sys/stat.h>
#include <unistd.h>

namespace bibifi {

namespace {

std::string normalizeLineEndings(const std::string& input) {
    std::string out;
    out.reserve(input.size());
    for (std::size_t i = 0; i < input.size(); ++i) {
        const char c = input[i];
        if (c == '\r') {
            if (i + 1 < input.size() && input[i + 1] == '\n') {
                continue;
            }
            out.push_back('\n');
            continue;
        }
        out.push_back(c);
    }
    return out;
}

Result<KeyfileContents> missingKeyfileContentsError() {
    return Result<KeyfileContents>::err(FsError::InvalidKeyfile, "keyfile missing");
}

Result<KeyfileContents> malformedKeyfileContentsError() {
    return Result<KeyfileContents>::err(FsError::InvalidKeyfile, "keyfile malformed");
}

}  // namespace

Result<KeyfileContents> readKeyfileParsed(const std::string& keyfile_path,
                                          std::uintmax_t max_bytes,
                                          const std::string& expected_username) {
    struct stat lst;
    if (::lstat(keyfile_path.c_str(), &lst) != 0) {
        return missingKeyfileContentsError();
    }
    if (S_ISLNK(lst.st_mode)) {
        return missingKeyfileContentsError();
    }

    int flags = O_RDONLY;
#ifdef O_NOFOLLOW
    flags |= O_NOFOLLOW;
#endif
#ifdef O_CLOEXEC
    flags |= O_CLOEXEC;
#endif
    const int fd = ::open(keyfile_path.c_str(), flags);
    if (fd < 0) {
        return missingKeyfileContentsError();
    }

    struct stat st;
    if (::fstat(fd, &st) != 0) {
        ::close(fd);
        return missingKeyfileContentsError();
    }
    if (!S_ISREG(st.st_mode)) {
        ::close(fd);
        return missingKeyfileContentsError();
    }
    if (st.st_size < 0 || static_cast<std::uintmax_t>(st.st_size) > max_bytes) {
        ::close(fd);
        return malformedKeyfileContentsError();
    }

    std::string contents;
    contents.resize(static_cast<std::size_t>(st.st_size));
    std::size_t total = 0;
    while (total < contents.size()) {
        const ssize_t n = ::read(fd, &contents[total], contents.size() - total);
        if (n < 0 && errno == EINTR) {
            continue;
        }
        if (n <= 0) {
            ::close(fd);
            return malformedKeyfileContentsError();
        }
        total += static_cast<std::size_t>(n);
    }
    ::close(fd);

    const std::string data = normalizeLineEndings(contents);
    const std::size_t nl = data.find('\n');
    if (nl == std::string::npos) {
        return malformedKeyfileContentsError();
    }

    std::string username = data.substr(0, nl);
    if (!expected_username.empty() && username != expected_username) {
        return malformedKeyfileContentsError();
    }

    const std::string remainder = data.substr(nl + 1);
    const std::size_t begin = remainder.find("-----BEGIN");
    const std::string private_pem = (begin == std::string::npos) ? "" : remainder.substr(begin);
    if (private_pem.empty()) {
        return malformedKeyfileContentsError();
    }

    std::string pinned_root_user_id;
    if (begin != std::string::npos && begin > 0) {
        std::stringstream meta(remainder.substr(0, begin));
        std::string line;
        while (std::getline(meta, line)) {
            if (line.rfind("root=", 0) == 0) {
                pinned_root_user_id = line.substr(std::string("root=").size());
            }
        }
    }

    KeyfileContents out;
    out.username = std::move(username);
    out.private_key_pem = private_pem;
    out.pinned_root_user_id = std::move(pinned_root_user_id);
    return Result<KeyfileContents>::ok(out);
}

}  // namespace bibifi
