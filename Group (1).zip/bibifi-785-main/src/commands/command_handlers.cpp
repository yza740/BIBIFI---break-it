#include "commands/command_handlers.h"

#include <sstream>

namespace bibifi {

std::string CommandHandlers::handle(const ParsedCommand& command, SessionContext& session) {
    if (command.name == "exit") {
        should_exit_ = true;
        return "";
    }

    if (command.name == "pwd") {
        if (!command.args.empty()) {
            return "Invalid Command";
        }

        auto result = vfs_.pwd(session);
        return result.isOk() ? result.value() : "Invalid Command";
    }

    if (command.name == "cd") {
        if (command.args.size() != 1U) {
            return "Invalid Command";
        }

        auto result = vfs_.cd(session, command.args[0]);
        if (result.isErr()) {
            return "Invalid Command";
        }
        return "";
    }

    if (command.name == "ls") {
        if (!command.args.empty()) {
            return "Invalid Command";
        }

        auto result = vfs_.ls(session);
        if (result.isErr()) {
            return "Invalid Command";
        }

        std::ostringstream out;
        for (std::size_t i = 0; i < result.value().size(); ++i) {
            out << (result.value()[i].is_dir ? "d -> " : "f -> ") << result.value()[i].name;
            if (i + 1 < result.value().size()) {
                out << '\n';
            }
        }
        return out.str();
    }

    if (command.name == "cat") {
        if (command.args.size() != 1U) {
            return "Invalid Command";
        }

        auto result = vfs_.cat(session, command.args[0]);
        if (result.isErr()) {
            if (result.error() == FsError::NotFound) {
                return command.args[0] + " doesn't exist";
            }
            return "Invalid Command";
        }

        return result.value();
    }

    if (command.name == "share") {
        if (command.args.size() != 2U) {
            return "Invalid Command";
        }

        auto result = vfs_.share(session, command.args[0], command.args[1]);
        if (result.isErr()) {
            if (result.error() == FsError::NotFound) {
                return "File " + command.args[0] + " doesn't exist";
            }
            if (result.error() == FsError::InvalidKeyfile) {
                return "User " + command.args[1] + " doesn't exist";
            }
            if (result.error() == FsError::Forbidden) {
                return "Forbidden";
            }
            return "Invalid Command";
        }

        return "";
    }

    if (command.name == "mkdir") {
        if (command.args.size() != 1U) {
            return "Invalid Command";
        }

        auto result = vfs_.mkdir(session, command.args[0]);
        if (result.isErr()) {
            if (result.error() == FsError::Forbidden) {
                return "Forbidden";
            }
            if (result.error() == FsError::AlreadyExists) {
                return "Directory already exists";
            }
            return "Invalid Command";
        }

        return "";
    }

    if (command.name == "mkfile") {
        if (command.args.size() != 2U) {
            return "Invalid Command";
        }

        auto result = vfs_.mkfile(session, command.args[0], command.args[1]);
        if (result.isErr()) {
            if (result.error() == FsError::Forbidden) {
                return "Forbidden";
            }
            return "Invalid Command";
        }

        return "";
    }

    if (command.name == "adduser") {
        if (command.args.size() != 1U) {
            return "Invalid Command";
        }

        if (!permissions_.canAddUser(session)) {
            return "Invalid Command";
        }

        auto result = users_.addUser(session, command.args[0]);
        if (result.isErr()) {
            if (result.error() == FsError::AlreadyExists) {
                return "User " + command.args[0] + " already exists";
            }
            return "Invalid Command";
        }

        return "";
    }

    return "Invalid Command";
}

bool CommandHandlers::shouldExit() const { return should_exit_; }

}  // namespace bibifi
