#ifndef BIBIFI_COMMANDS_COMMAND_HANDLERS_H
#define BIBIFI_COMMANDS_COMMAND_HANDLERS_H

#include "bibifi/core/types.h"
#include "users/user_manager.h"
#include "vfs/permission_engine.h"
#include "vfs/vfs_service.h"

#include <string>

namespace bibifi {

class CommandHandlers {
public:
    std::string handle(const ParsedCommand& command, SessionContext& session);
    bool shouldExit() const;

private:
    bool should_exit_{false};
    VFSService vfs_;
    PermissionEngine permissions_;
    UserManager users_;
};

}  // namespace bibifi

#endif  // BIBIFI_COMMANDS_COMMAND_HANDLERS_H
