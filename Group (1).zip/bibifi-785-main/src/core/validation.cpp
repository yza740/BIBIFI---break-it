#include "bibifi/core/validation.h"

#include <regex>

namespace bibifi {

bool isValidUsername(const std::string& username) {
    static const std::regex kUsernamePattern("^[A-Za-z0-9_-]+$");
    return !username.empty() && std::regex_match(username, kUsernamePattern);
}

bool isValidUserId(const std::string& user_id) {
    static const std::regex kUserIdPattern("^[a-f0-9]{64}$");
    return std::regex_match(user_id, kUserIdPattern);
}

bool isValidBlobId(const std::string& blob_id) {
    static const std::regex kBlobIdPattern("^[a-f0-9]{32}$");
    return std::regex_match(blob_id, kBlobIdPattern);
}

bool isValidCapsuleId(const std::string& cap_id) {
    return isValidBlobId(cap_id);
}

}  // namespace bibifi
