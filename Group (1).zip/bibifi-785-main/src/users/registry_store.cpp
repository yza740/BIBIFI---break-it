#include "users/registry_store.h"
#include "bibifi/core/validation.h"
#include "crypto/encoding_utils.h"
#include "io/file_utils.h"

#include <filesystem>
#include <sstream>
#include <string_view>
#include <system_error>
#include <algorithm>

namespace bibifi {

namespace fs = std::filesystem;

namespace {

constexpr const char* kRegistryMagic = "BIBIFI_REG_V1";

std::vector<std::uint8_t> makeRegistryAad() {
    static constexpr std::string_view kAad = "bibifi-registry";
    return std::vector<std::uint8_t>(kAad.begin(), kAad.end());
}

std::vector<std::uint8_t> registrySignatureMessage(const std::vector<std::uint8_t>& iv,
                                                    const std::vector<std::uint8_t>& tag,
                                                    const std::vector<std::uint8_t>& ciphertext) {
    std::vector<std::uint8_t> msg;
    msg.reserve(32 + iv.size() + tag.size() + ciphertext.size());
    const std::string magic = std::string(kRegistryMagic) + "\n";
    msg.insert(msg.end(), magic.begin(), magic.end());
    msg.insert(msg.end(), iv.begin(), iv.end());
    msg.insert(msg.end(), tag.begin(), tag.end());
    msg.insert(msg.end(), ciphertext.begin(), ciphertext.end());
    return msg;
}

}  // namespace

const RegistryEntry* RegistryData::findByUsername(const std::string& username) const {
    for (const auto& entry : entries) {
        if (entry.username == username) {
            return &entry;
        }
    }
    return nullptr;
}

bool RegistryData::containsUsername(const std::string& username) const {
    return findByUsername(username) != nullptr;
}

RegistryStore::RegistryStore(std::string registry_path,
                             std::string slot_dir,
                             std::string root_public_key_path)
    : registry_path_(std::move(registry_path)),
      slot_dir_(std::move(slot_dir)),
      root_public_key_path_(std::move(root_public_key_path)) {}

bool RegistryStore::isValidUsername(const std::string& username) {
    return bibifi::isValidUsername(username);
}

bool RegistryStore::isValidUserId(const std::string& user_id) {
    return bibifi::isValidUserId(user_id);
}

Result<void> RegistryStore::bootstrapEmpty(const std::string& root_private_key_pem,
                                           const std::string& root_user_id) const {
    std::error_code ec;
    if (fs::exists(registry_path_, ec) && !ec) {
        return Result<void>::ok();
    }

    auto kreg = crypto_.randomBytes(32);
    if (kreg.isErr()) {
        return Result<void>::err(FsError::Internal, "registry keygen failed");
    }

    RegistryData data;
    data.entries.push_back({"admin", root_user_id});

    auto write = writeRegistry(root_private_key_pem, kreg.value(), data);
    if (write.isErr()) {
        return write;
    }

    // Root slot uses the fixed root public key path.
    return writeRegistrySlotForUser(kreg.value(), root_user_id, root_public_key_path_);
}

Result<std::vector<std::uint8_t>> RegistryStore::readRegistrySlotKey(const SessionContext& session) const {
    if (!isValidUserId(session.user_id)) {
        return Result<std::vector<std::uint8_t>>::err(FsError::InvalidKeyfile, "invalid user id");
    }

    const fs::path slot_path = fs::path(slot_dir_) / (session.user_id + ".slot");
    auto slot_bytes = readRegularFileBytesBounded(slot_path, 4096);
    if (slot_bytes.isErr()) {
        return Result<std::vector<std::uint8_t>>::err(FsError::InvalidKeyfile, "slot missing");
    }

    const std::string encoded(reinterpret_cast<const char*>(slot_bytes.value().data()), slot_bytes.value().size());
    const std::string trimmed = encoded.substr(0, encoded.find_first_of("\r\n"));
    auto wrapped = hexDecode(trimmed);
    if (wrapped.isErr()) {
        return Result<std::vector<std::uint8_t>>::err(FsError::InvalidKeyfile, "slot malformed");
    }

    auto key = crypto_.rsaUnwrapKeyWithPrivatePem(wrapped.value(), session.private_key_pem);
    if (key.isErr() || key.value().size() != 32U) {
        return Result<std::vector<std::uint8_t>>::err(FsError::InvalidKeyfile, "slot unwrap failed");
    }
    return Result<std::vector<std::uint8_t>>::ok(key.value());
}

Result<std::pair<RegistryData, std::vector<std::uint8_t>>> RegistryStore::loadWithKeyForSession(
    const SessionContext& session) const {
    auto kreg = readRegistrySlotKey(session);
    if (kreg.isErr()) {
        return Result<std::pair<RegistryData, std::vector<std::uint8_t>>>::err(kreg.error(), kreg.message());
    }

    auto file = readRegularFileBytesBounded(registry_path_, 256 * 1024);
    if (file.isErr()) {
        return Result<std::pair<RegistryData, std::vector<std::uint8_t>>>::err(FsError::InvalidKeyfile,
                                                                               "registry missing");
    }

    // Parse header lines.
    std::size_t offset = 0;
    auto nextLine = [&](std::string& out) -> bool {
        if (offset >= file.value().size()) {
            return false;
        }
        auto it = std::find(file.value().begin() + static_cast<std::ptrdiff_t>(offset),
                            file.value().end(),
                            static_cast<unsigned char>('\n'));
        if (it == file.value().end()) {
            return false;
        }
        const std::size_t end = static_cast<std::size_t>(std::distance(file.value().begin(), it));
        out.assign(reinterpret_cast<const char*>(file.value().data() + offset), end - offset);
        if (!out.empty() && out.back() == '\r') {
            out.pop_back();
        }
        offset = end + 1U;
        return true;
    };

    std::string magic;
    std::string iv_hex;
    std::string tag_hex;
    std::string sig_hex;
    if (!nextLine(magic) || !nextLine(iv_hex) || !nextLine(tag_hex) || !nextLine(sig_hex)) {
        return Result<std::pair<RegistryData, std::vector<std::uint8_t>>>::err(FsError::InvalidKeyfile,
                                                                               "registry truncated");
    }
    if (magic != kRegistryMagic) {
        return Result<std::pair<RegistryData, std::vector<std::uint8_t>>>::err(FsError::InvalidKeyfile,
                                                                               "registry magic mismatch");
    }

    auto iv = hexDecode(iv_hex);
    auto tag = hexDecode(tag_hex);
    auto sig = hexDecode(sig_hex);
    if (iv.isErr() || tag.isErr() || sig.isErr()) {
        return Result<std::pair<RegistryData, std::vector<std::uint8_t>>>::err(FsError::InvalidKeyfile,
                                                                               "registry header decode failed");
    }
    if (iv.value().size() != 12U || tag.value().size() != 16U) {
        return Result<std::pair<RegistryData, std::vector<std::uint8_t>>>::err(FsError::InvalidKeyfile,
                                                                               "registry header invalid");
    }

    const std::vector<std::uint8_t> ciphertext(file.value().begin() + static_cast<std::ptrdiff_t>(offset),
                                               file.value().end());

    // Verify signature with root key.
    const auto msg = registrySignatureMessage(iv.value(), tag.value(), ciphertext);
    auto verified = crypto_.verifyRsaPssSha256WithPublicKeyPath(msg, sig.value(), root_public_key_path_);
    if (verified.isErr() || !verified.value()) {
        return Result<std::pair<RegistryData, std::vector<std::uint8_t>>>::err(FsError::InvalidKeyfile,
                                                                               "registry signature invalid");
    }

    // Decrypt.
    AeadBlob blob;
    blob.iv = iv.value();
    blob.tag = tag.value();
    blob.ciphertext = ciphertext;
    const auto aad = makeRegistryAad();
    auto plaintext = crypto_.decryptAesGcm(blob, kreg.value(), aad);
    if (plaintext.isErr()) {
        return Result<std::pair<RegistryData, std::vector<std::uint8_t>>>::err(FsError::InvalidKeyfile,
                                                                               "registry decrypt failed");
    }

    const std::string payload(reinterpret_cast<const char*>(plaintext.value().data()), plaintext.value().size());
    RegistryData data;

    std::stringstream lines(payload);
    std::string line;
    while (std::getline(lines, line)) {
        if (line.empty()) {
            continue;
        }

        std::stringstream ss(line);
        std::string username;
        std::string user_id;
        if (!std::getline(ss, username, '\t') || !std::getline(ss, user_id, '\t')) {
            continue;
        }

        if (!isValidUsername(username) || !isValidUserId(user_id)) {
            continue;
        }

        if (!data.containsUsername(username)) {
            data.entries.push_back({username, user_id});
        }
    }

    return Result<std::pair<RegistryData, std::vector<std::uint8_t>>>::ok({data, kreg.value()});
}

Result<RegistryData> RegistryStore::loadForSession(const SessionContext& session) const {
    auto loaded = loadWithKeyForSession(session);
    if (loaded.isErr()) {
        return Result<RegistryData>::err(loaded.error(), loaded.message());
    }
    return Result<RegistryData>::ok(loaded.value().first);
}

Result<void> RegistryStore::writeRegistrySlotForUser(const std::vector<std::uint8_t>& registry_key,
                                                     const std::string& user_id,
                                                     const std::string& user_public_key_path) const {
    if (!isValidUserId(user_id)) {
        return Result<void>::err(FsError::Internal, "invalid user id");
    }

    auto wrapped = crypto_.rsaWrapKeyWithPublicKeyPath(registry_key, user_public_key_path);
    if (wrapped.isErr()) {
        return Result<void>::err(FsError::Internal, "slot wrap failed");
    }

    const std::string encoded = hexEncode(wrapped.value()) + "\n";
    std::vector<std::uint8_t> bytes(encoded.begin(), encoded.end());
    const fs::path slot_path = fs::path(slot_dir_) / (user_id + ".slot");
    return writeFileAtomic(slot_path, bytes);
}

Result<void> RegistryStore::writeRegistry(const std::string& root_private_key_pem,
                                          const std::vector<std::uint8_t>& registry_key,
                                          const RegistryData& data) const {
    std::string payload;
    for (const auto& entry : data.entries) {
        if (!isValidUsername(entry.username) || !isValidUserId(entry.user_id)) {
            continue;
        }
        payload += entry.username + "\t" + entry.user_id + "\n";
    }

    const std::vector<std::uint8_t> plaintext(payload.begin(), payload.end());
    const auto aad = makeRegistryAad();
    auto encrypted = crypto_.encryptAesGcm(plaintext, registry_key, aad);
    if (encrypted.isErr()) {
        return Result<void>::err(FsError::Internal, "registry encrypt failed");
    }

    const auto msg = registrySignatureMessage(encrypted.value().iv, encrypted.value().tag, encrypted.value().ciphertext);
    auto signature = crypto_.signRsaPssSha256WithPrivatePem(msg, root_private_key_pem);
    if (signature.isErr()) {
        return Result<void>::err(FsError::Internal, "registry sign failed");
    }

    std::string header;
    header.reserve(1024);
    header += kRegistryMagic;
    header.push_back('\n');
    header += hexEncode(encrypted.value().iv);
    header.push_back('\n');
    header += hexEncode(encrypted.value().tag);
    header.push_back('\n');
    header += hexEncode(signature.value());
    header.push_back('\n');

    std::vector<std::uint8_t> out;
    out.reserve(header.size() + encrypted.value().ciphertext.size());
    out.insert(out.end(), header.begin(), header.end());
    out.insert(out.end(), encrypted.value().ciphertext.begin(), encrypted.value().ciphertext.end());

    return writeFileAtomic(registry_path_, out);
}

Result<void> RegistryStore::addUser(const SessionContext& admin_session,
                                    const std::string& username,
                                    const std::string& user_id,
                                    const std::string& user_public_key_path) const {
    if (!admin_session.is_admin) {
        return Result<void>::err(FsError::Forbidden, "not admin");
    }
    if (!isValidUsername(username) || !isValidUserId(user_id)) {
        return Result<void>::err(FsError::InvalidCommand, "invalid user");
    }

    auto loaded = loadWithKeyForSession(admin_session);
    if (loaded.isErr()) {
        return Result<void>::err(loaded.error(), loaded.message());
    }

    const RegistryData previous = loaded.value().first;
    RegistryData data = previous;
    if (data.containsUsername(username)) {
        return Result<void>::err(FsError::AlreadyExists, "user exists");
    }
    data.entries.push_back({username, user_id});

    auto write = writeRegistry(admin_session.private_key_pem, loaded.value().second, data);
    if (write.isErr()) {
        return write;
    }

    auto slot_write = writeRegistrySlotForUser(loaded.value().second, user_id, user_public_key_path);
    if (slot_write.isErr()) {
        auto rollback = writeRegistry(admin_session.private_key_pem, loaded.value().second, previous);
        if (rollback.isErr()) {
            return Result<void>::err(FsError::Internal, "registry rollback failed");
        }
        return slot_write;
    }

    return Result<void>::ok();
}

Result<std::string> RegistryStore::resolveUserId(const SessionContext& session,
                                                 const std::string& username) const {
    auto data = loadForSession(session);
    if (data.isErr()) {
        return Result<std::string>::err(data.error(), data.message());
    }

    const RegistryEntry* entry = data.value().findByUsername(username);
    if (!entry) {
        return Result<std::string>::err(FsError::NotFound, "unknown user");
    }
    return Result<std::string>::ok(entry->user_id);
}

}  // namespace bibifi
