#include "users/user_manager.h"
#include "auth/keyfile_reader.h"
#include "bibifi/core/validation.h"
#include "crypto/openssl_utils.h"
#include "io/file_utils.h"

#include <cstdio>
#include <filesystem>
#include <memory>
#include <unistd.h>
#include <utility>

#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/bio.h>
#include <openssl/buffer.h>
#include <openssl/pem.h>
#include <openssl/x509.h>

namespace bibifi {

namespace fs = std::filesystem;

namespace {

class ScopedFd {
public:
    explicit ScopedFd(int fd) : fd_(fd) {}
    ~ScopedFd() {
        if (fd_ >= 0) {
            ::close(fd_);
        }
    }

    ScopedFd(const ScopedFd&) = delete;
    ScopedFd& operator=(const ScopedFd&) = delete;

private:
    int fd_;
};

void rollbackCreatedUserArtifacts(const std::string& username,
                                  const std::string& user_id,
                                  const std::string& public_keys_dir) {
    std::error_code ec;
    if (!user_id.empty()) {
        fs::remove(fs::path(public_keys_dir) / (user_id + ".pub"), ec);
        ec.clear();
    }
    if (!username.empty()) {
        fs::remove(username + "_keyfile", ec);
    }
}

Result<EvpPkeyPtr> generateRsaKey(int bits) {
    EVP_PKEY_CTX* ctx = EVP_PKEY_CTX_new_id(EVP_PKEY_RSA, nullptr);
    if (!ctx) {
        return Result<EvpPkeyPtr>::err(FsError::Internal, "keygen ctx alloc failed");
    }

    auto cleanup = [&]() { EVP_PKEY_CTX_free(ctx); };

    if (EVP_PKEY_keygen_init(ctx) <= 0) {
        cleanup();
        return Result<EvpPkeyPtr>::err(FsError::Internal, opensslErrorString());
    }
    if (EVP_PKEY_CTX_set_rsa_keygen_bits(ctx, bits) <= 0) {
        cleanup();
        return Result<EvpPkeyPtr>::err(FsError::Internal, opensslErrorString());
    }

    EVP_PKEY* pkey = nullptr;
    if (EVP_PKEY_keygen(ctx, &pkey) <= 0 || !pkey) {
        cleanup();
        return Result<EvpPkeyPtr>::err(FsError::Internal, opensslErrorString());
    }

    cleanup();
    return Result<EvpPkeyPtr>::ok(EvpPkeyPtr(pkey));
}

Result<std::vector<std::uint8_t>> publicKeyDer(EVP_PKEY* key) {
    if (!key) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, "missing key");
    }

    int len = i2d_PUBKEY(key, nullptr);
    if (len <= 0) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }

    std::vector<std::uint8_t> out(static_cast<std::size_t>(len));
    unsigned char* p = out.data();
    if (i2d_PUBKEY(key, &p) <= 0) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }

    return Result<std::vector<std::uint8_t>>::ok(out);
}

Result<std::vector<std::uint8_t>> pemEncodePublicKey(EVP_PKEY* key) {
    if (!key) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, "missing key");
    }

    std::unique_ptr<BIO, decltype(&BIO_free)> bio(BIO_new(BIO_s_mem()), &BIO_free);
    if (!bio) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, "bio alloc failed");
    }

    if (PEM_write_bio_PUBKEY(bio.get(), key) != 1) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }

    BUF_MEM* mem = nullptr;
    BIO_get_mem_ptr(bio.get(), &mem);
    if (!mem || !mem->data || mem->length == 0) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, "pem encode failed");
    }

    const auto* data = reinterpret_cast<const std::uint8_t*>(mem->data);
    return Result<std::vector<std::uint8_t>>::ok(
        std::vector<std::uint8_t>(data, data + mem->length));
}

Result<std::vector<std::uint8_t>> pemEncodePrivateKey(EVP_PKEY* key) {
    if (!key) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, "missing key");
    }

    std::unique_ptr<BIO, decltype(&BIO_free)> bio(BIO_new(BIO_s_mem()), &BIO_free);
    if (!bio) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, "bio alloc failed");
    }

    if (PEM_write_bio_PrivateKey(bio.get(), key, nullptr, nullptr, 0, nullptr, nullptr) != 1) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, opensslErrorString());
    }

    BUF_MEM* mem = nullptr;
    BIO_get_mem_ptr(bio.get(), &mem);
    if (!mem || !mem->data || mem->length == 0) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, "pem encode failed");
    }

    const auto* data = reinterpret_cast<const std::uint8_t*>(mem->data);
    return Result<std::vector<std::uint8_t>>::ok(
        std::vector<std::uint8_t>(data, data + mem->length));
}

Result<void> writePublicKeyPem(const std::string& path, EVP_PKEY* pkey) {
    auto payload = pemEncodePublicKey(pkey);
    if (payload.isErr()) {
        return Result<void>::err(payload.error(), payload.message());
    }
    return writeFileAtomic(path, payload.value());
}

Result<void> writeKeyfilePem(const std::string& path,
                             const std::string& username,
                             const std::string& root_user_id,
                             EVP_PKEY* pkey) {
    auto pem = pemEncodePrivateKey(pkey);
    if (pem.isErr()) {
        return Result<void>::err(pem.error(), pem.message());
    }

    std::string header = username;
    header.push_back('\n');
    if (!root_user_id.empty()) {
        header += "root=" + root_user_id + "\n";
    }

    std::vector<std::uint8_t> payload;
    payload.reserve(header.size() + pem.value().size());
    payload.insert(payload.end(), header.begin(), header.end());
    payload.insert(payload.end(), pem.value().begin(), pem.value().end());

    auto write = writeFileAtomic(path, payload);
    if (write.isErr()) {
        return write;
    }

    // Best-effort hardening: keyfiles contain private material.
    std::error_code ec;
    fs::permissions(path,
                    fs::perms::owner_read | fs::perms::owner_write,
                    fs::perm_options::replace,
                    ec);
    return Result<void>::ok();
}

Result<EvpPkeyPtr> loadPrivateKeyFromKeyfile(const std::string& keyfile_path, const std::string& expected_username) {
    constexpr std::uintmax_t kMaxKeyfileBytes = 64 * 1024;
    auto keyfile = readKeyfileParsed(keyfile_path, kMaxKeyfileBytes, expected_username);
    if (keyfile.isErr()) {
        return Result<EvpPkeyPtr>::err(keyfile.error(), keyfile.message());
    }
    const std::string& pem = keyfile.value().private_key_pem;

    return loadPrivateKeyFromPem(pem);
}

}  // namespace

UserManager::UserManager(std::string public_keys_dir, std::string root_public_key_path)
    : public_keys_dir_(std::move(public_keys_dir)),
      root_public_key_path_(std::move(root_public_key_path)),
      registry_("filesystem/registry.enc", "filesystem/keyslots/registry", root_public_key_path_) {}

bool UserManager::isValidUsername(const std::string& username) {
    return bibifi::isValidUsername(username);
}

Result<std::string> UserManager::readPrivatePemFromKeyfile(const std::string& keyfile_path) const {
    constexpr std::uintmax_t kMaxKeyfileBytes = 64 * 1024;
    auto keyfile = readKeyfileParsed(keyfile_path, kMaxKeyfileBytes);
    if (keyfile.isErr()) {
        return Result<std::string>::err(keyfile.error(), keyfile.message());
    }
    return Result<std::string>::ok(keyfile.value().private_key_pem);
}

Result<void> UserManager::ensureRootKeypair(std::string* out_root_user_id,
                                            std::string* out_root_private_key_pem) const {
    auto ensure_dir = [](const std::string& path) -> Result<void> {
        std::error_code dir_ec;
        fs::create_directories(path, dir_ec);
        if (dir_ec) {
            return Result<void>::err(FsError::Internal, "cannot create directories");
        }
        return Result<void>::ok();
    };

    auto dir_result = ensure_dir(public_keys_dir_);
    if (dir_result.isErr()) {
        return dir_result;
    }
    dir_result = ensure_dir("filesystem");
    if (dir_result.isErr()) {
        return dir_result;
    }
    dir_result = ensure_dir("filesystem/data");
    if (dir_result.isErr()) {
        return dir_result;
    }
    dir_result = ensure_dir("filesystem/meta");
    if (dir_result.isErr()) {
        return dir_result;
    }
    dir_result = ensure_dir("filesystem/shares");
    if (dir_result.isErr()) {
        return dir_result;
    }
    dir_result = ensure_dir("filesystem/locks");
    if (dir_result.isErr()) {
        return dir_result;
    }
    dir_result = ensure_dir("filesystem/keyslots/registry");
    if (dir_result.isErr()) {
        return dir_result;
    }

    const fs::path keyfile_path = "admin_keyfile";
    std::error_code ec;
    if (fs::exists(keyfile_path, ec) && !ec) {
        auto priv_key = loadPrivateKeyFromKeyfile(keyfile_path.string(), "admin");
        if (priv_key.isErr()) {
            return Result<void>::err(FsError::Internal, "admin_keyfile invalid");
        }

        auto der = publicKeyDer(priv_key.value().get());
        if (der.isErr()) {
            return Result<void>::err(FsError::Internal, "admin public key der failed");
        }
        auto uid = crypto_.sha256Hex(der.value());
        if (uid.isErr()) {
            return Result<void>::err(FsError::Internal, "admin user id failed");
        }

        // Ensure trust anchor and user-key files exist.
        if (!fs::exists(root_public_key_path_, ec) || ec) {
            auto root_write = writePublicKeyPem(root_public_key_path_, priv_key.value().get());
            if (root_write.isErr()) {
                return root_write;
            }
        }

        const fs::path by_id_path = fs::path(public_keys_dir_) / (uid.value() + ".pub");
        if (!fs::exists(by_id_path, ec) || ec) {
            auto pub_write = writePublicKeyPem(by_id_path.string(), priv_key.value().get());
            if (pub_write.isErr()) {
                return pub_write;
            }
        }

        auto pem = readPrivatePemFromKeyfile(keyfile_path.string());
        if (pem.isErr()) {
            return Result<void>::err(FsError::Internal, "admin pem read failed");
        }

        if (out_root_user_id) {
            *out_root_user_id = uid.value();
        }
        if (out_root_private_key_pem) {
            *out_root_private_key_pem = pem.value();
        }
        return Result<void>::ok();
    }

    // First-time bootstrap: generate root/admin keypair.
    auto keygen = generateRsaKey(2048);
    if (keygen.isErr()) {
        return Result<void>::err(keygen.error(), keygen.message());
    }

    auto der = publicKeyDer(keygen.value().get());
    if (der.isErr()) {
        return Result<void>::err(der.error(), der.message());
    }
    auto uid = crypto_.sha256Hex(der.value());
    if (uid.isErr()) {
        return Result<void>::err(uid.error(), uid.message());
    }

    auto pub_write = writePublicKeyPem((fs::path(public_keys_dir_) / (uid.value() + ".pub")).string(),
                                       keygen.value().get());
    if (pub_write.isErr()) {
        return pub_write;
    }

    auto root_write = writePublicKeyPem(root_public_key_path_, keygen.value().get());
    if (root_write.isErr()) {
        return root_write;
    }

    auto key_write = writeKeyfilePem(keyfile_path.string(), "admin", uid.value(), keygen.value().get());
    if (key_write.isErr()) {
        return key_write;
    }

    // Extract private pem for registry bootstrap.
    BIO* bio = BIO_new(BIO_s_mem());
    if (!bio) {
        return Result<void>::err(FsError::Internal, "bio alloc failed");
    }
    const int ok = PEM_write_bio_PrivateKey(bio, keygen.value().get(), nullptr, nullptr, 0, nullptr, nullptr);
    if (ok != 1) {
        BIO_free(bio);
        return Result<void>::err(FsError::Internal, "pem encode failed");
    }
    BUF_MEM* mem = nullptr;
    BIO_get_mem_ptr(bio, &mem);
    const std::string priv_pem(mem ? mem->data : "", mem ? mem->length : 0);
    BIO_free(bio);

    if (out_root_user_id) {
        *out_root_user_id = uid.value();
    }
    if (out_root_private_key_pem) {
        *out_root_private_key_pem = priv_pem;
    }
    return Result<void>::ok();
}

Result<void> UserManager::bootstrapRoot() const {
    std::string root_user_id;
    std::string root_private_pem;
    auto root = ensureRootKeypair(&root_user_id, &root_private_pem);
    if (root.isErr()) {
        return root;
    }

    return registry_.bootstrapEmpty(root_private_pem, root_user_id);
}

Result<void> UserManager::ensureKeypairAndPublicKey(const std::string& username,
                                                    std::string* out_user_id) const {
    if (!isValidUsername(username)) {
        return Result<void>::err(FsError::InvalidCommand, "invalid username");
    }

    std::error_code dir_ec;
    fs::create_directories(public_keys_dir_, dir_ec);
    if (dir_ec) {
        return Result<void>::err(FsError::Internal, "cannot create directories");
    }

    auto keygen = generateRsaKey(2048);
    if (keygen.isErr()) {
        return Result<void>::err(keygen.error(), keygen.message());
    }

    auto der = publicKeyDer(keygen.value().get());
    if (der.isErr()) {
        return Result<void>::err(der.error(), der.message());
    }
    auto uid = crypto_.sha256Hex(der.value());
    if (uid.isErr()) {
        return Result<void>::err(uid.error(), uid.message());
    }

    const fs::path pub_path = fs::path(public_keys_dir_) / (uid.value() + ".pub");
    auto pub_write = writePublicKeyPem(pub_path.string(), keygen.value().get());
    if (pub_write.isErr()) {
        return pub_write;
    }

    auto root_id = crypto_.userIdFromPublicKeyPath(root_public_key_path_);
    if (root_id.isErr()) {
        return Result<void>::err(FsError::Internal, "root key missing");
    }

    auto key_write = writeKeyfilePem(username + "_keyfile", username, root_id.value(), keygen.value().get());
    if (key_write.isErr()) {
        return key_write;
    }

    if (out_user_id) {
        *out_user_id = uid.value();
    }
    return Result<void>::ok();
}

Result<void> UserManager::addUser(const SessionContext& admin_session, const std::string& username) const {
    if (!admin_session.is_admin) {
        return Result<void>::err(FsError::Forbidden, "not admin");
    }

    if (!isValidUsername(username)) {
        return Result<void>::err(FsError::InvalidCommand, "invalid username");
    }

    auto registry_lock = acquireExclusiveLock(fs::path("filesystem/locks") / "registry.lock");
    if (registry_lock.isErr()) {
        return Result<void>::err(FsError::Internal, "registry lock failed");
    }
    ScopedFd registry_lock_fd(registry_lock.value());

    auto registry = registry_.loadForSession(admin_session);
    if (registry.isErr()) {
        return Result<void>::err(registry.error(), registry.message());
    }
    if (registry.value().containsUsername(username)) {
        return Result<void>::err(FsError::AlreadyExists, "user already exists");
    }

    std::string user_id;
    auto keypair = ensureKeypairAndPublicKey(username, &user_id);
    if (keypair.isErr()) {
        return keypair;
    }

    const std::string public_key_path = (fs::path(public_keys_dir_) / (user_id + ".pub")).string();
    auto add = registry_.addUser(admin_session, username, user_id, public_key_path);
    if (add.isErr()) {
        rollbackCreatedUserArtifacts(username, user_id, public_keys_dir_);
        return add;
    }
    return Result<void>::ok();
}

}  // namespace bibifi
