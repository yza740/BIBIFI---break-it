#ifndef BIBIFI_USERS_USER_MANAGER_H
#define BIBIFI_USERS_USER_MANAGER_H

#include "bibifi/core/result.h"
#include "bibifi/core/types.h"
#include "crypto/crypto_provider.h"
#include "users/registry_store.h"

#include <string>

namespace bibifi {

class UserManager {
public:
    UserManager(std::string public_keys_dir = "public_keys",
                std::string root_public_key_path = "public_keys/root.pub");

    Result<void> bootstrapRoot() const;
    Result<void> addUser(const SessionContext& admin_session, const std::string& username) const;

private:
    static bool isValidUsername(const std::string& username);
    Result<void> ensureKeypairAndPublicKey(const std::string& username,
                                           std::string* out_user_id = nullptr) const;
    Result<void> ensureRootKeypair(std::string* out_root_user_id = nullptr,
                                   std::string* out_root_private_key_pem = nullptr) const;
    Result<std::string> readPrivatePemFromKeyfile(const std::string& keyfile_path) const;

    std::string public_keys_dir_;
    std::string root_public_key_path_;
    RegistryStore registry_;
    CryptoProvider crypto_;
};

}  // namespace bibifi

#endif  // BIBIFI_USERS_USER_MANAGER_H
