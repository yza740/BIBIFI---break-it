#ifndef BIBIFI_USERS_REGISTRY_STORE_H
#define BIBIFI_USERS_REGISTRY_STORE_H

#include "bibifi/core/result.h"
#include "bibifi/core/types.h"
#include "crypto/crypto_provider.h"

#include <cstdint>
#include <string>
#include <utility>
#include <vector>

namespace bibifi {

struct RegistryEntry {
    std::string username;
    std::string user_id;
};

struct RegistryData {
    std::vector<RegistryEntry> entries;

    const RegistryEntry* findByUsername(const std::string& username) const;
    bool containsUsername(const std::string& username) const;
};

class RegistryStore {
public:
    RegistryStore(std::string registry_path = "filesystem/registry.enc",
                  std::string slot_dir = "filesystem/keyslots/registry",
                  std::string root_public_key_path = "public_keys/root.pub");

    Result<void> bootstrapEmpty(const std::string& root_private_key_pem,
                                const std::string& root_user_id) const;

    Result<RegistryData> loadForSession(const SessionContext& session) const;

    // Loads registry and returns both parsed data and the decrypted registry key.
    Result<std::pair<RegistryData, std::vector<std::uint8_t>>> loadWithKeyForSession(
        const SessionContext& session) const;

    Result<void> addUser(const SessionContext& admin_session,
                         const std::string& username,
                         const std::string& user_id,
                         const std::string& user_public_key_path) const;

    Result<std::string> resolveUserId(const SessionContext& session,
                                      const std::string& username) const;

    Result<void> writeRegistrySlotForUser(const std::vector<std::uint8_t>& registry_key,
                                          const std::string& user_id,
                                          const std::string& user_public_key_path) const;

private:
    Result<std::vector<std::uint8_t>> readRegistrySlotKey(const SessionContext& session) const;
    Result<void> writeRegistry(const std::string& root_private_key_pem,
                               const std::vector<std::uint8_t>& registry_key,
                               const RegistryData& data) const;

    static bool isValidUsername(const std::string& username);
    static bool isValidUserId(const std::string& user_id);

    std::string registry_path_;
    std::string slot_dir_;
    std::string root_public_key_path_;
    CryptoProvider crypto_;
};

}  // namespace bibifi

#endif  // BIBIFI_USERS_REGISTRY_STORE_H
