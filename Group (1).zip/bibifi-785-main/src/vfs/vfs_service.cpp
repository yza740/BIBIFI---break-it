#include "vfs/vfs_service.h"

#include "bibifi/core/validation.h"
#include "share/share_index.h"
#include "crypto/encoding_utils.h"
#include "io/file_utils.h"

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <filesystem>
#include <sstream>
#include <string_view>
#include <system_error>
#include <unistd.h>
#include <vector>

namespace bibifi {

namespace fs = std::filesystem;

namespace {

constexpr const char* kFileMagic = "BIBIFI_FILE_V2";
constexpr const char* kMetaMagic = "BIBIFI_META_V2";
constexpr const char* kShareMagic = "BIBIFI_SHARE_V1";
constexpr const char* kLocksRoot = "filesystem/locks";

constexpr std::uintmax_t kMaxPlaintextBytes = 1024 * 1024;     // 1 MiB
constexpr std::uintmax_t kMaxEncryptedRecordBytes = kMaxPlaintextBytes + 16 * 1024;
constexpr std::uintmax_t kMaxMetaRecordBytes = 512 * 1024;
constexpr std::size_t kPadBlock = 4096;

class ScopedFd {
public:
    explicit ScopedFd(int fd) : fd_(fd) {}
    ~ScopedFd() {
        if (fd_ >= 0) {
            ::close(fd_);
        }
    }

    ScopedFd(const ScopedFd&) = delete;
    ScopedFd& operator=(const ScopedFd&) = delete;

private:
    int fd_;
};

fs::path metadataLockPath(const std::string& user_id) {
    return fs::path(kLocksRoot) / (user_id + ".lock");
}

fs::path shareIndexLockPath(const std::string& user_id) {
    return fs::path(kLocksRoot) / ("share-index-" + user_id + ".lock");
}

bool isPrintableAscii(const std::string& text) {
    for (unsigned char c : text) {
        if (c < 32 || c > 126) {
            return false;
        }
    }
    return true;
}

Result<PublicKey> loadPublicKeyForUser(const CryptoProvider& crypto,
                                       const std::string& public_key_path,
                                       const std::string& expected_user_id) {
    if (!bibifi::isValidUserId(expected_user_id)) {
        return Result<PublicKey>::err(FsError::Internal, "invalid user id");
    }
    auto pub = crypto.loadPublicKeyFromPath(public_key_path);
    if (pub.isErr()) {
        return Result<PublicKey>::err(pub.error(), pub.message());
    }
    auto derived = crypto.userIdFromPublicKey(pub.value());
    if (derived.isErr()) {
        return Result<PublicKey>::err(FsError::Internal, "invalid public key");
    }
    if (derived.value() != expected_user_id) {
        return Result<PublicKey>::err(FsError::Forbidden, "public key mismatch");
    }
    return Result<PublicKey>::ok(std::move(pub.value()));
}

Result<PublicKey> loadRootPublicKey(const SessionContext& session,
                                    const CryptoProvider& crypto,
                                    const std::string& root_public_key_path) {
    auto root_pub = crypto.loadPublicKeyFromPath(root_public_key_path);
    if (root_pub.isErr()) {
        return Result<PublicKey>::err(root_pub.error(), root_pub.message());
    }
    if (!session.pinned_root_user_id.empty()) {
        if (!bibifi::isValidUserId(session.pinned_root_user_id)) {
            return Result<PublicKey>::err(FsError::Internal, "invalid root id");
        }
        auto derived = crypto.userIdFromPublicKey(root_pub.value());
        if (derived.isErr()) {
            return Result<PublicKey>::err(FsError::Internal, "invalid public key");
        }
        if (derived.value() != session.pinned_root_user_id) {
            return Result<PublicKey>::err(FsError::Forbidden, "root key mismatch");
        }
    }
    return Result<PublicKey>::ok(std::move(root_pub.value()));
}

Result<std::string> nextLine(const std::vector<std::uint8_t>& bytes, std::size_t& offset) {
    if (offset >= bytes.size()) {
        return Result<std::string>::err(FsError::Internal, "truncated");
    }

    const auto it = std::find(bytes.begin() + static_cast<std::ptrdiff_t>(offset),
                              bytes.end(),
                              static_cast<std::uint8_t>('\n'));
    if (it == bytes.end()) {
        return Result<std::string>::err(FsError::Internal, "truncated");
    }

    const std::size_t end = static_cast<std::size_t>(std::distance(bytes.begin(), it));
    std::string line(reinterpret_cast<const char*>(bytes.data() + offset), end - offset);
    if (!line.empty() && line.back() == '\r') {
        line.pop_back();
    }
    offset = end + 1U;
    return Result<std::string>::ok(line);
}

std::vector<std::uint8_t> makeAad(std::string_view label, const std::string& a, const std::string& b = "") {
    std::string aad(label);
    aad.push_back(':');
    aad += a;
    if (!b.empty()) {
        aad.push_back(':');
        aad += b;
    }
    return std::vector<std::uint8_t>(aad.begin(), aad.end());
}

std::vector<std::uint8_t> signatureMessage(std::string_view magic,
                                            std::string_view context,
                                            const std::vector<std::uint8_t>& iv,
                                            const std::vector<std::uint8_t>& tag,
                                            const std::vector<std::uint8_t>& wrapped1,
                                            const std::vector<std::uint8_t>& wrapped2,
                                            const std::vector<std::uint8_t>& ciphertext) {
    std::vector<std::uint8_t> msg;
    msg.reserve(magic.size() + 1 + context.size() + 1 + iv.size() + tag.size() + wrapped1.size() + wrapped2.size() +
                ciphertext.size());
    msg.insert(msg.end(), magic.begin(), magic.end());
    msg.push_back('\n');
    msg.insert(msg.end(), context.begin(), context.end());
    msg.push_back('\n');
    msg.insert(msg.end(), iv.begin(), iv.end());
    msg.insert(msg.end(), tag.begin(), tag.end());
    msg.insert(msg.end(), wrapped1.begin(), wrapped1.end());
    msg.insert(msg.end(), wrapped2.begin(), wrapped2.end());
    msg.insert(msg.end(), ciphertext.begin(), ciphertext.end());
    return msg;
}

struct RecordParseErrors {
    FsError error;
    const char* truncated;
    const char* magic;
    const char* decode;
    const char* invalid;
};

struct ShareParseErrors {
    FsError error;
    const char* truncated;
    const char* magic;
    const char* owner;
    const char* decode;
    const char* invalid;
};

struct EncryptedRecordHeader {
    std::vector<std::uint8_t> iv;
    std::vector<std::uint8_t> tag;
    std::vector<std::uint8_t> wrap_a;
    std::vector<std::uint8_t> wrap_b;
    std::vector<std::uint8_t> signature;
    std::vector<std::uint8_t> ciphertext;
};

struct ShareRecordHeader {
    std::string owner_id;
    EncryptedRecordHeader header;
};

Result<EncryptedRecordHeader> parseRecordHeader(const std::vector<std::uint8_t>& bytes,
                                                std::string_view expected_magic,
                                                const RecordParseErrors& errors) {
    std::size_t offset = 0;
    auto magic = nextLine(bytes, offset);
    auto iv_hex = nextLine(bytes, offset);
    auto tag_hex = nextLine(bytes, offset);
    auto wrap_a_hex = nextLine(bytes, offset);
    auto wrap_b_hex = nextLine(bytes, offset);
    auto sig_hex = nextLine(bytes, offset);
    if (magic.isErr() || iv_hex.isErr() || tag_hex.isErr() || wrap_a_hex.isErr() || wrap_b_hex.isErr() ||
        sig_hex.isErr()) {
        return Result<EncryptedRecordHeader>::err(errors.error, errors.truncated);
    }
    if (magic.value() != expected_magic) {
        return Result<EncryptedRecordHeader>::err(errors.error, errors.magic);
    }

    auto iv = hexDecode(iv_hex.value());
    auto tag = hexDecode(tag_hex.value());
    auto wrap_a = hexDecode(wrap_a_hex.value());
    auto wrap_b = hexDecode(wrap_b_hex.value());
    auto sig = hexDecode(sig_hex.value());
    if (iv.isErr() || tag.isErr() || wrap_a.isErr() || wrap_b.isErr() || sig.isErr()) {
        return Result<EncryptedRecordHeader>::err(errors.error, errors.decode);
    }
    if (iv.value().size() != 12U || tag.value().size() != 16U) {
        return Result<EncryptedRecordHeader>::err(errors.error, errors.invalid);
    }

    EncryptedRecordHeader header;
    header.iv = std::move(iv.value());
    header.tag = std::move(tag.value());
    header.wrap_a = std::move(wrap_a.value());
    header.wrap_b = std::move(wrap_b.value());
    header.signature = std::move(sig.value());
    header.ciphertext.assign(bytes.begin() + static_cast<std::ptrdiff_t>(offset), bytes.end());
    return Result<EncryptedRecordHeader>::ok(std::move(header));
}

Result<ShareRecordHeader> parseShareRecordHeader(const std::vector<std::uint8_t>& bytes,
                                                 std::string_view expected_magic,
                                                 const ShareParseErrors& errors) {
    std::size_t offset = 0;
    auto magic = nextLine(bytes, offset);
    auto owner_id = nextLine(bytes, offset);
    auto wrap_a_hex = nextLine(bytes, offset);
    auto wrap_b_hex = nextLine(bytes, offset);
    auto iv_hex = nextLine(bytes, offset);
    auto tag_hex = nextLine(bytes, offset);
    auto sig_hex = nextLine(bytes, offset);
    if (magic.isErr() || owner_id.isErr() || wrap_a_hex.isErr() || wrap_b_hex.isErr() || iv_hex.isErr() ||
        tag_hex.isErr() || sig_hex.isErr()) {
        return Result<ShareRecordHeader>::err(errors.error, errors.truncated);
    }
    if (magic.value() != expected_magic) {
        return Result<ShareRecordHeader>::err(errors.error, errors.magic);
    }
    if (!bibifi::isValidUserId(owner_id.value())) {
        return Result<ShareRecordHeader>::err(errors.error, errors.owner);
    }

    auto wrap_a = hexDecode(wrap_a_hex.value());
    auto wrap_b = hexDecode(wrap_b_hex.value());
    auto iv = hexDecode(iv_hex.value());
    auto tag = hexDecode(tag_hex.value());
    auto sig = hexDecode(sig_hex.value());
    if (wrap_a.isErr() || wrap_b.isErr() || iv.isErr() || tag.isErr() || sig.isErr()) {
        return Result<ShareRecordHeader>::err(errors.error, errors.decode);
    }
    if (iv.value().size() != 12U || tag.value().size() != 16U) {
        return Result<ShareRecordHeader>::err(errors.error, errors.invalid);
    }

    ShareRecordHeader header;
    header.owner_id = owner_id.value();
    header.header.iv = std::move(iv.value());
    header.header.tag = std::move(tag.value());
    header.header.wrap_a = std::move(wrap_a.value());
    header.header.wrap_b = std::move(wrap_b.value());
    header.header.signature = std::move(sig.value());
    header.header.ciphertext.assign(bytes.begin() + static_cast<std::ptrdiff_t>(offset), bytes.end());
    return Result<ShareRecordHeader>::ok(std::move(header));
}

bool verifyRecordSignature(const SessionContext& session,
                           const CryptoProvider& crypto,
                           const PublicKey& owner_pub,
                           const std::string& root_public_key_path,
                           std::string_view magic,
                           const std::string& context,
                           const EncryptedRecordHeader& header) {
    const auto msg = signatureMessage(magic,
                                      context,
                                      header.iv,
                                      header.tag,
                                      header.wrap_a,
                                      header.wrap_b,
                                      header.ciphertext);
    auto owner_ok = crypto.verifyRsaPssSha256WithPublicKey(msg, header.signature, owner_pub);
    if (owner_ok.isOk() && owner_ok.value()) {
        return true;
    }
    auto root_pub = loadRootPublicKey(session, crypto, root_public_key_path);
    if (root_pub.isOk()) {
        auto root_ok = crypto.verifyRsaPssSha256WithPublicKey(msg, header.signature, root_pub.value());
        return root_ok.isOk() && root_ok.value();
    }
    return false;
}

const RecordParseErrors kMissingRecordErrors{
    FsError::NotFound,
    "missing",
    "missing",
    "missing",
    "missing",
};

const RecordParseErrors kMetaRecordErrors{
    FsError::Internal,
    "meta truncated",
    "meta magic mismatch",
    "meta header decode failed",
    "meta header invalid",
};

const ShareParseErrors kShareRecordErrors{
    FsError::NotFound,
    "missing",
    "missing",
    "missing",
    "missing",
    "missing",
};

Result<std::vector<std::uint8_t>> padPayload(const std::vector<std::uint8_t>& contents,
                                             CryptoProvider& crypto) {
    if (contents.size() > kMaxPlaintextBytes) {
        return Result<std::vector<std::uint8_t>>::err(FsError::InvalidCommand, "too large");
    }

    // payload = [len_be32][contents][random padding] to block boundary.
    std::vector<std::uint8_t> out;
    out.reserve(4 + contents.size() + kPadBlock);
    const std::uint32_t len = static_cast<std::uint32_t>(contents.size());
    out.push_back(static_cast<std::uint8_t>((len >> 24) & 0xFF));
    out.push_back(static_cast<std::uint8_t>((len >> 16) & 0xFF));
    out.push_back(static_cast<std::uint8_t>((len >> 8) & 0xFF));
    out.push_back(static_cast<std::uint8_t>((len)&0xFF));
    out.insert(out.end(), contents.begin(), contents.end());

    const std::size_t remainder = out.size() % kPadBlock;
    const std::size_t pad_len = remainder == 0 ? 0 : (kPadBlock - remainder);
    if (pad_len > 0) {
        auto pad = crypto.randomBytes(pad_len);
        if (pad.isErr()) {
            return Result<std::vector<std::uint8_t>>::err(FsError::Internal, "padding failed");
        }
        out.insert(out.end(), pad.value().begin(), pad.value().end());
    }
    return Result<std::vector<std::uint8_t>>::ok(out);
}

Result<std::vector<std::uint8_t>> unpadPayload(const std::vector<std::uint8_t>& payload) {
    if (payload.size() < 4) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, "payload truncated");
    }
    const std::uint32_t len = (static_cast<std::uint32_t>(payload[0]) << 24) |
                              (static_cast<std::uint32_t>(payload[1]) << 16) |
                              (static_cast<std::uint32_t>(payload[2]) << 8) |
                              static_cast<std::uint32_t>(payload[3]);
    if (len > kMaxPlaintextBytes) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, "payload length invalid");
    }
    if (payload.size() < 4U + len) {
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, "payload truncated");
    }
    std::vector<std::uint8_t> contents(payload.begin() + 4, payload.begin() + 4 + len);
    return Result<std::vector<std::uint8_t>>::ok(contents);
}

Result<void> ensureAdminWriteAllowed(const SessionContext& session,
                                     const std::string& target_user_id) {
    if (session.is_admin && target_user_id != session.user_id) {
        return Result<void>::err(FsError::Forbidden, "forbidden");
    }
    return Result<void>::ok();
}

Result<std::vector<std::string>> readShareIndexFile(const fs::path& index_path) {
    auto bytes = readRegularFileBytesBounded(index_path, ShareIndexLimits::kMaxShareIndexBytes);
    if (bytes.isErr()) {
        return Result<std::vector<std::string>>::err(bytes.error(), bytes.message());
    }
    auto parsed = parseShareIndexLines(bytes.value());
    if (parsed.isErr()) {
        return Result<std::vector<std::string>>::err(parsed.error(), parsed.message());
    }
    return Result<std::vector<std::string>>::ok(parsed.value());
}

Result<void> writeShareIndexFile(const fs::path& index_path, const std::vector<std::string>& entries) {
    auto payload = encodeShareIndex(entries);
    if (payload.isErr()) {
        return Result<void>::err(payload.error(), payload.message());
    }
    return writeFileAtomic(index_path, payload.value());
}

}  // namespace

std::string VFSService::parentVirtualPath(const std::string& virtual_path) {
    if (virtual_path.empty() || virtual_path == "/") {
        return "/";
    }

    const std::size_t slash = virtual_path.find_last_of('/');
    if (slash == 0 || slash == std::string::npos) {
        return "/";
    }
    return virtual_path.substr(0, slash);
}

std::string VFSService::fileNameFromVirtualPath(const std::string& virtual_path) {
    return fs::path(virtual_path).filename().string();
}

bool VFSService::hasAllowedRootPrefix(const std::string& virtual_path) {
    if (virtual_path == "/") {
        return true;
    }
    return virtual_path == "/personal" || virtual_path == "/shared" || virtual_path.rfind("/personal/", 0) == 0 ||
           virtual_path.rfind("/shared/", 0) == 0;
}

bool VFSService::isValidUsername(const std::string& username) {
    return bibifi::isValidUsername(username);
}

VFSService::EffectiveUserPath VFSService::mapEffective(const SessionContext& session,
                                                       const std::string& virtual_path) const {
    EffectiveUserPath out{session.user_id, virtual_path};
    if (!session.is_admin) {
        return out;
    }

    const bool under_personal = (virtual_path == "/personal") || (virtual_path.rfind("/personal/", 0) == 0);
    const bool under_shared = (virtual_path == "/shared") || (virtual_path.rfind("/shared/", 0) == 0);
    if (!under_personal && !under_shared) {
        return out;
    }

    const std::string root = under_personal ? "/personal" : "/shared";
    if (virtual_path.size() <= root.size() + 1U) {
        return out;
    }

    const std::size_t start = root.size() + 1U;
    const std::size_t next_slash = virtual_path.find('/', start);
    const std::string candidate =
        next_slash == std::string::npos ? virtual_path.substr(start) : virtual_path.substr(start, next_slash - start);
    if (!isValidUsername(candidate)) {
        return out;
    }

    auto resolved = registry_.resolveUserId(session, candidate);
    if (resolved.isErr()) {
        return out;
    }

    out.user_id = resolved.value();
    const std::string remainder = next_slash == std::string::npos ? "" : virtual_path.substr(next_slash);
    out.per_user_virtual_path = root + remainder;
    return out;
}

Result<VFSService::UserMetadata> VFSService::loadMetadata(const SessionContext& session,
                                                          const std::string& user_id) const {
    UserMetadata meta;
    meta.directories.insert("/personal");

    const fs::path meta_path = fs::path(kMetaRoot) / (user_id + ".enc");
    std::error_code ec;
    if (!fs::exists(meta_path, ec) || ec) {
        return Result<UserMetadata>::ok(meta);
    }

    auto bytes = readRegularFileBytesBounded(meta_path, kMaxMetaRecordBytes);
    if (bytes.isErr()) {
        return Result<UserMetadata>::err(bytes.error(), bytes.message());
    }

    auto parsed = parseRecordHeader(bytes.value(), kMetaMagic, kMetaRecordErrors);
    if (parsed.isErr()) {
        return Result<UserMetadata>::err(parsed.error(), parsed.message());
    }
    const auto& header = parsed.value();
    const auto& owner_wrapped = header.wrap_a;
    const auto& root_wrapped = header.wrap_b;
    // Verify signature (owner or root).
    const std::string context = user_id;
    const std::string owner_pub_path = (fs::path(kPublicKeysDir) / (user_id + ".pub")).string();
    auto owner_pub = loadPublicKeyForUser(crypto_, owner_pub_path, user_id);
    if (owner_pub.isErr()) {
        return Result<UserMetadata>::err(FsError::Internal, "meta signature invalid");
    }
    if (!verifyRecordSignature(session, crypto_, owner_pub.value(), kRootPublicKeyPath, kMetaMagic, context, header)) {
        return Result<UserMetadata>::err(FsError::Internal, "meta signature invalid");
    }

    // Unwrap metadata key (owner for self, root for admin).
    const bool use_owner_wrap = (session.user_id == user_id);
    const bool use_root_wrap = (!use_owner_wrap && session.is_admin);
    if (!use_owner_wrap && !use_root_wrap) {
        return Result<UserMetadata>::err(FsError::Forbidden, "forbidden");
    }
    const auto& wrapped = use_owner_wrap ? owner_wrapped : root_wrapped;

    auto meta_key = crypto_.rsaUnwrapKeyWithPrivatePem(wrapped, session.private_key_pem);
    if (meta_key.isErr() || meta_key.value().size() != 32U) {
        return Result<UserMetadata>::err(FsError::Internal, "meta key unwrap failed");
    }

    AeadBlob blob;
    blob.iv = header.iv;
    blob.tag = header.tag;
    blob.ciphertext = header.ciphertext;
    const auto aad = makeAad("meta", user_id);
    auto plaintext = crypto_.decryptAesGcm(blob, meta_key.value(), aad);
    if (plaintext.isErr()) {
        return Result<UserMetadata>::err(FsError::Internal, "meta decrypt failed");
    }

    const std::string payload(reinterpret_cast<const char*>(plaintext.value().data()), plaintext.value().size());
    std::stringstream lines(payload);
    std::string line;
    while (std::getline(lines, line)) {
        if (line.empty()) {
            continue;
        }

        std::stringstream ss(line);
        std::string kind;
        std::getline(ss, kind, '\t');
        if (kind == "D") {
            std::string path;
            std::getline(ss, path, '\t');
            if (path == "/personal" || path.rfind("/personal/", 0) == 0) {
                meta.directories.insert(path);
            }
        } else if (kind == "F") {
            std::string path;
            std::string blob_id;
            std::getline(ss, path, '\t');
            std::getline(ss, blob_id, '\t');
            if (path.rfind("/personal/", 0) == 0 && isValidBlobId(blob_id)) {
                meta.files_to_blob[path] = blob_id;
            }
        }
    }

    return Result<UserMetadata>::ok(meta);
}

Result<void> VFSService::saveMetadata(const SessionContext& session,
                                      const std::string& user_id,
                                      const UserMetadata& metadata) const {
    // Serialize.
    std::string payload;
    for (const auto& dir : metadata.directories) {
        if (dir == "/personal" || dir.rfind("/personal/", 0) == 0) {
            payload += "D\t" + dir + "\n";
        }
    }
    for (const auto& kv : metadata.files_to_blob) {
        if (kv.first.rfind("/personal/", 0) == 0 && isValidBlobId(kv.second)) {
            payload += "F\t" + kv.first + "\t" + kv.second + "\n";
        }
    }

    // Encrypt under fresh metadata key to avoid relying on host state.
    auto meta_key = crypto_.randomBytes(32);
    if (meta_key.isErr()) {
        return Result<void>::err(FsError::Internal, "meta keygen failed");
    }

    const std::string owner_pub_path = (fs::path(kPublicKeysDir) / (user_id + ".pub")).string();
    auto owner_pub = loadPublicKeyForUser(crypto_, owner_pub_path, user_id);
    if (owner_pub.isErr()) {
        return Result<void>::err(FsError::Forbidden, "forbidden");
    }
    auto owner_wrapped = crypto_.rsaWrapKeyWithPublicKey(meta_key.value(), owner_pub.value());
    if (owner_wrapped.isErr()) {
        return Result<void>::err(FsError::Internal, "meta wrap failed");
    }
    auto root_pub = loadRootPublicKey(session, crypto_, kRootPublicKeyPath);
    if (root_pub.isErr()) {
        return Result<void>::err(FsError::Internal, "meta root wrap failed");
    }
    auto root_wrapped = crypto_.rsaWrapKeyWithPublicKey(meta_key.value(), root_pub.value());
    if (root_wrapped.isErr()) {
        return Result<void>::err(FsError::Internal, "meta root wrap failed");
    }

    const std::vector<std::uint8_t> plaintext(payload.begin(), payload.end());
    const auto aad = makeAad("meta", user_id);
    auto encrypted = crypto_.encryptAesGcm(plaintext, meta_key.value(), aad);
    if (encrypted.isErr()) {
        return Result<void>::err(FsError::Internal, "meta encrypt failed");
    }

    const std::string context = user_id;
    const auto msg = signatureMessage(kMetaMagic,
                                      context,
                                      encrypted.value().iv,
                                      encrypted.value().tag,
                                      owner_wrapped.value(),
                                      root_wrapped.value(),
                                      encrypted.value().ciphertext);
    auto sig = crypto_.signRsaPssSha256WithPrivatePem(msg, session.private_key_pem);
    if (sig.isErr()) {
        return Result<void>::err(FsError::Internal, "meta sign failed");
    }

    std::string header;
    header.reserve(2048);
    header += kMetaMagic;
    header.push_back('\n');
    header += hexEncode(encrypted.value().iv);
    header.push_back('\n');
    header += hexEncode(encrypted.value().tag);
    header.push_back('\n');
    header += hexEncode(owner_wrapped.value());
    header.push_back('\n');
    header += hexEncode(root_wrapped.value());
    header.push_back('\n');
    header += hexEncode(sig.value());
    header.push_back('\n');

    std::vector<std::uint8_t> out;
    out.reserve(header.size() + encrypted.value().ciphertext.size());
    out.insert(out.end(), header.begin(), header.end());
    out.insert(out.end(), encrypted.value().ciphertext.begin(), encrypted.value().ciphertext.end());

    const fs::path meta_path = fs::path(kMetaRoot) / (user_id + ".enc");
    return writeFileAtomic(meta_path, out);
}

bool VFSService::directoryExists(const SessionContext& session, const std::string& virtual_path) const {
    if (virtual_path == "/") {
        return true;
    }

    const EffectiveUserPath eff = mapEffective(session, virtual_path);
    if (!hasAllowedRootPrefix(eff.per_user_virtual_path)) {
        return false;
    }

    if (eff.per_user_virtual_path == "/personal" || eff.per_user_virtual_path == "/shared") {
        return true;
    }
    if (eff.per_user_virtual_path.rfind("/shared/", 0) == 0) {
        // Shared is flat (files only).
        return false;
    }

    auto meta = loadMetadata(session, eff.user_id);
    if (meta.isErr()) {
        return false;
    }

    return meta.value().directories.find(eff.per_user_virtual_path) != meta.value().directories.end();
}

Result<std::string> VFSService::pwd(const SessionContext& session) const {
    return Result<std::string>::ok(session.cwd_virtual);
}

Result<std::vector<ListEntry>> VFSService::ls(const SessionContext& session) const {
    if (!directoryExists(session, session.cwd_virtual)) {
        return Result<std::vector<ListEntry>>::err(FsError::NotFound, "directory missing");
    }

    std::vector<ListEntry> entries{{true, "."}, {true, ".."}};

    if (session.cwd_virtual == "/") {
        entries.push_back({true, "personal"});
        entries.push_back({true, "shared"});
        return Result<std::vector<ListEntry>>::ok(entries);
    }

    const EffectiveUserPath eff = mapEffective(session, session.cwd_virtual);
    std::vector<ListEntry> directories;
    std::vector<ListEntry> files;
    std::set<std::string> seen;

    if (session.is_admin && session.cwd_virtual == "/personal") {
        auto registry = registry_.loadForSession(session);
        if (registry.isOk()) {
            for (const auto& entry : registry.value().entries) {
                if (!isValidUsername(entry.username)) {
                    continue;
                }
                if (entry.username == session.username) {
                    continue;
                }
                if (seen.insert(entry.username).second) {
                    directories.push_back({true, entry.username});
                }
            }
        }
    }

    if (eff.per_user_virtual_path == "/shared") {
        auto shares = listSharedFiles(session, eff.user_id);
        if (shares.isOk()) {
            std::map<std::string, std::string> owner_by_alias;
            std::set<std::string> ambiguous_aliases;
            for (const auto& s : shares.value()) {
                const auto inserted = owner_by_alias.emplace(s.alias, s.owner_user_id);
                if (!inserted.second && inserted.first->second != s.owner_user_id) {
                    ambiguous_aliases.insert(s.alias);
                }
            }
            for (const auto& kv : owner_by_alias) {
                if (ambiguous_aliases.find(kv.first) == ambiguous_aliases.end()) {
                    entries.push_back({false, kv.first});
                }
            }
        }
        return Result<std::vector<ListEntry>>::ok(entries);
    }

    auto meta = loadMetadata(session, eff.user_id);
    if (meta.isErr()) {
        return Result<std::vector<ListEntry>>::err(FsError::Internal, "meta load failed");
    }

    const std::string parent = eff.per_user_virtual_path;
    for (const auto& dir : meta.value().directories) {
        if (dir == parent) {
            continue;
        }
        if (parentVirtualPath(dir) == parent) {
            const std::string name = fileNameFromVirtualPath(dir);
            if (!name.empty() && seen.insert(name).second) {
                directories.push_back({true, name});
            }
        }
    }

    for (const auto& kv : meta.value().files_to_blob) {
        if (parentVirtualPath(kv.first) == parent) {
            const std::string name = fileNameFromVirtualPath(kv.first);
            if (!name.empty() && seen.insert(name).second) {
                files.push_back({false, name});
            }
        }
    }

    auto by_name = [](const ListEntry& lhs, const ListEntry& rhs) { return lhs.name < rhs.name; };
    std::sort(directories.begin(), directories.end(), by_name);
    std::sort(files.begin(), files.end(), by_name);
    entries.insert(entries.end(), directories.begin(), directories.end());
    entries.insert(entries.end(), files.begin(), files.end());
    return Result<std::vector<ListEntry>>::ok(entries);
}

Result<std::string> VFSService::readPersonalFile(const SessionContext& session,
                                                 const std::string& owner_user_id,
                                                 const std::string& blob_id,
                                                 const std::vector<std::uint8_t>* override_file_key) const {
    if (!isValidBlobId(blob_id)) {
        return Result<std::string>::err(FsError::NotFound, "missing");
    }

    const fs::path blob_path = fs::path(kDataRoot) / blob_id;
    auto bytes = readRegularFileBytesBounded(blob_path, kMaxEncryptedRecordBytes);
    if (bytes.isErr()) {
        return Result<std::string>::err(FsError::NotFound, "missing");
    }

    auto parsed = parseRecordHeader(bytes.value(), kFileMagic, kMissingRecordErrors);
    if (parsed.isErr()) {
        return Result<std::string>::err(parsed.error(), parsed.message());
    }
    const auto& header = parsed.value();

    const std::string context = owner_user_id + ":" + blob_id;
    const std::string owner_pub_path = (fs::path(kPublicKeysDir) / (owner_user_id + ".pub")).string();
    auto owner_pub = loadPublicKeyForUser(crypto_, owner_pub_path, owner_user_id);
    if (owner_pub.isErr()) {
        return Result<std::string>::err(FsError::NotFound, "missing");
    }
    if (!verifyRecordSignature(session, crypto_, owner_pub.value(), kRootPublicKeyPath, kFileMagic, context, header)) {
        return Result<std::string>::err(FsError::NotFound, "missing");
    }

    std::vector<std::uint8_t> file_key;
    if (override_file_key != nullptr) {
        file_key = *override_file_key;
    } else {
        const bool use_owner_wrap = (session.user_id == owner_user_id);
        const bool use_root_wrap = (!use_owner_wrap && session.is_admin);
        if (!use_owner_wrap && !use_root_wrap) {
            return Result<std::string>::err(FsError::NotFound, "missing");
        }
        const auto& wrapped = use_owner_wrap ? header.wrap_a : header.wrap_b;
        auto unwrapped = crypto_.rsaUnwrapKeyWithPrivatePem(wrapped, session.private_key_pem);
        if (unwrapped.isErr() || unwrapped.value().size() != 32U) {
            return Result<std::string>::err(FsError::NotFound, "missing");
        }
        file_key = std::move(unwrapped.value());
    }

    AeadBlob blob;
    blob.iv = header.iv;
    blob.tag = header.tag;
    blob.ciphertext = header.ciphertext;
    const auto aad = makeAad("file", owner_user_id, blob_id);
    auto decrypted = crypto_.decryptAesGcm(blob, file_key, aad);
    if (decrypted.isErr()) {
        return Result<std::string>::err(FsError::NotFound, "missing");
    }

    auto contents = unpadPayload(decrypted.value());
    if (contents.isErr()) {
        return Result<std::string>::err(FsError::NotFound, "missing");
    }

    std::string plaintext(reinterpret_cast<const char*>(contents.value().data()), contents.value().size());
    if (!isPrintableAscii(plaintext)) {
        return Result<std::string>::err(FsError::NotFound, "missing");
    }
    return Result<std::string>::ok(plaintext);
}

Result<std::vector<VFSService::ShareViewEntry>> VFSService::listSharedFiles(const SessionContext& session,
                                                                            const std::string& recipient_user_id) const {
    const fs::path dir = fs::path(kSharesRoot) / recipient_user_id;
    std::error_code ec;
    if (!fs::exists(dir, ec) || ec || !fs::is_directory(dir, ec)) {
        return Result<std::vector<ShareViewEntry>>::ok({});
    }

    auto index_lock = acquireExclusiveLock(shareIndexLockPath(recipient_user_id));
    if (index_lock.isErr()) {
        return Result<std::vector<ShareViewEntry>>::ok({});
    }
    ScopedFd index_lock_fd(index_lock.value());

    auto scanned = scanShareDirForCaps(dir);
    if (scanned.isErr()) {
        return Result<std::vector<ShareViewEntry>>::ok({});
    }
    std::vector<std::string> cap_ids = std::move(scanned.value());

    const fs::path index_path = shareIndexPath(recipient_user_id, kShareIndexRoot);
    auto index = readShareIndexFile(index_path);
    if (index.isErr() || index.value() != cap_ids) {
        // Directory scan is authoritative; repair index opportunistically.
        (void)writeShareIndexFile(index_path, cap_ids);
    }

    std::vector<ShareViewEntry> out;
    for (const auto& cap_id : cap_ids) {
        const fs::path path = dir / (cap_id + ".cap");
        auto bytes = readRegularFileBytesBounded(path, ShareIndexLimits::kMaxShareRecordBytes);
        if (bytes.isErr()) {
            continue;
        }

        auto parsed = parseShareRecordHeader(bytes.value(), kShareMagic, kShareRecordErrors);
        if (parsed.isErr()) {
            continue;
        }
        const auto& header = parsed.value().header;
        const auto& owner_id = parsed.value().owner_id;

        const std::string context = owner_id + ":" + recipient_user_id;
        const std::string owner_pub_path = (fs::path(kPublicKeysDir) / (owner_id + ".pub")).string();
        auto owner_pub = loadPublicKeyForUser(crypto_, owner_pub_path, owner_id);
        if (owner_pub.isErr()) {
            continue;
        }
        if (!verifyRecordSignature(session, crypto_, owner_pub.value(), kRootPublicKeyPath, kShareMagic, context, header)) {
            continue;
        }

        std::vector<std::uint8_t> cap_key_bytes;
        auto cap_key = crypto_.rsaUnwrapKeyWithPrivatePem(header.wrap_a, session.private_key_pem);
        if (cap_key.isOk() && cap_key.value().size() == 32U) {
            cap_key_bytes = cap_key.value();
        } else if (session.is_admin) {
            auto root_key = crypto_.rsaUnwrapKeyWithPrivatePem(header.wrap_b, session.private_key_pem);
            if (root_key.isOk() && root_key.value().size() == 32U) {
                cap_key_bytes = root_key.value();
            } else {
                continue;
            }
        } else {
            continue;
        }

        AeadBlob blob;
        blob.iv = header.iv;
        blob.tag = header.tag;
        blob.ciphertext = header.ciphertext;
        const auto aad = makeAad("share", owner_id, recipient_user_id);
        auto decrypted = crypto_.decryptAesGcm(blob, cap_key_bytes, aad);
        if (decrypted.isErr()) {
            continue;
        }

        const std::string payload(reinterpret_cast<const char*>(decrypted.value().data()), decrypted.value().size());
        std::stringstream ss(payload);
        std::string alias;
        std::string blob_id;
        std::string file_key_hex;
        std::getline(ss, alias);
        std::getline(ss, blob_id);
        std::getline(ss, file_key_hex);

        if (alias.empty() || alias.find('/') != std::string::npos || !isPrintableAscii(alias)) {
            continue;
        }
        if (!isValidBlobId(blob_id)) {
            continue;
        }
        auto file_key = hexDecode(file_key_hex);
        if (file_key.isErr() || file_key.value().size() != 32U) {
            continue;
        }

        out.push_back({alias, owner_id, blob_id, file_key.value()});
    }

    return Result<std::vector<ShareViewEntry>>::ok(out);
}

Result<VFSService::ShareViewEntry> VFSService::findSharedFile(const SessionContext& session,
                                                              const std::string& recipient_user_id,
                                                              const std::string& alias) const {
    auto shares = listSharedFiles(session, recipient_user_id);
    if (shares.isErr()) {
        return Result<ShareViewEntry>::err(FsError::NotFound, "missing");
    }
    // Fail closed for ambiguous aliases.
    std::string owner_user_id;
    ShareViewEntry found;
    bool any = false;
    for (const auto& entry : shares.value()) {
        if (entry.alias == alias) {
            if (any && owner_user_id != entry.owner_user_id) {
                return Result<ShareViewEntry>::err(FsError::NotFound, "missing");
            }
            owner_user_id = entry.owner_user_id;
            found = entry;
            any = true;
        }
    }
    if (!any) {
        return Result<ShareViewEntry>::err(FsError::NotFound, "missing");
    }
    return Result<ShareViewEntry>::ok(found);
}

Result<std::string> VFSService::cat(const SessionContext& session, const std::string& filename) const {
    if (filename.empty()) {
        return Result<std::string>::err(FsError::InvalidCommand, "missing filename");
    }

    const std::string target_display = resolver_.resolve(session.cwd_virtual, filename);
    const EffectiveUserPath eff = mapEffective(session, target_display);

    if (!hasAllowedRootPrefix(eff.per_user_virtual_path) || eff.per_user_virtual_path == "/") {
        return Result<std::string>::err(FsError::NotFound, "missing");
    }

    if (eff.per_user_virtual_path.rfind("/shared/", 0) == 0) {
        const std::string alias = eff.per_user_virtual_path.substr(std::string("/shared/").size());
        if (alias.empty() || alias.find('/') != std::string::npos) {
            return Result<std::string>::err(FsError::NotFound, "missing");
        }
        auto entry = findSharedFile(session, eff.user_id, alias);
        if (entry.isErr()) {
            return Result<std::string>::err(FsError::NotFound, "missing");
        }
        return readPersonalFile(session, entry.value().owner_user_id, entry.value().blob_id, &entry.value().file_key);
    }

    auto meta = loadMetadata(session, eff.user_id);
    if (meta.isErr()) {
        return Result<std::string>::err(FsError::NotFound, "missing");
    }

    const auto it = meta.value().files_to_blob.find(eff.per_user_virtual_path);
    if (it == meta.value().files_to_blob.end()) {
        return Result<std::string>::err(FsError::NotFound, "missing");
    }

    return readPersonalFile(session, eff.user_id, it->second, nullptr);
}

Result<void> VFSService::mkdir(const SessionContext& session, const std::string& directory_name) {
    if (directory_name.empty() || directory_name.find('/') != std::string::npos) {
        return Result<void>::err(FsError::InvalidCommand, "invalid directory");
    }

    const std::string target_display = resolver_.resolve(session.cwd_virtual, directory_name);
    const EffectiveUserPath eff = mapEffective(session, target_display);
    auto admin_guard = ensureAdminWriteAllowed(session, eff.user_id);
    if (admin_guard.isErr()) {
        return admin_guard;
    }

    if (!hasAllowedRootPrefix(eff.per_user_virtual_path) || eff.per_user_virtual_path == "/") {
        return Result<void>::err(FsError::Forbidden, "forbidden");
    }

    const std::string parent_display = parentVirtualPath(target_display);
    if (!permissions_.canCreatePath(session, parent_display)) {
        return Result<void>::err(FsError::Forbidden, "forbidden");
    }

    if (eff.per_user_virtual_path == "/shared" || eff.per_user_virtual_path.rfind("/shared/", 0) == 0) {
        return Result<void>::err(FsError::Forbidden, "forbidden");
    }

    auto metadata_lock = acquireExclusiveLock(metadataLockPath(eff.user_id));
    if (metadata_lock.isErr()) {
        return Result<void>::err(FsError::Internal, "meta lock failed");
    }
    ScopedFd metadata_lock_fd(metadata_lock.value());

    auto meta = loadMetadata(session, eff.user_id);
    if (meta.isErr()) {
        return Result<void>::err(FsError::Internal, "meta load failed");
    }

    if (meta.value().files_to_blob.find(eff.per_user_virtual_path) != meta.value().files_to_blob.end()) {
        return Result<void>::err(FsError::AlreadyExists, "name exists as file");
    }

    if (meta.value().directories.find(eff.per_user_virtual_path) != meta.value().directories.end()) {
        return Result<void>::err(FsError::AlreadyExists, "already exists");
    }

    const std::string parent_path = parentVirtualPath(eff.per_user_virtual_path);
    if (meta.value().directories.find(parent_path) == meta.value().directories.end()) {
        return Result<void>::err(FsError::NotFound, "parent missing");
    }

    meta.value().directories.insert(eff.per_user_virtual_path);
    return saveMetadata(session, eff.user_id, meta.value());
}

Result<void> VFSService::mkfile(const SessionContext& session,
                                const std::string& filename,
                                const std::string& contents) {
    if (filename.empty() || filename.find('/') != std::string::npos) {
        return Result<void>::err(FsError::InvalidCommand, "invalid filename");
    }
    // mkfile requires a non-empty contents argument; empty payloads are invalid.
    if (contents.empty() || !isPrintableAscii(contents) ||
        contents.size() > static_cast<std::size_t>(kMaxPlaintextBytes)) {
        return Result<void>::err(FsError::InvalidCommand, "invalid contents");
    }

    const std::string target_display = resolver_.resolve(session.cwd_virtual, filename);
    const EffectiveUserPath eff = mapEffective(session, target_display);
    auto admin_guard = ensureAdminWriteAllowed(session, eff.user_id);
    if (admin_guard.isErr()) {
        return admin_guard;
    }
    const std::string owner_pub_path = (fs::path(kPublicKeysDir) / (eff.user_id + ".pub")).string();
    auto owner_pub = loadPublicKeyForUser(crypto_, owner_pub_path, eff.user_id);
    if (owner_pub.isErr()) {
        return Result<void>::err(FsError::Forbidden, "forbidden");
    }

    if (!hasAllowedRootPrefix(eff.per_user_virtual_path) || eff.per_user_virtual_path == "/") {
        return Result<void>::err(FsError::Forbidden, "forbidden");
    }

    const std::string parent_display = parentVirtualPath(target_display);
    if (!permissions_.canCreatePath(session, parent_display)) {
        return Result<void>::err(FsError::Forbidden, "forbidden");
    }

    if (eff.per_user_virtual_path == "/shared" || eff.per_user_virtual_path.rfind("/shared/", 0) == 0) {
        return Result<void>::err(FsError::Forbidden, "forbidden");
    }

    auto metadata_lock = acquireExclusiveLock(metadataLockPath(eff.user_id));
    if (metadata_lock.isErr()) {
        return Result<void>::err(FsError::Internal, "meta lock failed");
    }
    ScopedFd metadata_lock_fd(metadata_lock.value());

    auto meta = loadMetadata(session, eff.user_id);
    if (meta.isErr()) {
        return Result<void>::err(FsError::Internal, "meta load failed");
    }

    if (meta.value().directories.find(eff.per_user_virtual_path) != meta.value().directories.end()) {
        return Result<void>::err(FsError::InvalidCommand, "name exists as directory");
    }

    const std::string parent_path = parentVirtualPath(eff.per_user_virtual_path);
    if (meta.value().directories.find(parent_path) == meta.value().directories.end()) {
        return Result<void>::err(FsError::NotFound, "parent missing");
    }

    std::string blob_id;
    std::vector<std::uint8_t> file_key;
    std::vector<std::uint8_t> owner_wrapped;
    std::vector<std::uint8_t> root_wrapped;

    auto existing = meta.value().files_to_blob.find(eff.per_user_virtual_path);
    bool reuse_existing_key = false;
    if (existing != meta.value().files_to_blob.end()) {
        blob_id = existing->second;

        // Load existing blob; reuse key only if the record signature verifies.
        if (isValidBlobId(blob_id)) {
            const fs::path blob_path = fs::path(kDataRoot) / blob_id;
            auto bytes = readRegularFileBytesBounded(blob_path, kMaxEncryptedRecordBytes);
            if (bytes.isOk()) {
                auto parsed = parseRecordHeader(bytes.value(), kFileMagic, kMissingRecordErrors);
                if (parsed.isOk()) {
                    const auto& header = parsed.value();
                    const std::string context = eff.user_id + ":" + blob_id;
                    if (verifyRecordSignature(session, crypto_, owner_pub.value(), kRootPublicKeyPath, kFileMagic, context, header)) {
                        owner_wrapped = header.wrap_a;
                        root_wrapped = header.wrap_b;

                        const bool use_owner_wrap = (session.user_id == eff.user_id);
                        const bool use_root_wrap = (!use_owner_wrap && session.is_admin);
                        if (use_owner_wrap || use_root_wrap) {
                            const auto& wrapped = use_owner_wrap ? owner_wrapped : root_wrapped;
                            auto unwrapped = crypto_.rsaUnwrapKeyWithPrivatePem(wrapped, session.private_key_pem);
                            if (unwrapped.isOk() && unwrapped.value().size() == 32U) {
                                file_key = std::move(unwrapped.value());
                                reuse_existing_key = true;
                            }
                        }
                    }
                }
            }
        }
    }

    if (!reuse_existing_key) {
        // Treat missing/corrupt existing records as a fresh file: rotate to a new key and rewrap.
        if (blob_id.empty() || !isValidBlobId(blob_id)) {
            auto rand = crypto_.randomBytes(16);
            if (rand.isErr()) {
                return Result<void>::err(FsError::Internal, "blob id gen failed");
            }
            blob_id = hexEncode(rand.value());
        }

        auto key = crypto_.randomBytes(32);
        if (key.isErr()) {
            return Result<void>::err(FsError::Internal, "file keygen failed");
        }
        file_key = std::move(key.value());

        auto owner_wrap = crypto_.rsaWrapKeyWithPublicKey(file_key, owner_pub.value());
        if (owner_wrap.isErr()) {
            return Result<void>::err(FsError::Internal, "file wrap failed");
        }
        owner_wrapped = std::move(owner_wrap.value());

        auto root_pub = loadRootPublicKey(session, crypto_, kRootPublicKeyPath);
        if (root_pub.isErr()) {
            return Result<void>::err(FsError::Internal, "file root wrap failed");
        }
        auto root_wrap = crypto_.rsaWrapKeyWithPublicKey(file_key, root_pub.value());
        if (root_wrap.isErr()) {
            return Result<void>::err(FsError::Internal, "file root wrap failed");
        }
        root_wrapped = std::move(root_wrap.value());
    }

    // Encrypt payload (padded).
    const std::vector<std::uint8_t> content_bytes(contents.begin(), contents.end());
    auto payload = padPayload(content_bytes, crypto_);
    if (payload.isErr()) {
        return Result<void>::err(FsError::Internal, "payload build failed");
    }

    const auto aad = makeAad("file", eff.user_id, blob_id);
    auto encrypted = crypto_.encryptAesGcm(payload.value(), file_key, aad);
    if (encrypted.isErr()) {
        return Result<void>::err(FsError::Internal, "encrypt failed");
    }

    const std::string context = eff.user_id + ":" + blob_id;
    const auto msg = signatureMessage(kFileMagic,
                                      context,
                                      encrypted.value().iv,
                                      encrypted.value().tag,
                                      owner_wrapped,
                                      root_wrapped,
                                      encrypted.value().ciphertext);
    auto sig = crypto_.signRsaPssSha256WithPrivatePem(msg, session.private_key_pem);
    if (sig.isErr()) {
        return Result<void>::err(FsError::Internal, "sign failed");
    }

    std::string header;
    header.reserve(4096);
    header += kFileMagic;
    header.push_back('\n');
    header += hexEncode(encrypted.value().iv);
    header.push_back('\n');
    header += hexEncode(encrypted.value().tag);
    header.push_back('\n');
    header += hexEncode(owner_wrapped);
    header.push_back('\n');
    header += hexEncode(root_wrapped);
    header.push_back('\n');
    header += hexEncode(sig.value());
    header.push_back('\n');

    std::vector<std::uint8_t> encoded;
    encoded.reserve(header.size() + encrypted.value().ciphertext.size());
    encoded.insert(encoded.end(), header.begin(), header.end());
    encoded.insert(encoded.end(), encrypted.value().ciphertext.begin(), encrypted.value().ciphertext.end());

    const fs::path blob_path = fs::path(kDataRoot) / blob_id;
    auto write = writeFileAtomic(blob_path, encoded);
    if (write.isErr()) {
        return write;
    }

    meta.value().files_to_blob[eff.per_user_virtual_path] = blob_id;
    return saveMetadata(session, eff.user_id, meta.value());
}

Result<void> VFSService::share(const SessionContext& session,
                               const std::string& filename,
                               const std::string& username) {
    const std::string source_display = resolver_.resolve(session.cwd_virtual, filename);
    const EffectiveUserPath eff = mapEffective(session, source_display);
    auto admin_guard = ensureAdminWriteAllowed(session, eff.user_id);
    if (admin_guard.isErr()) {
        return admin_guard;
    }
    const std::string owner_pub_path = (fs::path(kPublicKeysDir) / (eff.user_id + ".pub")).string();
    auto owner_pub = loadPublicKeyForUser(crypto_, owner_pub_path, eff.user_id);
    if (owner_pub.isErr()) {
        return Result<void>::err(FsError::NotFound, "missing");
    }

    // Shares must originate from /personal.
    if (eff.per_user_virtual_path.rfind("/personal/", 0) != 0) {
        return Result<void>::err(FsError::NotFound, "missing");
    }

    auto meta = loadMetadata(session, eff.user_id);
    if (meta.isErr()) {
        return Result<void>::err(FsError::NotFound, "missing");
    }

    const auto it = meta.value().files_to_blob.find(eff.per_user_virtual_path);
    if (it == meta.value().files_to_blob.end()) {
        return Result<void>::err(FsError::NotFound, "missing");
    }

    auto recipient_id = registry_.resolveUserId(session, username);
    if (recipient_id.isErr()) {
        return Result<void>::err(FsError::InvalidKeyfile, "unknown user");
    }
    const std::string recipient_pub_path = (fs::path(kPublicKeysDir) / (recipient_id.value() + ".pub")).string();
    auto recipient_pub = loadPublicKeyForUser(crypto_, recipient_pub_path, recipient_id.value());
    if (recipient_pub.isErr()) {
        return Result<void>::err(FsError::InvalidKeyfile, "unknown user");
    }

    const std::string alias = fileNameFromVirtualPath(eff.per_user_virtual_path);
    if (alias.empty() || alias.find('/') != std::string::npos) {
        return Result<void>::err(FsError::InvalidCommand, "invalid alias");
    }

    auto index_lock = acquireExclusiveLock(shareIndexLockPath(recipient_id.value()));
    if (index_lock.isErr()) {
        return Result<void>::err(FsError::Internal, "share index lock failed");
    }
    ScopedFd index_lock_fd(index_lock.value());

    const std::string blob_id = it->second;

    // Unwrap file key from blob header (owner or root).
    const fs::path blob_path = fs::path(kDataRoot) / blob_id;
    auto bytes = readRegularFileBytesBounded(blob_path, kMaxEncryptedRecordBytes);
    if (bytes.isErr()) {
        return Result<void>::err(FsError::NotFound, "missing");
    }

    auto parsed = parseRecordHeader(bytes.value(), kFileMagic, kMissingRecordErrors);
    if (parsed.isErr()) {
        return Result<void>::err(FsError::NotFound, "missing");
    }
    const auto& file_header = parsed.value();

    const std::string file_context = eff.user_id + ":" + blob_id;
    if (!verifyRecordSignature(session,
                               crypto_,
                               owner_pub.value(),
                               kRootPublicKeyPath,
                               kFileMagic,
                               file_context,
                               file_header)) {
        return Result<void>::err(FsError::NotFound, "missing");
    }

    const bool use_owner_wrap = (session.user_id == eff.user_id);
    const bool use_root_wrap = (!use_owner_wrap && session.is_admin);
    if (!use_owner_wrap && !use_root_wrap) {
        return Result<void>::err(FsError::Forbidden, "forbidden");
    }
    const auto& wrapped = use_owner_wrap ? file_header.wrap_a : file_header.wrap_b;
    auto file_key = crypto_.rsaUnwrapKeyWithPrivatePem(wrapped, session.private_key_pem);
    if (file_key.isErr() || file_key.value().size() != 32U) {
        return Result<void>::err(FsError::NotFound, "missing");
    }

    // Build capsule payload: alias, blob_id, file_key_hex.
    const std::string payload_text = alias + "\n" + blob_id + "\n" + hexEncode(file_key.value()) + "\n";

    auto cap_key = crypto_.randomBytes(32);
    if (cap_key.isErr()) {
        return Result<void>::err(FsError::Internal, "capsule keygen failed");
    }

    auto recip_wrapped = crypto_.rsaWrapKeyWithPublicKey(cap_key.value(), recipient_pub.value());
    if (recip_wrapped.isErr()) {
        return Result<void>::err(FsError::Internal, "capsule wrap failed");
    }
    auto root_pub = loadRootPublicKey(session, crypto_, kRootPublicKeyPath);
    if (root_pub.isErr()) {
        return Result<void>::err(FsError::Internal, "capsule root wrap failed");
    }
    auto root_wrapped = crypto_.rsaWrapKeyWithPublicKey(cap_key.value(), root_pub.value());
    if (root_wrapped.isErr()) {
        return Result<void>::err(FsError::Internal, "capsule root wrap failed");
    }

    const std::vector<std::uint8_t> payload_bytes(payload_text.begin(), payload_text.end());
    const auto aad = makeAad("share", eff.user_id, recipient_id.value());
    auto encrypted = crypto_.encryptAesGcm(payload_bytes, cap_key.value(), aad);
    if (encrypted.isErr()) {
        return Result<void>::err(FsError::Internal, "capsule encrypt failed");
    }

    const std::string context = eff.user_id + ":" + recipient_id.value();
    const auto msg = signatureMessage(kShareMagic,
                                      context,
                                      encrypted.value().iv,
                                      encrypted.value().tag,
                                      recip_wrapped.value(),
                                      root_wrapped.value(),
                                      encrypted.value().ciphertext);
    auto sig = crypto_.signRsaPssSha256WithPrivatePem(msg, session.private_key_pem);
    if (sig.isErr()) {
        return Result<void>::err(FsError::Internal, "capsule sign failed");
    }

    std::string cap_header;
    cap_header.reserve(4096);
    cap_header += kShareMagic;
    cap_header.push_back('\n');
    cap_header += eff.user_id;
    cap_header.push_back('\n');
    cap_header += hexEncode(recip_wrapped.value());
    cap_header.push_back('\n');
    cap_header += hexEncode(root_wrapped.value());
    cap_header.push_back('\n');
    cap_header += hexEncode(encrypted.value().iv);
    cap_header.push_back('\n');
    cap_header += hexEncode(encrypted.value().tag);
    cap_header.push_back('\n');
    cap_header += hexEncode(sig.value());
    cap_header.push_back('\n');

    std::vector<std::uint8_t> encoded;
    encoded.reserve(cap_header.size() + encrypted.value().ciphertext.size());
    encoded.insert(encoded.end(), cap_header.begin(), cap_header.end());
    encoded.insert(encoded.end(), encrypted.value().ciphertext.begin(), encrypted.value().ciphertext.end());

    auto cap_id_bytes = crypto_.randomBytes(16);
    if (cap_id_bytes.isErr()) {
        return Result<void>::err(FsError::Internal, "capsule id gen failed");
    }
    const std::string cap_id = hexEncode(cap_id_bytes.value());

    const fs::path cap_path = fs::path(kSharesRoot) / recipient_id.value() / (cap_id + ".cap");
    auto write = writeFileAtomic(cap_path, encoded);
    if (write.isErr()) {
        return write;
    }

    auto scanned = scanShareDirForCaps(fs::path(kSharesRoot) / recipient_id.value());
    if (scanned.isErr()) {
        std::error_code rm_ec;
        fs::remove(cap_path, rm_ec);
        return Result<void>::err(FsError::InvalidCommand, "share index full");
    }
    std::vector<std::string> entries = std::move(scanned.value());

    if (std::find(entries.begin(), entries.end(), cap_id) == entries.end()) {
        if (entries.size() >= ShareIndexLimits::kMaxShareCapsules) {
            std::error_code rm_ec;
            fs::remove(cap_path, rm_ec);
            return Result<void>::err(FsError::InvalidCommand, "share index full");
        }
        entries.push_back(cap_id);
        std::sort(entries.begin(), entries.end());
    }

    const fs::path index_path = shareIndexPath(recipient_id.value(), kShareIndexRoot);
    auto index_write = writeShareIndexFile(index_path, entries);
    if (index_write.isErr()) {
        std::error_code rm_ec;
        fs::remove(cap_path, rm_ec);
        return index_write;
    }

    return Result<void>::ok();
}

Result<std::string> VFSService::cd(SessionContext& session, const std::string& directory) {
    const std::string resolved = resolver_.resolve(session.cwd_virtual, directory);
    if (directoryExists(session, resolved)) {
        session.cwd_virtual = resolved;
    }
    return Result<std::string>::ok(session.cwd_virtual);
}

}  // namespace bibifi
