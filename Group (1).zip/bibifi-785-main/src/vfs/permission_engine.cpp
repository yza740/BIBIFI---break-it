#include "vfs/permission_engine.h"

namespace bibifi {

bool PermissionEngine::canCreatePath(const SessionContext& session, const std::string& path) const {
    (void)session;
    if (path == "/" || path == "/shared") {
        return false;
    }

    return path.rfind("/shared/", 0) != 0;
}

bool PermissionEngine::canAddUser(const SessionContext& session) const { return session.is_admin; }

}  // namespace bibifi
