#ifndef BIBIFI_VFS_PATH_RESOLVER_H
#define BIBIFI_VFS_PATH_RESOLVER_H

#include <string>

namespace bibifi {

class PathResolver {
public:
    std::string resolve(const std::string& cwd, const std::string& path) const;
};

}  // namespace bibifi

#endif  // BIBIFI_VFS_PATH_RESOLVER_H
