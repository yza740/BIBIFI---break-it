#ifndef BIBIFI_VFS_PERMISSION_ENGINE_H
#define BIBIFI_VFS_PERMISSION_ENGINE_H

#include "bibifi/core/types.h"

#include <string>

namespace bibifi {

class PermissionEngine {
public:
    bool canCreatePath(const SessionContext& session, const std::string& path) const;
    bool canAddUser(const SessionContext& session) const;
};

}  // namespace bibifi

#endif  // BIBIFI_VFS_PERMISSION_ENGINE_H
