#include "vfs/path_resolver.h"

#include <sstream>
#include <vector>

namespace bibifi {

namespace {

std::vector<std::string> splitPath(const std::string& path) {
    std::vector<std::string> parts;
    std::stringstream ss(path);
    std::string token;

    while (std::getline(ss, token, '/')) {
        if (token.empty() || token == ".") {
            continue;
        }
        parts.push_back(token);
    }

    return parts;
}

std::string buildPath(const std::vector<std::string>& stack) {
    if (stack.empty()) {
        return "/";
    }

    std::string out;
    for (const auto& part : stack) {
        out += "/" + part;
    }
    return out;
}

}  // namespace

std::string PathResolver::resolve(const std::string& cwd, const std::string& path) const {
    if (path.empty()) {
        return cwd;
    }

    std::vector<std::string> stack;
    if (path.front() != '/') {
        stack = splitPath(cwd);
    }

    for (const auto& token : splitPath(path)) {
        if (token == "..") {
            if (!stack.empty()) {
                stack.pop_back();
            }
            continue;
        }
        stack.push_back(token);
    }

    return buildPath(stack);
}

}  // namespace bibifi
