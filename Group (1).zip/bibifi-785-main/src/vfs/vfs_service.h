#ifndef BIBIFI_VFS_VFS_SERVICE_H
#define BIBIFI_VFS_VFS_SERVICE_H

#include "bibifi/core/result.h"
#include "bibifi/core/types.h"
#include "crypto/crypto_provider.h"
#include "users/registry_store.h"
#include "vfs/path_resolver.h"
#include "vfs/permission_engine.h"

#include <map>
#include <set>
#include <string>
#include <vector>

namespace bibifi {

class VFSService {
public:
    Result<std::string> pwd(const SessionContext& session) const;
    Result<std::vector<ListEntry>> ls(const SessionContext& session) const;
    Result<std::string> cat(const SessionContext& session, const std::string& filename) const;

    Result<void> mkdir(const SessionContext& session, const std::string& directory_name);
    Result<void> mkfile(const SessionContext& session,
                        const std::string& filename,
                        const std::string& contents);
    Result<void> share(const SessionContext& session,
                       const std::string& filename,
                       const std::string& username);
    Result<std::string> cd(SessionContext& session, const std::string& directory);

private:
    struct EffectiveUserPath {
        std::string user_id;
        std::string per_user_virtual_path;
    };

    struct UserMetadata {
        std::set<std::string> directories;                 // full paths under /personal (including /personal)
        std::map<std::string, std::string> files_to_blob;  // full paths -> blob id
    };

    struct ShareViewEntry {
        std::string alias;
        std::string owner_user_id;
        std::string blob_id;
        std::vector<std::uint8_t> file_key;
    };

    static std::string parentVirtualPath(const std::string& virtual_path);
    static std::string fileNameFromVirtualPath(const std::string& virtual_path);
    static bool hasAllowedRootPrefix(const std::string& virtual_path);
    static bool isValidUsername(const std::string& username);

    EffectiveUserPath mapEffective(const SessionContext& session,
                                   const std::string& virtual_path) const;

    Result<UserMetadata> loadMetadata(const SessionContext& session,
                                      const std::string& user_id) const;
    Result<void> saveMetadata(const SessionContext& session,
                              const std::string& user_id,
                              const UserMetadata& metadata) const;

    bool directoryExists(const SessionContext& session, const std::string& virtual_path) const;

    Result<std::string> readPersonalFile(const SessionContext& session,
                                         const std::string& owner_user_id,
                                         const std::string& blob_id,
                                         const std::vector<std::uint8_t>* override_file_key = nullptr) const;

    Result<std::vector<ShareViewEntry>> listSharedFiles(const SessionContext& session,
                                                        const std::string& recipient_user_id) const;
    Result<ShareViewEntry> findSharedFile(const SessionContext& session,
                                         const std::string& recipient_user_id,
                                         const std::string& alias) const;

    static constexpr const char* kFilesystemRoot = "filesystem";
    static constexpr const char* kDataRoot = "filesystem/data";
    static constexpr const char* kMetaRoot = "filesystem/meta";
    static constexpr const char* kSharesRoot = "filesystem/shares";
    static constexpr const char* kShareIndexRoot = "filesystem/shares_index";
    static constexpr const char* kPublicKeysDir = "public_keys";
    static constexpr const char* kRootPublicKeyPath = "public_keys/root.pub";

    PathResolver resolver_;
    PermissionEngine permissions_;
    RegistryStore registry_;
    CryptoProvider crypto_;
};

}  // namespace bibifi

#endif  // BIBIFI_VFS_VFS_SERVICE_H
