#ifndef BIBIFI_APP_FILESERVER_APP_H
#define BIBIFI_APP_FILESERVER_APP_H

#include "auth/auth_manager.h"
#include "bibifi/core/result.h"

#include <string>

namespace bibifi {

class FileserverApp {
public:
    int run(int argc, char** argv);

private:
    Result<void> bootstrap();

    AuthManager auth_;
};

}  // namespace bibifi

#endif  // BIBIFI_APP_FILESERVER_APP_H
