#include "app/fileserver_app.h"

#include "cli/shell.h"
#include "users/user_manager.h"

#include <iostream>

namespace bibifi {

Result<void> FileserverApp::bootstrap() {
    UserManager users;
    // Ensure root key material and encrypted registry exist.
    return users.bootstrapRoot();
}

int FileserverApp::run(int argc, char** argv) {
    constexpr const char* kStartupFailureMessage = "Invalid keyfile";
    if (argc != 2) {
        std::cout << "Invalid keyfile" << std::endl;
        return 1;
    }

    auto boot = bootstrap();
    if (boot.isErr()) {
        std::cout << kStartupFailureMessage << std::endl;
        return 1;
    }

    auto session_result = auth_.login(argv[1]);
    if (session_result.isErr()) {
        std::cout << "Invalid keyfile" << std::endl;
        return 1;
    }

    auto session = session_result.value();
    std::cout << "Logged in as " << session.username << std::endl;

    Shell shell;
    shell.run(session);
    return 0;
}

}  // namespace bibifi
