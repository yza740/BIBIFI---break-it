#ifndef BIBIFI_IO_FILE_UTILS_H
#define BIBIFI_IO_FILE_UTILS_H

#include "bibifi/core/result.h"

#include <cstdint>
#include <filesystem>
#include <vector>

namespace bibifi {

Result<std::vector<std::uint8_t>> readRegularFileBytesBounded(const std::filesystem::path& path,
                                                              std::uintmax_t max_bytes);
Result<void> writeFileAtomic(const std::filesystem::path& path, const std::vector<std::uint8_t>& bytes);
// Caller must close the returned fd to release the lock.
Result<int> acquireExclusiveLock(const std::filesystem::path& lock_path);

}  // namespace bibifi

#endif  // BIBIFI_IO_FILE_UTILS_H
