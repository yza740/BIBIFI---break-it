#include "io/file_utils.h"
#include "crypto/openssl_utils.h"

#include <cerrno>
#include <chrono>
#include <fcntl.h>
#include <string>
#include <sys/file.h>
#include <sys/stat.h>
#include <thread>
#include <unistd.h>

namespace bibifi {

namespace fs = std::filesystem;

namespace {

Result<std::string> randomHexToken(std::size_t bytes) {
    static constexpr char kHex[] = "0123456789abcdef";

    auto buf = opensslRandomBytes(bytes);
    if (buf.isErr()) {
        return Result<std::string>::err(buf.error(), buf.message());
    }

    std::string out;
    out.reserve(bytes * 2);
    for (unsigned char val : buf.value()) {
        out.push_back(kHex[(val >> 4) & 0x0F]);
        out.push_back(kHex[val & 0x0F]);
    }
    return Result<std::string>::ok(out);
}

Result<int> openDirectoryNoSymlink(const fs::path& dir) {
    int dirfd = AT_FDCWD;
    bool opened = false;
    for (const auto& part : dir) {
        if (part.empty() || part == ".") {
            continue;
        }
        if (part == "/") {
            if (dirfd != AT_FDCWD) {
                ::close(dirfd);
            }
            dirfd = ::open("/", O_RDONLY | O_DIRECTORY
#ifdef O_CLOEXEC
                                      | O_CLOEXEC
#endif
#ifdef O_NOFOLLOW
                                      | O_NOFOLLOW
#endif
            );
            if (dirfd < 0) {
                return Result<int>::err(FsError::Internal, "open dir failed");
            }
            opened = true;
            continue;
        }
        const std::string name = part.string();
        struct stat st {};
        if (::fstatat(dirfd, name.c_str(), &st, AT_SYMLINK_NOFOLLOW) != 0) {
            if (errno == ENOENT) {
                if (::mkdirat(dirfd, name.c_str(), 0700) != 0 && errno != EEXIST) {
                    if (dirfd != AT_FDCWD) {
                        ::close(dirfd);
                    }
                    return Result<int>::err(FsError::Internal, "cannot create directories");
                }
                if (::fstatat(dirfd, name.c_str(), &st, AT_SYMLINK_NOFOLLOW) != 0) {
                    if (dirfd != AT_FDCWD) {
                        ::close(dirfd);
                    }
                    return Result<int>::err(FsError::Internal, "path status failed");
                }
            } else {
                if (dirfd != AT_FDCWD) {
                    ::close(dirfd);
                }
                return Result<int>::err(FsError::Internal, "path status failed");
            }
        }
        if (S_ISLNK(st.st_mode)) {
            if (dirfd != AT_FDCWD) {
                ::close(dirfd);
            }
            return Result<int>::err(FsError::Forbidden, "symlink path forbidden");
        }
        if (!S_ISDIR(st.st_mode)) {
            if (dirfd != AT_FDCWD) {
                ::close(dirfd);
            }
            return Result<int>::err(FsError::Internal, "path component not directory");
        }

        int next_fd = ::openat(dirfd,
                               name.c_str(),
                               O_RDONLY | O_DIRECTORY
#ifdef O_CLOEXEC
                                   | O_CLOEXEC
#endif
#ifdef O_NOFOLLOW
                                   | O_NOFOLLOW
#endif
        );
        if (next_fd < 0) {
            if (dirfd != AT_FDCWD) {
                ::close(dirfd);
            }
            return Result<int>::err(FsError::Internal, "open dir failed");
        }
        if (opened) {
            ::close(dirfd);
        }
        opened = true;
        dirfd = next_fd;
    }
    return Result<int>::ok(dirfd);
}

Result<int> openDirectoryNoSymlinkExisting(const fs::path& dir) {
    int dirfd = AT_FDCWD;
    bool opened = false;
    for (const auto& part : dir) {
        if (part.empty() || part == ".") {
            continue;
        }
        if (part == "/") {
            if (dirfd != AT_FDCWD) {
                ::close(dirfd);
            }
            dirfd = ::open("/", O_RDONLY | O_DIRECTORY
#ifdef O_CLOEXEC
                                      | O_CLOEXEC
#endif
#ifdef O_NOFOLLOW
                                      | O_NOFOLLOW
#endif
            );
            if (dirfd < 0) {
                return Result<int>::err(FsError::NotFound, "open dir failed");
            }
            opened = true;
            continue;
        }
        const std::string name = part.string();
        struct stat st {};
        if (::fstatat(dirfd, name.c_str(), &st, AT_SYMLINK_NOFOLLOW) != 0) {
            if (dirfd != AT_FDCWD) {
                ::close(dirfd);
            }
            if (errno == ENOENT) {
                return Result<int>::err(FsError::NotFound, "path missing");
            }
            return Result<int>::err(FsError::Internal, "path status failed");
        }
        if (S_ISLNK(st.st_mode)) {
            if (dirfd != AT_FDCWD) {
                ::close(dirfd);
            }
            return Result<int>::err(FsError::Forbidden, "symlink path forbidden");
        }
        if (!S_ISDIR(st.st_mode)) {
            if (dirfd != AT_FDCWD) {
                ::close(dirfd);
            }
            return Result<int>::err(FsError::NotFound, "path component not directory");
        }

        int next_fd = ::openat(dirfd,
                               name.c_str(),
                               O_RDONLY | O_DIRECTORY
#ifdef O_CLOEXEC
                                   | O_CLOEXEC
#endif
#ifdef O_NOFOLLOW
                                   | O_NOFOLLOW
#endif
        );
        if (next_fd < 0) {
            if (dirfd != AT_FDCWD) {
                ::close(dirfd);
            }
            return Result<int>::err(FsError::Internal, "open dir failed");
        }
        if (opened) {
            ::close(dirfd);
        }
        opened = true;
        dirfd = next_fd;
    }
    return Result<int>::ok(dirfd);
}

Result<std::string> createTempFileNoSymlinkInDir(int dirfd, int* out_fd) {
    if (!out_fd) {
        return Result<std::string>::err(FsError::Internal, "fd out missing");
    }

    for (int attempt = 0; attempt < 8; ++attempt) {
        auto token = randomHexToken(8);
        if (token.isErr()) {
            return Result<std::string>::err(token.error(), token.message());
        }
        const std::string name = ".tmp-" + token.value();
        int flags = O_CREAT | O_EXCL | O_WRONLY;
#ifdef O_NOFOLLOW
        flags |= O_NOFOLLOW;
#endif
#ifdef O_CLOEXEC
        flags |= O_CLOEXEC;
#endif
        const int fd = ::openat(dirfd, name.c_str(), flags, 0600);
        if (fd >= 0) {
            *out_fd = fd;
            return Result<std::string>::ok(name);
        }
        if (errno == EEXIST) {
            continue;
        }
        return Result<std::string>::err(FsError::Internal, "temp open failed");
    }
    return Result<std::string>::err(FsError::Internal, "temp open failed");
}

}  // namespace

Result<int> acquireExclusiveLock(const fs::path& lock_path) {
    const fs::path parent = lock_path.parent_path().empty() ? fs::path(".") : lock_path.parent_path();
    const std::string filename = lock_path.filename().string();
    if (filename.empty() || filename == "." || filename == "..") {
        return Result<int>::err(FsError::Internal, "invalid lock path");
    }

    int open_flags = O_RDWR | O_CREAT;
#ifdef O_NOFOLLOW
    open_flags |= O_NOFOLLOW;
#endif
#ifdef O_CLOEXEC
    open_flags |= O_CLOEXEC;
#endif
    constexpr int kMaxAttempts = 8;
    for (int attempt = 0; attempt < kMaxAttempts; ++attempt) {
        auto dirfd_result = openDirectoryNoSymlink(parent);
        if (dirfd_result.isErr()) {
            if (attempt + 1 < kMaxAttempts) {
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
                continue;
            }
            return Result<int>::err(FsError::Internal, "lock directory unavailable");
        }

        const int dirfd = dirfd_result.value();
        const int lock_fd = ::openat(dirfd, filename.c_str(), open_flags, 0600);
        const int open_errno = errno;
        if (dirfd != AT_FDCWD) {
            ::close(dirfd);
        }
        if (lock_fd < 0) {
            if ((open_errno == EINTR || open_errno == ENOENT) && attempt + 1 < kMaxAttempts) {
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
                continue;
            }
            return Result<int>::err(FsError::Internal, "lock open failed");
        }

        struct stat st {};
        if (::fstat(lock_fd, &st) != 0 || !S_ISREG(st.st_mode)) {
            ::close(lock_fd);
            return Result<int>::err(FsError::Internal, "lock file invalid");
        }

        while (::flock(lock_fd, LOCK_EX) != 0) {
            if (errno == EINTR) {
                continue;
            }
            ::close(lock_fd);
            return Result<int>::err(FsError::Internal, "lock acquire failed");
        }

        return Result<int>::ok(lock_fd);
    }

    return Result<int>::err(FsError::Internal, "lock open failed");
}

Result<std::vector<std::uint8_t>> readRegularFileBytesBounded(const fs::path& path, std::uintmax_t max_bytes) {
    int flags = O_RDONLY;
#ifdef O_NOFOLLOW
    flags |= O_NOFOLLOW;
#endif
#ifdef O_CLOEXEC
    flags |= O_CLOEXEC;
#endif
    const fs::path parent = path.parent_path().empty() ? fs::path(".") : path.parent_path();
    auto dirfd_result = openDirectoryNoSymlinkExisting(parent);
    if (dirfd_result.isErr()) {
        return Result<std::vector<std::uint8_t>>::err(FsError::NotFound, "not found");
    }
    const int dirfd = dirfd_result.value();

    const std::string filename = path.filename().string();
    if (filename.empty() || filename == "." || filename == "..") {
        if (dirfd != AT_FDCWD) {
            ::close(dirfd);
        }
        return Result<std::vector<std::uint8_t>>::err(FsError::NotFound, "not found");
    }

    const int fd = ::openat(dirfd, filename.c_str(), flags);
    if (fd < 0) {
        if (dirfd != AT_FDCWD) {
            ::close(dirfd);
        }
        return Result<std::vector<std::uint8_t>>::err(FsError::NotFound, "not found");
    }

    struct stat st {};
    if (::fstat(fd, &st) != 0) {
        ::close(fd);
        if (dirfd != AT_FDCWD) {
            ::close(dirfd);
        }
        return Result<std::vector<std::uint8_t>>::err(FsError::NotFound, "not found");
    }
    if (!S_ISREG(st.st_mode)) {
        ::close(fd);
        if (dirfd != AT_FDCWD) {
            ::close(dirfd);
        }
        return Result<std::vector<std::uint8_t>>::err(FsError::NotFound, "not found");
    }
    if (st.st_size < 0 || static_cast<std::uintmax_t>(st.st_size) > max_bytes) {
        ::close(fd);
        if (dirfd != AT_FDCWD) {
            ::close(dirfd);
        }
        return Result<std::vector<std::uint8_t>>::err(FsError::Internal, "too large");
    }

    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(st.st_size));
    std::size_t total = 0;
    while (total < bytes.size()) {
        const ssize_t n = ::read(fd, bytes.data() + total, bytes.size() - total);
        if (n < 0 && errno == EINTR) {
            continue;
        }
        if (n <= 0) {
            ::close(fd);
            if (dirfd != AT_FDCWD) {
                ::close(dirfd);
            }
            return Result<std::vector<std::uint8_t>>::err(FsError::Internal, "read failed");
        }
        total += static_cast<std::size_t>(n);
    }
    ::close(fd);
    if (dirfd != AT_FDCWD) {
        ::close(dirfd);
    }
    return Result<std::vector<std::uint8_t>>::ok(bytes);
}

Result<void> writeFileAtomic(const fs::path& path, const std::vector<std::uint8_t>& bytes) {
    const fs::path parent = path.parent_path().empty() ? fs::path(".") : path.parent_path();
    auto dirfd_result = openDirectoryNoSymlink(parent);
    if (dirfd_result.isErr()) {
        return Result<void>::err(dirfd_result.error(), dirfd_result.message());
    }
    const int dirfd = dirfd_result.value();

    const std::string filename = path.filename().string();
    if (filename.empty() || filename == "." || filename == "..") {
        ::close(dirfd);
        return Result<void>::err(FsError::Internal, "invalid path");
    }

    struct stat st {};
    if (::fstatat(dirfd, filename.c_str(), &st, AT_SYMLINK_NOFOLLOW) == 0) {
        if (S_ISLNK(st.st_mode)) {
            ::close(dirfd);
            return Result<void>::err(FsError::Forbidden, "symlink write forbidden");
        }
    } else if (errno != ENOENT) {
        ::close(dirfd);
        return Result<void>::err(FsError::Internal, "path status failed");
    }

    int fd = -1;
    auto tmp_name = createTempFileNoSymlinkInDir(dirfd, &fd);
    if (tmp_name.isErr()) {
        ::close(dirfd);
        return Result<void>::err(FsError::Internal, "temp write failed");
    }

    std::size_t total = 0;
    while (total < bytes.size()) {
        const ssize_t wrote = ::write(fd,
                                      bytes.data() + total,
                                      bytes.size() - total);
        if (wrote < 0) {
            ::close(fd);
            ::unlinkat(dirfd, tmp_name.value().c_str(), 0);
            ::close(dirfd);
            return Result<void>::err(FsError::Internal, "short write");
        }
        total += static_cast<std::size_t>(wrote);
    }
    ::close(fd);

    if (::renameat(dirfd, tmp_name.value().c_str(), dirfd, filename.c_str()) != 0) {
        ::unlinkat(dirfd, tmp_name.value().c_str(), 0);
        ::close(dirfd);
        return Result<void>::err(FsError::Internal, "rename failed");
    }
    ::close(dirfd);
    return Result<void>::ok();
}

}  // namespace bibifi
