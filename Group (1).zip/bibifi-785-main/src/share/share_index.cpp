#include "share/share_index.h"
#include "bibifi/core/validation.h"

#include <algorithm>
#include <sstream>

namespace bibifi {

namespace fs = std::filesystem;

fs::path shareIndexPath(const std::string& recipient_user_id, const char* root) {
    return fs::path(root) / (recipient_user_id + ".idx");
}

Result<std::vector<std::string>> parseShareIndexLines(const std::vector<std::uint8_t>& bytes) {
    std::string text(reinterpret_cast<const char*>(bytes.data()), bytes.size());
    std::stringstream ss(text);
    std::vector<std::string> out;
    std::string line;
    while (std::getline(ss, line)) {
        if (!line.empty() && line.back() == '\r') {
            line.pop_back();
        }
        if (line.empty()) {
            continue;
        }
        if (!isValidCapsuleId(line)) {
            return Result<std::vector<std::string>>::err(FsError::InvalidCommand, "share index corrupt");
        }
        out.push_back(line);
        if (out.size() > ShareIndexLimits::kMaxShareCapsules) {
            return Result<std::vector<std::string>>::err(FsError::InvalidCommand, "share index overflow");
        }
    }
    return Result<std::vector<std::string>>::ok(out);
}

Result<std::vector<std::uint8_t>> encodeShareIndex(const std::vector<std::string>& entries) {
    if (entries.size() > ShareIndexLimits::kMaxShareCapsules) {
        return Result<std::vector<std::uint8_t>>::err(FsError::InvalidCommand, "share index overflow");
    }

    std::string payload;
    payload.reserve(entries.size() * 40);
    for (const auto& entry : entries) {
        if (!isValidCapsuleId(entry)) {
            return Result<std::vector<std::uint8_t>>::err(FsError::InvalidCommand, "share index corrupt");
        }
        payload += entry;
        payload.push_back('\n');
    }
    if (payload.size() > ShareIndexLimits::kMaxShareIndexBytes) {
        return Result<std::vector<std::uint8_t>>::err(FsError::InvalidCommand, "share index too large");
    }

    return Result<std::vector<std::uint8_t>>::ok(std::vector<std::uint8_t>(payload.begin(), payload.end()));
}

Result<std::vector<std::string>> scanShareDirForCaps(const fs::path& dir) {
    std::error_code ec;
    if (!fs::exists(dir, ec) || ec || !fs::is_directory(dir, ec)) {
        return Result<std::vector<std::string>>::ok({});
    }

    std::vector<std::string> out;
    for (fs::directory_iterator it(dir, ec); !ec && it != fs::directory_iterator(); it.increment(ec)) {
        if (!it->is_regular_file(ec)) {
            continue;
        }
        const fs::path path = it->path();
        if (path.extension() != ".cap") {
            continue;
        }
        const std::string cap_id = path.stem().string();
        if (!isValidCapsuleId(cap_id)) {
            continue;
        }
        out.push_back(cap_id);
        if (out.size() > ShareIndexLimits::kMaxShareCapsules) {
            return Result<std::vector<std::string>>::err(FsError::InvalidCommand, "share index overflow");
        }
    }

    std::sort(out.begin(), out.end());
    return Result<std::vector<std::string>>::ok(out);
}

}  // namespace bibifi
