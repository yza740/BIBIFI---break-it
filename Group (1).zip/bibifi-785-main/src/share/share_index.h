#ifndef BIBIFI_SHARE_SHARE_INDEX_H
#define BIBIFI_SHARE_SHARE_INDEX_H

#include "bibifi/core/result.h"

#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

namespace bibifi {

struct ShareIndexLimits {
    // Maximum number of share capsules per recipient user.
    static constexpr std::size_t kMaxShareCapsules = 1024;
    // Maximum serialized index size (line-based list of capsule ids).
    static constexpr std::uintmax_t kMaxShareIndexBytes = kMaxShareCapsules * 64;
    // Maximum capsule record size allowed when loading a share.
    static constexpr std::uintmax_t kMaxShareRecordBytes = 256 * 1024;
};

std::filesystem::path shareIndexPath(const std::string& recipient_user_id, const char* root);

// Parse index bytes into capsule ids.
// Policy: any non-empty invalid line marks the index corrupt.
Result<std::vector<std::string>> parseShareIndexLines(const std::vector<std::uint8_t>& bytes);

// Serialize capsule ids into index bytes with bounds checks.
Result<std::vector<std::uint8_t>> encodeShareIndex(const std::vector<std::string>& entries);

// Scan share capsule directory, enforcing bounds and filtering invalid ids.
Result<std::vector<std::string>> scanShareDirForCaps(const std::filesystem::path& dir);

}  // namespace bibifi

#endif  // BIBIFI_SHARE_SHARE_INDEX_H
