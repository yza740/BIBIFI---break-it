#ifndef BIBIFI_CLI_SHELL_H
#define BIBIFI_CLI_SHELL_H

#include "bibifi/core/types.h"
#include "cli/command_parser.h"
#include "commands/command_handlers.h"

namespace bibifi {

class Shell {
public:
    void run(SessionContext session);

private:
    CommandParser parser_;
    CommandHandlers handlers_;
};

}  // namespace bibifi

#endif  // BIBIFI_CLI_SHELL_H
