#include "cli/shell.h"

#include <iostream>
#include <string>

namespace bibifi {

void Shell::run(SessionContext session) {
    if (session.is_admin) {
        std::cout << "Available commands: cd pwd ls cat share mkdir mkfile adduser exit" << std::endl;
    } else {
        std::cout << "Available commands: cd pwd ls cat share mkdir mkfile exit" << std::endl;
    }

    constexpr std::size_t kMaxCommandBytes = 1024 * 1024 + 1024;

    std::string line;
    while (std::getline(std::cin, line)) {
        if (line.size() > kMaxCommandBytes) {
            std::cout << "Invalid Command" << std::endl;
            continue;
        }

        auto parsed = parser_.parse(line);
        if (!parsed.has_value()) {
            std::cout << "Invalid Command" << std::endl;
            continue;
        }

        auto output = handlers_.handle(parsed.value(), session);
        if (!output.empty()) {
            std::cout << output << std::endl;
        }

        if (handlers_.shouldExit()) {
            break;
        }
    }
}

}  // namespace bibifi
