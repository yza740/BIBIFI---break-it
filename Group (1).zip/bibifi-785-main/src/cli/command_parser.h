#ifndef BIBIFI_CLI_COMMAND_PARSER_H
#define BIBIFI_CLI_COMMAND_PARSER_H

#include "bibifi/core/types.h"

#include <optional>
#include <string>

namespace bibifi {

class CommandParser {
public:
    std::optional<ParsedCommand> parse(const std::string& line) const;
};

}  // namespace bibifi

#endif  // BIBIFI_CLI_COMMAND_PARSER_H
