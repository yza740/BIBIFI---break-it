#include "cli/command_parser.h"

#include <algorithm>
#include <cctype>
#include <sstream>

namespace bibifi {

std::optional<ParsedCommand> CommandParser::parse(const std::string& line) const {
    std::istringstream stream(line);

    ParsedCommand command;
    if (!(stream >> command.name)) {
        return std::nullopt;
    }

    if (command.name == "mkfile") {
        std::string filename;
        if (!(stream >> filename)) {
            return command;
        }

        command.args.push_back(filename);

        std::string contents;
        std::getline(stream, contents);
        // Treat the first separator whitespace as a delimiter, preserve remaining spaces.
        if (!contents.empty() && std::isspace(static_cast<unsigned char>(contents.front()))) {
            contents.erase(contents.begin());
        }
        command.args.push_back(contents);
        return command;
    }

    std::string arg;
    while (stream >> arg) {
        command.args.push_back(arg);
    }

    return command;
}

}  // namespace bibifi
