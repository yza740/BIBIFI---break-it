#include <iostream>

int RunRegressionTests();

int main() {
    const int failures = RunRegressionTests();
    if (failures == 0) {
        std::cout << "regression_tests: PASS" << std::endl;
        return 0;
    }

    std::cout << "regression_tests: FAIL (" << failures << ")" << std::endl;
    return 1;
}
