#include "cli/command_parser.h"
#include "test_assert.h"
#include "transcript_matcher.h"
#include "vfs/path_resolver.h"

int RunRegressionTests() {
    int failures = 0;

    bibifi::CommandParser parser;

    auto mkfile_no_contents = parser.parse("mkfile name");
    failures += Expect(mkfile_no_contents.has_value(),
                       "regression: mkfile without contents still parses for validation stage");

    auto mkfile_spaced = parser.parse("mkfile report   keep  internal   spaces");
    failures += Expect(mkfile_spaced.has_value(), "regression: mkfile with spaces parses");
    if (mkfile_spaced.has_value()) {
        failures += Expect(mkfile_spaced->args.size() == 2,
                           "regression: mkfile spaced variant includes filename and contents");
        if (mkfile_spaced->args.size() == 2) {
            failures += Expect(mkfile_spaced->args[1].find("keep  internal   spaces") != std::string::npos,
                               "regression: mkfile keeps user content spacing tokens");
        }
    }

    bibifi::PathResolver resolver;
    failures += Expect(resolver.resolve("/", "..") == "/", "regression: parent of root remains root");
    failures += Expect(resolver.resolve("/personal/docs", "../../shared") == "/shared",
                       "regression: multi-level traversal normalizes correctly");

    const auto lines = SplitLines("a\nb\n");
    failures += Expect(lines.size() == 2, "regression: SplitLines should not append empty trailing line");

    return failures;
}
