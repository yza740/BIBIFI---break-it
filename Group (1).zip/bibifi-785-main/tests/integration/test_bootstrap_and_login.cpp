#include "binary_locator.h"
#include "case_runner.h"
#include "fixture_loader.h"
#include "temp_workspace.h"
#include "test_assert.h"

int RunContractBootstrapAndLoginTests(const BinaryUnderTest& binary) {
    int failures = 0;
    auto workspace = TempWorkspace::create("bibifi_contract_bootstrap");

    TranscriptCase invalid_login_case{
        "bootstrap_invalid_login",
        "",
        "missing_keyfile",
        LoadFixtureLines("transcripts/spec/bootstrap_invalid_login.expected"),
        {},
        {"filesystem", "public_keys", "admin_keyfile"},
        1,
        true,
    };

    failures += RunTranscriptCase(binary, invalid_login_case, workspace.path());

    TranscriptCase valid_login_case{
        "bootstrap_valid_login",
        LoadFixtureText("scripts/exit.in"),
        "admin_keyfile",
        LoadFixtureLines("transcripts/spec/admin_exit.expected"),
        {},
        {"filesystem", "public_keys", "admin_keyfile"},
        0,
        true,
    };

    failures += RunTranscriptCase(binary, valid_login_case, workspace.path());

    return failures;
}
