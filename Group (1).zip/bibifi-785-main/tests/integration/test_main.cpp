#include "binary_locator.h"

#include <iostream>
#include <string>

int RunContractBootstrapAndLoginTests(const BinaryUnderTest& binary);
int RunCommandContractCoreTests(const BinaryUnderTest& binary);
int RunNavigationContractTests(const BinaryUnderTest& binary);

int RunFileOpsPendingContractTests(const BinaryUnderTest& binary);
int RunSharePendingContractTests(const BinaryUnderTest& binary);
int RunAdminPendingContractTests(const BinaryUnderTest& binary);

namespace {

enum class Mode {
    Contract,
    Pending,
};

Mode ParseMode(int argc, char** argv) {
    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];
        if (arg == "--mode=pending") {
            return Mode::Pending;
        }
    }
    return Mode::Contract;
}

}  // namespace

int main(int argc, char** argv) {
    const BinaryUnderTest binary = ResolveBinaryUnderTest(FILESERVER_PATH);
    const Mode mode = ParseMode(argc, argv);

    int failures = 0;
    if (mode == Mode::Contract) {
        failures += RunContractBootstrapAndLoginTests(binary);
        failures += RunCommandContractCoreTests(binary);
        failures += RunNavigationContractTests(binary);
    } else {
        failures += RunFileOpsPendingContractTests(binary);
        failures += RunSharePendingContractTests(binary);
        failures += RunAdminPendingContractTests(binary);
    }

    if (failures == 0) {
        std::cout << "integration_cli_tests: PASS" << std::endl;
        return 0;
    }

    std::cout << "integration_cli_tests: FAIL (" << failures << ")" << std::endl;
    return 1;
}
