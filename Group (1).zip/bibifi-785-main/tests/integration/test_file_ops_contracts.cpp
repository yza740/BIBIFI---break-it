#include "binary_locator.h"
#include "case_runner.h"
#include "fixture_loader.h"
#include "temp_workspace.h"

int RunFileOpsPendingContractTests(const BinaryUnderTest& binary) {
    int failures = 0;
    auto workspace = TempWorkspace::create("bibifi_pending_file_ops");

    TranscriptCase file_ops_case{
        "pending_file_ops_cat_mkdir_mkfile",
        LoadFixtureText("scripts/pending_file_ops.in"),
        "admin_keyfile",
        LoadFixtureLines("transcripts/spec/pending_file_ops.expected"),
        {},
        {"filesystem", "public_keys", "admin_keyfile"},
        0,
        true,
    };

    failures += RunTranscriptCase(binary, file_ops_case, workspace.path());
    return failures;
}
