#include "binary_locator.h"
#include "case_runner.h"
#include "fixture_loader.h"
#include "temp_workspace.h"

int RunCommandContractCoreTests(const BinaryUnderTest& binary) {
    int failures = 0;
    auto workspace = TempWorkspace::create("bibifi_contract_commands");

    TranscriptCase command_case{
        "command_core_pwd_ls_cd_invalid",
        LoadFixtureText("scripts/pwd_ls_cd_invalid.in"),
        "admin_keyfile",
        LoadFixtureLines("transcripts/spec/pwd_ls_cd_invalid.expected"),
        {},
        {"filesystem", "public_keys", "admin_keyfile"},
        0,
        true,
    };

    failures += RunTranscriptCase(binary, command_case, workspace.path());
    return failures;
}
