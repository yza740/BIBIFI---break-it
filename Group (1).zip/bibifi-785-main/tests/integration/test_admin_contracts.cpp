#include "binary_locator.h"
#include "case_runner.h"
#include "fixture_loader.h"
#include "temp_workspace.h"

int RunAdminPendingContractTests(const BinaryUnderTest& binary) {
    int failures = 0;
    auto workspace = TempWorkspace::create("bibifi_pending_admin");

    TranscriptCase admin_case{
        "pending_admin_adduser_duplicate",
        LoadFixtureText("scripts/pending_admin.in"),
        "admin_keyfile",
        LoadFixtureLines("transcripts/spec/pending_admin.expected"),
        {},
        {"filesystem", "public_keys", "admin_keyfile", "alice_keyfile"},
        0,
        true,
    };

    failures += RunTranscriptCase(binary, admin_case, workspace.path());
    return failures;
}
