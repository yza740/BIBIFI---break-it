#include "binary_locator.h"
#include "case_runner.h"
#include "fixture_loader.h"
#include "temp_workspace.h"

int RunSharePendingContractTests(const BinaryUnderTest& binary) {
    int failures = 0;
    auto workspace = TempWorkspace::create("bibifi_pending_share");

    TranscriptCase share_case{
        "pending_share_file_precedence",
        LoadFixtureText("scripts/pending_share.in"),
        "admin_keyfile",
        LoadFixtureLines("transcripts/spec/pending_share.expected"),
        {},
        {"filesystem", "public_keys", "admin_keyfile"},
        0,
        true,
    };

    failures += RunTranscriptCase(binary, share_case, workspace.path());
    return failures;
}
