#include "binary_locator.h"
#include "case_runner.h"
#include "fixture_loader.h"
#include "temp_workspace.h"

int RunNavigationContractTests(const BinaryUnderTest& binary) {
    int failures = 0;
    auto workspace = TempWorkspace::create("bibifi_contract_navigation");

    TranscriptCase navigation_case{
        "navigation_relative_absolute_root",
        LoadFixtureText("scripts/navigation_relative.in"),
        "admin_keyfile",
        LoadFixtureLines("transcripts/spec/navigation_relative.expected"),
        {},
        {"filesystem", "public_keys", "admin_keyfile"},
        0,
        true,
    };

    failures += RunTranscriptCase(binary, navigation_case, workspace.path());
    return failures;
}
