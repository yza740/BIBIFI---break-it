#include "case_runner.h"

#include "test_assert.h"
#include "transcript_matcher.h"

#include <filesystem>
#include <sstream>

namespace {

std::string MakeContext(const TranscriptCase& test_case, const std::string& suffix) {
    return test_case.name + ": " + suffix;
}

}  // namespace

int RunTranscriptCase(const BinaryUnderTest& binary,
                      const TranscriptCase& test_case,
                      const std::string& working_directory,
                      ProcessResult* out_result) {
    int failures = 0;

    const ProcessResult result =
        ProcessRunner::runFileserver(binary.path, test_case.keyfile, working_directory, test_case.stdin_script);

    if (out_result != nullptr) {
        *out_result = result;
    }

    {
        std::ostringstream message;
        message << MakeContext(test_case, "exit code mismatch") << ". expected="
                << test_case.expected_exit << ", actual=" << result.exit_code;
        failures += Expect(result.exit_code == test_case.expected_exit, message.str());
    }

    if (test_case.must_end_newline) {
        failures += ExpectHasTrailingNewline(result.output, MakeContext(test_case, "newline check"));
    }

    if (!test_case.expected_lines.empty()) {
        failures += ExpectExactLines(result.lines,
                                     test_case.expected_lines,
                                     MakeContext(test_case, "exact transcript"));
    }

    for (const auto& required : test_case.required_substrings) {
        failures += Expect(result.output.find(required) != std::string::npos,
                           MakeContext(test_case, "missing substring: " + required));
    }

    for (const auto& path : test_case.required_files) {
        failures += Expect(std::filesystem::exists(std::filesystem::path(working_directory) / path),
                           MakeContext(test_case, "missing file: " + path));
    }

    return failures;
}
