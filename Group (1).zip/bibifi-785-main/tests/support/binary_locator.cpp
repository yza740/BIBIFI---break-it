#include "binary_locator.h"

#include <cstdlib>

namespace {

std::string GetEnvOrEmpty(const char* name) {
    const char* value = std::getenv(name);
    return value == nullptr ? std::string() : std::string(value);
}

}  // namespace

BinaryUnderTest ResolveBinaryUnderTest(const std::string& default_binary_path) {
    const std::string override_binary = GetEnvOrEmpty("BIBIFI_BINARY_UNDER_TEST");

    BinaryUnderTest target;
    target.path = override_binary.empty() ? default_binary_path : override_binary;
    target.overridden = !override_binary.empty();
    return target;
}
