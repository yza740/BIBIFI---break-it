#ifndef BIBIFI_TESTS_SUPPORT_CASE_RUNNER_H
#define BIBIFI_TESTS_SUPPORT_CASE_RUNNER_H

#include "binary_locator.h"
#include "process_runner.h"

#include <string>
#include <vector>

struct TranscriptCase {
    std::string name;
    std::string stdin_script;
    std::string keyfile;
    std::vector<std::string> expected_lines;
    std::vector<std::string> required_substrings;
    std::vector<std::string> required_files;
    int expected_exit;
    bool must_end_newline;
};

int RunTranscriptCase(const BinaryUnderTest& binary,
                      const TranscriptCase& test_case,
                      const std::string& working_directory,
                      ProcessResult* out_result = nullptr);

#endif  // BIBIFI_TESTS_SUPPORT_CASE_RUNNER_H
