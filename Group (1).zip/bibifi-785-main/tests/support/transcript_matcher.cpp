#include "transcript_matcher.h"

#include "test_assert.h"

#include <algorithm>
#include <iostream>
#include <sstream>

std::vector<std::string> SplitLines(const std::string& text) {
    std::vector<std::string> lines;
    std::stringstream ss(text);
    std::string line;
    while (std::getline(ss, line)) {
        lines.push_back(line);
    }
    return lines;
}

int ExpectHasTrailingNewline(const std::string& output, const std::string& context) {
    const bool ok = !output.empty() && output.back() == '\n';
    return Expect(ok, context + ": output must end with newline");
}

int ExpectExactLines(const std::vector<std::string>& actual,
                    const std::vector<std::string>& expected,
                    const std::string& context) {
    int failures = 0;
    if (actual.size() != expected.size()) {
        std::ostringstream msg;
        msg << context << ": line count mismatch. expected=" << expected.size()
            << ", actual=" << actual.size();
        failures += Expect(false, msg.str());
    }

    const std::size_t count = std::min(actual.size(), expected.size());
    for (std::size_t i = 0; i < count; ++i) {
        std::ostringstream msg;
        msg << context << ": line " << i << " mismatch. expected=['" << expected[i]
            << "'] actual=['" << actual[i] << "']";
        failures += Expect(actual[i] == expected[i], msg.str());
    }

    return failures;
}

int ExpectLineAt(const std::vector<std::string>& lines,
                 std::size_t index,
                 const std::string& expected,
                 const std::string& context) {
    if (index >= lines.size()) {
        std::ostringstream msg;
        msg << context << ": line " << index << " missing";
        return Expect(false, msg.str());
    }

    std::ostringstream msg;
    msg << context << ": line " << index << " mismatch. expected=['" << expected
        << "'] actual=['" << lines[index] << "']";
    return Expect(lines[index] == expected, msg.str());
}
