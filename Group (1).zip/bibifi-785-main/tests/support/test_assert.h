#ifndef BIBIFI_TEST_ASSERT_H
#define BIBIFI_TEST_ASSERT_H

#include <iostream>
#include <string>

inline int Expect(bool condition, const std::string& message) {
    if (condition) {
        return 0;
    }

    std::cerr << "[FAIL] " << message << std::endl;
    return 1;
}

#endif  // BIBIFI_TEST_ASSERT_H
