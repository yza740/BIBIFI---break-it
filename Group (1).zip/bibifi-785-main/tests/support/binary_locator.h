#ifndef BIBIFI_TESTS_SUPPORT_BINARY_LOCATOR_H
#define BIBIFI_TESTS_SUPPORT_BINARY_LOCATOR_H

#include <string>

struct BinaryUnderTest {
    std::string path;
    bool overridden;
};

BinaryUnderTest ResolveBinaryUnderTest(const std::string& default_binary_path);

#endif  // BIBIFI_TESTS_SUPPORT_BINARY_LOCATOR_H
