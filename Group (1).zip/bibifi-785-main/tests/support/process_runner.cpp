#include "process_runner.h"
#include "transcript_matcher.h"

#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <random>
#include <sstream>
#include <string>
#include <sys/wait.h>

namespace {

std::string shellEscape(const std::string& s) {
    std::string out = "'";
    for (char c : s) {
        if (c == '\'') {
            out += "'\\''";
        } else {
            out.push_back(c);
        }
    }
    out += "'";
    return out;
}

std::string randomSuffix() {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> dist(100000, 999999);
    return std::to_string(dist(gen));
}

}  // namespace

ProcessResult ProcessRunner::run(const std::string& command,
                                 const std::string& working_directory,
                                 const std::string& stdin_data) {
    namespace fs = std::filesystem;

    const fs::path base = fs::temp_directory_path() / ("bibifi_test_" + randomSuffix());
    fs::create_directories(base);

    const fs::path input_path = base / "stdin.txt";
    const fs::path output_path = base / "stdout.txt";

    {
        std::ofstream in(input_path);
        in << stdin_data;
    }

    std::ostringstream script;
    script << "cd " << shellEscape(working_directory)
           << " && " << command
           << " < " << shellEscape(input_path.string())
           << " > " << shellEscape(output_path.string())
           << " 2>&1";

    int code = std::system(script.str().c_str());
    int exit_code = code;
    if (WIFEXITED(code)) {
        exit_code = WEXITSTATUS(code);
    }

    std::ifstream out(output_path);
    std::string output((std::istreambuf_iterator<char>(out)), std::istreambuf_iterator<char>());
    const auto lines = SplitLines(output);

    std::error_code ec;
    fs::remove_all(base, ec);
    return {exit_code, output, lines};
}

ProcessResult ProcessRunner::runFileserver(const std::string& fileserver_path,
                                           const std::string& keyfile,
                                           const std::string& working_directory,
                                           const std::string& stdin_data) {
    const std::string command = shellEscape(fileserver_path) + " " + shellEscape(keyfile);
    return run(command, working_directory, stdin_data);
}
