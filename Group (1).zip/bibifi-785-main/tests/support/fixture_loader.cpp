#include "fixture_loader.h"

#include "transcript_matcher.h"

#include <filesystem>
#include <fstream>
#include <sstream>

std::string TestsRootDir() {
#ifdef TESTS_ROOT_DIR
    return TESTS_ROOT_DIR;
#else
    return "tests";
#endif
}

std::string FixturePath(const std::string& relative_path) {
    return (std::filesystem::path(TestsRootDir()) / "fixtures" / relative_path).string();
}

std::string LoadFixtureText(const std::string& relative_path) {
    const std::string full_path = FixturePath(relative_path);
    std::ifstream in(full_path, std::ios::binary);
    if (!in) {
        return "";
    }

    std::ostringstream buffer;
    buffer << in.rdbuf();
    return buffer.str();
}

std::vector<std::string> LoadFixtureLines(const std::string& relative_path) {
    return SplitLines(LoadFixtureText(relative_path));
}
