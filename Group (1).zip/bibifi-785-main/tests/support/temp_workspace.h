#ifndef BIBIFI_TESTS_SUPPORT_TEMP_WORKSPACE_H
#define BIBIFI_TESTS_SUPPORT_TEMP_WORKSPACE_H

#include <filesystem>
#include <string>

class TempWorkspace {
public:
    static TempWorkspace create(const std::string& prefix = "bibifi_test");

    TempWorkspace(TempWorkspace&& other) noexcept;
    TempWorkspace& operator=(TempWorkspace&& other) noexcept;

    TempWorkspace(const TempWorkspace&) = delete;
    TempWorkspace& operator=(const TempWorkspace&) = delete;

    ~TempWorkspace();

    const std::string& path() const;
    std::string resolve(const std::string& relative_path) const;

    void writeFile(const std::string& relative_path, const std::string& contents) const;
    bool exists(const std::string& relative_path) const;

    void keep();

private:
    explicit TempWorkspace(std::filesystem::path path);

    std::filesystem::path path_;
    std::string path_string_;
    bool keep_{false};
};

#endif  // BIBIFI_TESTS_SUPPORT_TEMP_WORKSPACE_H
