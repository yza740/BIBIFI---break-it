#include "temp_workspace.h"

#include <fstream>
#include <random>
#include <utility>

namespace {

std::string randomSuffix() {
    std::random_device rd;
    std::mt19937_64 gen(rd());
    std::uniform_int_distribution<unsigned long long> dist;
    return std::to_string(dist(gen));
}

}  // namespace

TempWorkspace TempWorkspace::create(const std::string& prefix) {
    const std::filesystem::path base =
        std::filesystem::temp_directory_path() / (prefix + "_" + randomSuffix());
    std::filesystem::create_directories(base);
    return TempWorkspace(base);
}

TempWorkspace::TempWorkspace(std::filesystem::path path)
    : path_(std::move(path)), path_string_(path_.string()) {}

TempWorkspace::TempWorkspace(TempWorkspace&& other) noexcept
    : path_(std::move(other.path_)),
      path_string_(std::move(other.path_string_)),
      keep_(other.keep_) {
    other.keep_ = true;
}

TempWorkspace& TempWorkspace::operator=(TempWorkspace&& other) noexcept {
    if (this == &other) {
        return *this;
    }

    if (!keep_) {
        std::error_code ec;
        std::filesystem::remove_all(path_, ec);
    }

    path_ = std::move(other.path_);
    path_string_ = std::move(other.path_string_);
    keep_ = other.keep_;
    other.keep_ = true;
    return *this;
}

TempWorkspace::~TempWorkspace() {
    if (keep_) {
        return;
    }

    std::error_code ec;
    std::filesystem::remove_all(path_, ec);
}

const std::string& TempWorkspace::path() const { return path_string_; }

std::string TempWorkspace::resolve(const std::string& relative_path) const {
    return (path_ / relative_path).string();
}

void TempWorkspace::writeFile(const std::string& relative_path, const std::string& contents) const {
    const std::filesystem::path file_path = path_ / relative_path;
    std::filesystem::create_directories(file_path.parent_path());
    std::ofstream out(file_path, std::ios::binary);
    out << contents;
}

bool TempWorkspace::exists(const std::string& relative_path) const {
    return std::filesystem::exists(path_ / relative_path);
}

void TempWorkspace::keep() { keep_ = true; }
