#ifndef BIBIFI_TESTS_SUPPORT_FIXTURE_LOADER_H
#define BIBIFI_TESTS_SUPPORT_FIXTURE_LOADER_H

#include <string>
#include <vector>

std::string TestsRootDir();
std::string FixturePath(const std::string& relative_path);
std::string LoadFixtureText(const std::string& relative_path);
std::vector<std::string> LoadFixtureLines(const std::string& relative_path);

#endif  // BIBIFI_TESTS_SUPPORT_FIXTURE_LOADER_H
