#ifndef BIBIFI_TESTS_SUPPORT_TRANSCRIPT_MATCHER_H
#define BIBIFI_TESTS_SUPPORT_TRANSCRIPT_MATCHER_H

#include <cstddef>
#include <string>
#include <vector>

std::vector<std::string> SplitLines(const std::string& text);

int ExpectHasTrailingNewline(const std::string& output, const std::string& context);
int ExpectExactLines(const std::vector<std::string>& actual,
                    const std::vector<std::string>& expected,
                    const std::string& context);
int ExpectLineAt(const std::vector<std::string>& lines,
                 std::size_t index,
                 const std::string& expected,
                 const std::string& context);

#endif  // BIBIFI_TESTS_SUPPORT_TRANSCRIPT_MATCHER_H
