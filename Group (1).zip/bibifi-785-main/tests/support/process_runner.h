#ifndef BIBIFI_TESTS_SUPPORT_PROCESS_RUNNER_H
#define BIBIFI_TESTS_SUPPORT_PROCESS_RUNNER_H

#include <string>
#include <vector>

struct ProcessResult {
    int exit_code;
    std::string output;
    std::vector<std::string> lines;
};

class ProcessRunner {
public:
    static ProcessResult run(const std::string& command,
                             const std::string& working_directory,
                             const std::string& stdin_data = "");

    static ProcessResult runFileserver(const std::string& fileserver_path,
                                       const std::string& keyfile,
                                       const std::string& working_directory,
                                       const std::string& stdin_data = "");
};

#endif  // BIBIFI_TESTS_SUPPORT_PROCESS_RUNNER_H
