# Fixtures

Deterministic data used by local test targets.

- `transcripts/spec/*.expected` — spec-first expected outputs.
- `scripts/*.in` — reusable CLI input scripts consumed by transcript tests.

All fixtures are plain text and are loaded by `tests/support/fixture_loader.*`.
