#include "binary_locator.h"

#include <iostream>
#include <string>

int RunKeyfileMalformedCoreTests(const BinaryUnderTest& binary);

int RunMetadataTamperPendingTests();
int RunBlobTamperPendingTests();
int RunForbiddenPathPendingTests(const BinaryUnderTest& binary);

namespace {

enum class Mode {
    Core,
    Pending,
};

Mode ParseMode(int argc, char** argv) {
    for (int i = 1; i < argc; ++i) {
        if (std::string(argv[i]) == "--mode=pending") {
            return Mode::Pending;
        }
    }
    return Mode::Core;
}

}  // namespace

int main(int argc, char** argv) {
    const BinaryUnderTest binary = ResolveBinaryUnderTest(FILESERVER_PATH);
    const Mode mode = ParseMode(argc, argv);

    int failures = 0;
    if (mode == Mode::Core) {
        failures += RunKeyfileMalformedCoreTests(binary);
    } else {
        failures += RunMetadataTamperPendingTests();
        failures += RunBlobTamperPendingTests();
        failures += RunForbiddenPathPendingTests(binary);
    }

    if (failures == 0) {
        std::cout << "security_tests: PASS" << std::endl;
        return 0;
    }

    std::cout << "security_tests: FAIL (" << failures << ")" << std::endl;
    return 1;
}
