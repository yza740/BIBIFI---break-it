#include "binary_locator.h"
#include "case_runner.h"
#include "temp_workspace.h"

int RunKeyfileMalformedCoreTests(const BinaryUnderTest& binary) {
    int failures = 0;
    auto workspace = TempWorkspace::create("bibifi_security_keyfile");

    workspace.writeFile("malformed_keyfile", "not valid username!*\n");

    TranscriptCase malformed_case{
        "security_malformed_keyfile_login",
        "",
        "malformed_keyfile",
        {"Invalid keyfile"},
        {},
        {"filesystem", "public_keys", "admin_keyfile", "malformed_keyfile"},
        1,
        true,
    };

    failures += RunTranscriptCase(binary, malformed_case, workspace.path());
    return failures;
}
