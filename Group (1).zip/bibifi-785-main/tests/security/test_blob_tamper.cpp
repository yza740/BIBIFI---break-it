#include "storage/blob_store.h"
#include "temp_workspace.h"
#include "test_assert.h"

#include <cstdint>
#include <filesystem>
#include <fstream>
#include <vector>

int RunBlobTamperPendingTests() {
    int failures = 0;

    auto workspace = TempWorkspace::create("bibifi_sec_blob");
    bibifi::BlobStore store(workspace.resolve("filesystem/data"));

    const std::string blob_id = "blob_001";
    const std::vector<std::uint8_t> data = {1, 2, 3, 4, 5};

    auto write = store.writeBlob(blob_id, data);
    failures += Expect(write.isOk(), "blob tamper: write blob succeeds");

    {
        std::fstream blob(workspace.resolve("filesystem/data/" + blob_id),
                          std::ios::in | std::ios::out | std::ios::binary);
        char c = 0;
        blob.read(&c, 1);
        blob.seekp(0);
        blob.put(static_cast<char>(c ^ 0xAB));
    }

    auto read = store.readBlob(blob_id);
    failures += Expect(read.isErr(), "blob tamper should fail read under spec behavior");

    return failures;
}
