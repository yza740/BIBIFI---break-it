#include "storage/metadata_store.h"
#include "test_assert.h"

#include <filesystem>
#include <fstream>
#include <random>
#include <string>

namespace {

std::string tempMetaPath() {
    namespace fs = std::filesystem;
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> dist(10000, 99999);
    auto dir = fs::temp_directory_path() / ("bibifi_sec_meta_" + std::to_string(dist(gen)));
    fs::create_directories(dir);
    return (dir / "meta.enc").string();
}

}  // namespace

int RunMetadataTamperPendingTests() {
    int failures = 0;

    const auto path = tempMetaPath();
    bibifi::MetadataStore store(path);

    auto save = store.saveAtomic("test-metadata");
    failures += Expect(save.isOk(), "metadata tamper: initial save succeeds");

    {
        std::fstream file(path, std::ios::in | std::ios::out | std::ios::binary);
        char c = 0;
        file.read(&c, 1);
        file.seekp(0);
        c = static_cast<char>(c ^ 0xFF);
        file.write(&c, 1);
    }

    auto load = store.load();
    failures += Expect(load.isErr(), "metadata tamper should fail load under spec behavior");

    std::error_code ec;
    std::filesystem::remove_all(std::filesystem::path(path).parent_path(), ec);
    return failures;
}
