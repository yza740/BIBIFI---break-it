#include "binary_locator.h"
#include "case_runner.h"
#include "fixture_loader.h"
#include "temp_workspace.h"

int RunForbiddenPathPendingTests(const BinaryUnderTest& binary) {
    int failures = 0;
    auto workspace = TempWorkspace::create("bibifi_sec_forbidden");

    TranscriptCase forbidden_case{
        "security_forbidden_shared_writes",
        LoadFixtureText("scripts/pending_forbidden_paths.in"),
        "admin_keyfile",
        LoadFixtureLines("transcripts/spec/pending_forbidden_paths.expected"),
        {},
        {"filesystem", "public_keys", "admin_keyfile"},
        0,
        true,
    };

    failures += RunTranscriptCase(binary, forbidden_case, workspace.path());
    return failures;
}
