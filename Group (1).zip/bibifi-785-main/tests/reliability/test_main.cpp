#include <iostream>

int RunAtomicMetadataRecoveryTests();

int main() {
    const int failures = RunAtomicMetadataRecoveryTests();
    if (failures == 0) {
        std::cout << "reliability_tests: PASS" << std::endl;
        return 0;
    }

    std::cout << "reliability_tests: FAIL (" << failures << ")" << std::endl;
    return 1;
}
