#include "storage/metadata_store.h"
#include "temp_workspace.h"
#include "test_assert.h"

#include <filesystem>

int RunAtomicMetadataRecoveryTests() {
    int failures = 0;

    auto workspace = TempWorkspace::create("bibifi_rel_meta");
    const std::string meta_path = workspace.resolve("filesystem/meta.enc");

    bibifi::MetadataStore store(meta_path);

    failures += Expect(store.saveAtomic("v1").isOk(), "reliability: save v1 succeeds");
    failures += Expect(store.saveAtomic("v2").isOk(), "reliability: save v2 succeeds");

    workspace.writeFile("filesystem/meta.enc", "corrupted");
    failures += Expect(store.recoverBackup().isOk(), "reliability: backup recovery succeeds");

    auto restored = store.load();
    failures += Expect(restored.isOk(), "reliability: load after recovery succeeds");
    if (restored.isOk()) {
        failures += Expect(restored.value() == "v1",
                           "reliability: recovered metadata should match previous snapshot");
    }

    workspace.writeFile("filesystem/meta.enc.tmp", "dangling-temp-data");
    failures += Expect(store.saveAtomic("v3").isOk(), "reliability: save with dangling temp succeeds");

    auto latest = store.load();
    failures += Expect(latest.isOk(), "reliability: load latest metadata succeeds");
    if (latest.isOk()) {
        failures += Expect(latest.value() == "v3", "reliability: latest metadata should be v3");
    }

    failures += Expect(!std::filesystem::exists(workspace.resolve("filesystem/meta.enc.tmp")),
                       "reliability: temp metadata file should be cleaned up");

    return failures;
}
