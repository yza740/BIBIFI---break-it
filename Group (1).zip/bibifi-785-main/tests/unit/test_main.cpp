#include <iostream>

int RunParserTests();
int RunPathResolverTests();
int RunPermissionEngineTests();

int main() {
    int failures = 0;
    failures += RunParserTests();
    failures += RunPathResolverTests();
    failures += RunPermissionEngineTests();

    if (failures == 0) {
        std::cout << "unit_tests: PASS" << std::endl;
        return 0;
    }

    std::cout << "unit_tests: FAIL (" << failures << ")" << std::endl;
    return 1;
}
