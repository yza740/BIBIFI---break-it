#include "cli/command_parser.h"
#include "test_assert.h"

int RunParserTests() {
    int failures = 0;

    bibifi::CommandParser parser;

    auto mkfile = parser.parse("mkfile note hello world");
    failures += Expect(mkfile.has_value(), "mkfile command should parse");
    if (mkfile.has_value()) {
        failures += Expect(mkfile->name == "mkfile", "mkfile command name");
        failures += Expect(mkfile->args.size() == 2, "mkfile should have filename and contents");
        if (mkfile->args.size() == 2) {
            failures += Expect(mkfile->args[0] == "note", "mkfile filename parse");
            failures += Expect(mkfile->args[1] == "hello world", "mkfile content parse");
        }
    }

    auto blank = parser.parse("   ");
    failures += Expect(!blank.has_value(), "blank command should not parse");

    return failures;
}
