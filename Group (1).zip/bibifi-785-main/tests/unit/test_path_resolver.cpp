#include "vfs/path_resolver.h"
#include "test_assert.h"

int RunPathResolverTests() {
    int failures = 0;

    bibifi::PathResolver resolver;

    failures += Expect(resolver.resolve("/", "../x") == "/x", "root traversal should stay under root");
    failures += Expect(resolver.resolve("/personal/docs", "../../shared") == "/shared",
                       "nested traversal should normalize");
    failures += Expect(resolver.resolve("/personal", "./notes") == "/personal/notes",
                       "dot segments should be ignored");

    return failures;
}
