#include "vfs/permission_engine.h"
#include "test_assert.h"

int RunPermissionEngineTests() {
    int failures = 0;

    bibifi::PermissionEngine permissions;
    bibifi::SessionContext user{"alice", false, "/personal"};
    bibifi::SessionContext admin{"admin", true, "/"};

    failures += Expect(!permissions.canCreatePath(user, "/"), "cannot create in root");
    failures += Expect(!permissions.canCreatePath(user, "/shared"), "cannot create in /shared");
    failures += Expect(!permissions.canCreatePath(user, "/shared/alice"), "cannot create under shared subtree");
    failures += Expect(permissions.canCreatePath(user, "/personal"), "can create under personal");

    failures += Expect(!permissions.canAddUser(user), "normal user cannot add user");
    failures += Expect(permissions.canAddUser(admin), "admin can add user");

    return failures;
}
