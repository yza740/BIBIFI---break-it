# Local Test Suite

All tests run locally via CMake/CTest (no Docker required).

## Build

```bash
cmake -S . -B build
cmake --build build
```

## Run default (spec core only)

```bash
ctest --test-dir build --output-on-failure
```

Default run includes labels: `unit`, `contract`, `security`, `reliability`, `regression`.
Pending tests are compiled but disabled by default.

## Run pending tests

Reconfigure with pending enabled:

```bash
cmake -S . -B build -DBIBIFI_ENABLE_PENDING_CONTRACTS=ON
cmake --build build
ctest --test-dir build --output-on-failure -L pending
```

## Run spec contracts against alternate binary

```bash
BIBIFI_BINARY_UNDER_TEST=/path/to/fileserver \
ctest --test-dir build --output-on-failure -L contract
```
