#ifndef BIBIFI_CORE_RESULT_H
#define BIBIFI_CORE_RESULT_H

#include "bibifi/core/errors.h"

#include <optional>
#include <string>
#include <utility>

namespace bibifi {

template <typename T>
class Result {
public:
    static Result<T> ok(T value) { return Result<T>(std::move(value)); }

    static Result<T> err(FsError error, std::string message = "") {
        return Result<T>(error, std::move(message));
    }

    bool isOk() const { return value_.has_value(); }
    bool isErr() const { return !isOk(); }

    const T& value() const { return *value_; }
    T& value() { return *value_; }

    FsError error() const { return error_; }
    const std::string& message() const { return message_; }

private:
    explicit Result(T value) : value_(std::move(value)), error_(FsError::Internal) {}

    Result(FsError error, std::string message)
        : value_(std::nullopt), error_(error), message_(std::move(message)) {}

    std::optional<T> value_;
    FsError error_;
    std::string message_;
};

template <>
class Result<void> {
public:
    static Result<void> ok() { return Result<void>(true, FsError::Internal, ""); }

    static Result<void> err(FsError error, std::string message = "") {
        return Result<void>(false, error, std::move(message));
    }

    bool isOk() const { return ok_; }
    bool isErr() const { return !ok_; }

    FsError error() const { return error_; }
    const std::string& message() const { return message_; }

private:
    Result(bool ok, FsError error, std::string message)
        : ok_(ok), error_(error), message_(std::move(message)) {}

    bool ok_;
    FsError error_;
    std::string message_;
};

}  // namespace bibifi

#endif  // BIBIFI_CORE_RESULT_H
