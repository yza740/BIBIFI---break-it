#ifndef BIBIFI_CORE_TYPES_H
#define BIBIFI_CORE_TYPES_H

#include <string>
#include <vector>

namespace bibifi {

struct SessionContext {
    std::string username;
    bool is_admin{false};
    std::string cwd_virtual{"/"};
    // Opaque stable identifier for this user's public key (used for on-disk addressing).
    std::string user_id;
    // Optional pinned root user id from keyfile metadata.
    std::string pinned_root_user_id;
    // PEM-encoded private key (excluding the first-line username metadata in keyfiles).
    // Kept in-session so VFS operations can unwrap file/share keys.
    std::string private_key_pem;
};

struct ListEntry {
    bool is_dir{false};
    std::string name;
};

struct ParsedCommand {
    std::string name;
    std::vector<std::string> args;
};

}  // namespace bibifi

#endif  // BIBIFI_CORE_TYPES_H
