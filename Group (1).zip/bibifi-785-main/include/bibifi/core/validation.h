#ifndef BIBIFI_CORE_VALIDATION_H
#define BIBIFI_CORE_VALIDATION_H

#include <string>

namespace bibifi {

bool isValidUsername(const std::string& username);
bool isValidUserId(const std::string& user_id);
bool isValidBlobId(const std::string& blob_id);
bool isValidCapsuleId(const std::string& cap_id);

}  // namespace bibifi

#endif  // BIBIFI_CORE_VALIDATION_H
