#ifndef BIBIFI_CORE_ERRORS_H
#define BIBIFI_CORE_ERRORS_H

namespace bibifi {

enum class FsError {
    InvalidCommand,
    Forbidden,
    NotFound,
    AlreadyExists,
    InvalidKeyfile,
    Internal
};

}  // namespace bibifi

#endif  // BIBIFI_CORE_ERRORS_H
